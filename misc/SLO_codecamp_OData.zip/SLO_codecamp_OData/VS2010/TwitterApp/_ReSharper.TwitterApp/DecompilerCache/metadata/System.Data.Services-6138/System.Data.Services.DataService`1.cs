// Type: System.Data.Services.DataService`1
// Assembly: System.Data.Services, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// Assembly location: C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\v3.5\System.Data.Services.dll

using System.Diagnostics;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Channels;

namespace System.Data.Services
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class DataService<T> : IRequestHandler, IDataService
    {
        #region IDataService Members

        public DataServiceProcessingPipeline ProcessingPipeline { [DebuggerStepThrough]
        get; }

        #endregion

        protected T CurrentDataSource { get; }

        #region IRequestHandler Members

        public Message ProcessRequestForMessage(Stream messageBody);

        #endregion

        public void AttachHost(IDataServiceHost host);
        public void ProcessRequest();
        protected virtual T CreateDataSource();
        protected virtual void HandleException(HandleExceptionArgs args);
        protected virtual void OnStartProcessingRequest(ProcessRequestArgs args);
    }
}
