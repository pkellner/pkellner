﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Data.Services.Common;
using System.Linq;
using System.ServiceModel.Syndication;
using System.ServiceModel.Web;
using System.Web;
using System.Xml;

namespace TwitterApp
{
    // property in atom

    //[EntityPropertyMapping("author",SyndicationItemProperty.Title,SyndicationTextContentKind.Plaintext,false)]
    //[EntityPropertyMapping("Text", SyndicationItemProperty.Summary, SyndicationTextContentKind.Html, false)]
    public class Tweet
    {
        public string ID { get; set;}
        public string Text { get; set;}
        public string Author { get; set;}
    }

    public class TwitterDataSource
    {



        private List<Tweet> _tweets = new List<Tweet>();

        public TwitterDataSource()
        {
            LoadTweets();
        }

        private void LoadTweets()
        {

            _tweets.Clear();

            //XmlReaderSettings xmlReaderSettings = new XmlReaderSettings();
            //xmlReaderSettings.ProhibitDtd = false;

            //var feed = SyndicationFeed.Load(XmlReader.Create("http://search.twitter.com/search?q=lance", xmlReaderSettings));

            XmlReader reader = XmlReader.Create("http://search.twitter.com/search.atom?q=lance");
            SyndicationFeed feed = SyndicationFeed.Load(reader);
            foreach (var item in feed.Items)
            {
                _tweets.Add(new Tweet()
                                {
                                    ID = item.Id,
                                    Text = item.Title.Text,
                                    Author = item.Authors.Count > 0 ? item.Authors[0].Name : "No Author"
                                });
            }
        }

        public IQueryable<Tweet> Tweets
        {
            get { return _tweets.AsQueryable(); }
        }
    }



    public class WcfDataServiceTwitter : DataService<TwitterDataSource>
    {
        // This method is called only once to initialize service-wide policies.
        public static void InitializeService(IDataServiceConfiguration config)
        {
            // TODO: set rules to indicate which entity sets and service operations are visible, updatable, etc.
            // Examples:
            config.SetEntitySetAccessRule("*", EntitySetRights.All);
            config.SetServiceOperationAccessRule("*", ServiceOperationRights.All);
            
        }
    }
}
