using System;
using System.Threading;
using System.Web;
using Mono.Security.Cryptography;
using Mono.Security.X509;
using Novell.Directory.Ldap;
using X509Certificate = System.Security.Cryptography.X509Certificates.X509Certificate;

namespace LdapThreadTesterConsole
{
    class Program
    {
        private static LdapConnection lc;  // shared connection

        [STAThread]
        static void Main(string[] args)
        {
            // build the static connection just once before threads start
            BuildStaticConnection();

            CallLdap = true;
            ExitFlag = false;

            // search below for " //!!! Uncomment one of three choices below" to choose which version to run
            // to change parameters, search for //!!! change parameters here
            int numThreads = 200;
            for (int i = 0; i < numThreads; i++)
            {
                Thread t = new Thread(DoLdapLapsGannettSamples);
                t.Name = "PK" + i.ToString();
                t.Start();
            }
        }

        private static void BuildStaticConnection()
        {
            int LdapPort = LdapConnection.DEFAULT_SSL_PORT;
            String ldapHost = "YourHostName.com";
            String loginDN = "cn=administrator,ou=users,o=system";
            String password = "YourPasswordHere";

            lc = new LdapConnection();

            lc.SecureSocketLayer = true;
            lc.UserDefinedServerCertValidationDelegate += new CertificateValidationCallback(MySSLHandler);

            lc.Connect(ldapHost, LdapPort);
            lc.Bind(loginDN, password); // authenticate to the server
        }

        // This is the Callback handler - after "Binding" this is called
        public static bool MySSLHandler(X509Certificate certificate, int[] certificateErrors)
        {
            bool bHowToProceed;
            bool removeFlag = false;
            int bindCount = 0;

            X509Store store;
            X509Stores stores = X509StoreManager.CurrentUser;
            store = stores.TrustedRoot;

            //Import the details of the certificate from the server.

            Mono.Security.X509.X509Certificate x509 = null;
            X509CertificateCollection coll = new X509CertificateCollection();
            byte[] data = certificate.GetRawCertData();
            if (data != null)
                x509 = new Mono.Security.X509.X509Certificate(data);

            bHowToProceed = true;
            if (bHowToProceed)
            {
                //Add the certificate to the store. This is \Documents and Settings\program data\.mono. . . 

                if (x509 != null)
                    coll.Add(x509);
                store.Import(x509);
                if (bindCount == 1)
                    removeFlag = true;
            }

            if (bHowToProceed == false)
            {
                //Remove the certificate added from the store.

                if (removeFlag && bindCount > 1)
                {
                    foreach (Mono.Security.X509.X509Certificate xt509 in store.Certificates)
                    {
                        if (x509 != null)
                            if (CryptoConvert.ToHex(xt509.Hash) == CryptoConvert.ToHex(x509.Hash))
                            {
                                store.Remove(x509);
                            }
                    }
                }
                //Response.Write("SSL Bind Failed.");
            }
            return bHowToProceed;
        }



        static object locker = new object();
        static int _cnter = 0;
        public static int Cnter
        {
            get
            {
                lock (locker)
                {
                    return _cnter;
                }
            }
            set
            {
                lock (locker)
                {
                    _cnter = value;
                }
            }
        }

        static double _totalExecutionTimeInMS;
        public static double TotalExecutionTimeInMS
        {
            get
            {
                lock (locker)
                {
                    return _totalExecutionTimeInMS;
                }
            }
            set
            {
                lock (locker)
                {
                    _totalExecutionTimeInMS = value;
                }
            }
        }


        static bool _exitFlag;
        public static bool ExitFlag
        {
            get
            {
                lock (locker)
                {
                    return _exitFlag;
                }
            }
            set
            {
                lock (locker)
                {
                    _exitFlag = value;
                }
            }
        }

        static bool _callLdap;
        public static bool CallLdap
        {
            get
            {
                lock (locker)
                {
                    return _callLdap;
                }
            }
            set
            {
                lock (locker)
                {
                    _callLdap = value;
                }
            }
        }

        int _secondsInProcess;
        public int SecondsInProcess
        {
            get
            {
                lock (locker)
                {
                    return _secondsInProcess;
                }
            }
            set
            {
                lock (locker)
                {
                    _secondsInProcess = value;
                }
            }
        }

        public static void UpdateCounters(double ms)
        {
            lock (locker)
            {
                _cnter++;
                TotalExecutionTimeInMS += ms;
            }
        }

        static void DoLdapLapsGannettSamples()
        {
            while (!ExitFlag)
            {
                DateTime dtStart = DateTime.Now;

                if (CallLdap)
                {
                    // Singleton SSL
                    MembershipSimulation msnpc =
                        new MembershipSimulation();
                    string str = msnpc.GetUser(lc);
                }
                DateTime dtEnd = DateTime.Now;
                TimeSpan ts = dtEnd.Subtract(dtStart);
                string timeSpent = " ms: " + ts.TotalMilliseconds;
                double ms = Convert.ToInt32(ts.TotalMilliseconds);
                UpdateCounters(ms);
                if (Cnter % 100 == 0)
                {
                    lock (locker)
                    {
                        double timePerCycle = TotalExecutionTimeInMS / Convert.ToDouble(Cnter);
                        Console.WriteLine("Cycles: " + Cnter.ToString() + " Time Per Cycle MS: " + timePerCycle.ToString());
                    }
                }
            }
        }
    }

    class MembershipSimulation
    {
        private int pMaxReturnedValues = 10000;

        public MembershipSimulation()
        {
        }

        public string GetUser(LdapConnection lc)
        {
            String userDNForCompare = "cn=testuser,ou=1003,o=LocalCustomers";
            string emailUser = "testuser@cowpalace.com";
            string emailAttribute = "mail";
            String[] attrs = { LdapConnection.NO_ATTRS };
            String searchBase = "OU=1003,O=LocalCustomers";
            String objectClass = "inetOrgPerson";
            String searchFilterWithParameters = "(&(objectClass={0})({1}={2}))";
            string[] attribs = {
                                   "cn",
                                   "mail",
                                   "lockedByIntruder",
                                   "loginDisabled",
                                    "sn",
                                    "givenName"
                               };

            string userDN = string.Empty;

            try
            {
                LdapSearchResults lsc = null;
                // (&(objectClass=cimINTLocalCustomer)(cimINTCustEmail=DynTestUser0@cowpalace.com))
                string filter = String.Format(searchFilterWithParameters,
                    objectClass, emailAttribute, emailUser);

                lsc = lc.Search(searchBase, LdapConnection.SCOPE_SUB, filter, attribs, false);
                int retCnt = 0;
                while (lsc.hasMore() && retCnt++ < pMaxReturnedValues)
                {
                    LdapEntry nextEntry;
                    nextEntry = lsc.next();
                    if (nextEntry != null)
                    {
                        userDN = nextEntry.DN.ToString();
                        if (!userDN.Equals(userDNForCompare))
                        {
                            Console.WriteLine("DN does not equal, failure");
                        }
                    }
                }
            }
            catch (LdapException e)
            {
                throw new ApplicationException(e.ToString());
            }
            return userDN;
        }
    }
}

       
