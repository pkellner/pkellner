'
'Original C# code translated to VB, Jan 2007, by 
' Sean Devoy
' Time2, Inc
' 
' All credit, rights and license still belong to Peter Kellner
'
' The translation was nearly line for line except for the 
' "Comparison" delegate functions which are handled slightly 
' diffferently in VB.  The functionality is identical.
'
'/*
'Copyright � 2005, Peter Kellner
'All rights reserved.
'http://peterkellner.net

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'
'- Redistributions of source code must retain the above copyright
'notice, this list of conditions and the following disclaimer.
'
'- Neither Peter Kellner, nor the names of its
'contributors may be used to endorse or promote products
'derived from this software without specific prior written 
'permission. 
'
'THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
'"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
'LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
'FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
'COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES INCLUDING,
'BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES 
'LOSS OF USE, DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER 
'CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
'LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
'ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
'POSSIBILITY OF SUCH DAMAGE.
'*/

Partial Class SamplePages_Membership
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '// Grab first username and load roles below
        If Not IsPostBack() Then
            FindFirstUserName()
        End If
    End Sub

    '/// <summary>
    '/// Used to retrieve the first user that would normally be processed
    '/// by the Membership List
    '/// </summary>
    Private Sub FindFirstUserName()
        Dim muc As MembershipUserCollection = Membership.GetAllUsers()
        Dim mu As MembershipUser
        For Each mu In muc
            '// Just grab the first name then break out of loop
            Dim userName As String = mu.UserName
            ObjectDataSourceRoleObject.SelectParameters("UserName").DefaultValue = userName
            Exit For
        Next
    End Sub

    Protected Sub GridViewMembershipUser_RowDeleted(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeletedEventArgs) Handles GridViewMemberUser.RowDeleted
        LabelInsertMessage.Text = ""

        Dim gv As GridView = CType(sender, GridView)

        '// cover case where there is no current user
        If Not IsNothing(Membership.GetUser()) Then
            ObjectDataSourceRoleObject.SelectParameters("UserName").DefaultValue = Membership.GetUser().UserName
            ObjectDataSourceRoleObject.SelectParameters("ShowOnlyAssignedRolls").DefaultValue = "true"
        End If

        GridViewRole.DataBind()
    End Sub


    Protected Sub GridViewMemberUser_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridViewMemberUser.SelectedIndexChanged

        LabelInsertMessage.Text = ""
        Dim gv As GridView = CType(sender, GridView)

        '// cover case where there is no current user
        If Not IsNothing(Membership.GetUser()) Then
            ObjectDataSourceRoleObject.SelectParameters("UserName").DefaultValue = Membership.GetUser().UserName
            ObjectDataSourceRoleObject.SelectParameters("ShowOnlyAssignedRolls").DefaultValue = "true"
        End If

        GridViewRole.DataBind()
    End Sub


    Protected Sub ButtonCreateNewRole_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButtonCreateNewRole.Click
        If (TextBoxCreateNewRole.Text.Length > 0) Then
            ObjectDataSourceRoleObject.InsertParameters("RoleName").DefaultValue = TextBoxCreateNewRole.Text
            ObjectDataSourceRoleObject.Insert()
            GridViewRole.DataBind()
            TextBoxCreateNewRole.Text = ""
        End If
    End Sub

    Protected Function ShowInRoleStatus(ByVal userName As String, ByVal roleName As String) As String
        Dim result As String

        If IsNothing(userName) Or IsNothing(roleName) Then
            Return "No UserName Specified"
        End If

        If (Roles.IsUserInRole(userName, roleName) = True) Then
            result = "Unassign " + userName + " From Role " + roleName
        Else
            result = "Assign " + userName + " To Role " + roleName
        End If

        Return result

    End Function

    Protected Sub ToggleInRole_Click(ByVal sender As Object, ByVal e As EventArgs)
        '// Grab text from button and parse, not so elegant, but gets the job done
        Dim bt As Button = CType(sender, Button)
        Dim buttonText As String = bt.Text

        Dim seps(1) As Char
        seps(0) = " "
        Dim buttonTextArray() As String = buttonText.Split(seps)
        Dim roleName As String = buttonTextArray(4)
        Dim userName As String = buttonTextArray(1)
        Dim whatToDo As String = buttonTextArray(0)
        Dim userNameArray(0) As String
        userNameArray(0) = userName  '// Need to do this because RemoveUserFromRole requires string array.

        If (whatToDo.StartsWith("Un")) Then
            '// need to remove assignment of this role to this user
            Roles.RemoveUsersFromRole(userNameArray, roleName)
        Else
            Roles.AddUserToRole(userName, roleName)
        End If
        GridViewRole.DataBind()
    End Sub



    Protected Sub ButtonNewUser_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButtonNewUser.Click
        '//if (TextBoxUserName.Text.Length > 0 && TextBoxPassword.Text.Length > 0)
        '//{
        ObjectDataSourceMembershipUser.InsertParameters("UserName").DefaultValue = TextBoxUserName.Text
        ObjectDataSourceMembershipUser.InsertParameters("password").DefaultValue = TextBoxPassword.Text
        ObjectDataSourceMembershipUser.InsertParameters("passwordQuestion").DefaultValue = TextBoxPasswordQuestion.Text
        ObjectDataSourceMembershipUser.InsertParameters("passwordAnswer").DefaultValue = TextBoxPasswordAnswer.Text
        ObjectDataSourceMembershipUser.InsertParameters("email").DefaultValue = TextBoxEmail.Text
        ObjectDataSourceMembershipUser.InsertParameters("isApproved").DefaultValue = CheckboxApproval.Checked.ToString.ToLower()

        ObjectDataSourceMembershipUser.Insert()
        GridViewMemberUser.DataBind()
        TextBoxUserName.Text = ""
        TextBoxPassword.Text = ""
        TextBoxEmail.Text = ""
        TextBoxPasswordAnswer.Text = ""
        TextBoxPasswordQuestion.Text = ""
        CheckboxApproval.Checked = False
        '//}
    End Sub

    Protected Function ShowNumberUsersInRole(ByVal numUsersInRole As Int32) As String
        Dim result As String
        result = "Number of Users In Role: " + numUsersInRole.ToString()
        Return result
    End Function

    Protected Sub ObjectDataSourceMembershipUser_Inserted(ByVal sender As Object, ByVal e As ObjectDataSourceStatusEventArgs)
        If Not IsNothing(e.Exception) Then
            LabelInsertMessage.Text = e.Exception.InnerException.Message + " Insert Failed"
            LabelInsertMessage.ForeColor = System.Drawing.Color.Red

            e.ExceptionHandled = True
        Else
            LabelInsertMessage.Text = "Member " + TextBoxUserName.Text + " Inserted Successfully."
            LabelInsertMessage.ForeColor = System.Drawing.Color.Green
        End If
    End Sub

End Class
