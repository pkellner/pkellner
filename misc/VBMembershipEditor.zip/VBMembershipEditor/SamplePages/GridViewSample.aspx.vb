
Partial Class SamplePages_GridViewSample
    Inherits System.Web.UI.Page

End Class
