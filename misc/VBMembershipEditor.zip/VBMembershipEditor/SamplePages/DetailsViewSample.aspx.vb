
Partial Class SamplePages_DetailsViewSample
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub


    Protected Sub DetailsView1_ItemInserted(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DetailsViewInsertedEventArgs) Handles DetailsView1.ItemInserted
        If Not IsNothing(e.Exception) Then
            LabelInsertMessage.Text = e.Exception.InnerException.Message + " Insert Failed"
            LabelInsertMessage.ForeColor = System.Drawing.Color.Red
            e.ExceptionHandled = True
        Else
            LabelInsertMessage.Text = ""
        End If
    End Sub

    Protected Sub DetailsView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DetailsViewPageEventArgs) Handles DetailsView1.PageIndexChanging
        LabelInsertMessage.Text = ""
    End Sub
End Class
