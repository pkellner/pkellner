
Partial Class SamplePages_DetailsViewOneUser
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click2(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        DetailsView1.DataBind()
    End Sub
End Class
