'
'Original C# code translated to VB, Jan 2007, by 
' Sean Devoy
' Time2, Inc
' 
' All credit, rights and license still belong to Peter Kellner
'
' The translation was nearly line for line except for the 
' "Comparison" delegate functions which are handled slightly 
' diffferently in VB.  The functionality is identical.
'
'
'Copyright � 2005, Peter Kellner
'All rights reserved.
'http://peterkellner.net
'
'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'
'- Redistributions of source code must retain the above copyright
'notice, this list of conditions and the following disclaimer.
'
'- Neither Peter Kellner, nor the names of its
'contributors may be used to endorse or promote products
'derived from this software without specific prior written 
'permission. 
'
'THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
'"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
'LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
'FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
'COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES INCLUDING,
'BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES 
'LOSS OF USE, DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER 
'CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
'LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
'ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
'POSSIBILITY OF SUCH DAMAGE.
'*/

Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Collections.ObjectModel

Namespace MembershipUtilities

    '/// <summary>
    '/// A class used to encapsulate the Roles in ASP.NET Membermanagement 2.0
    '/// </summary>
    <DataObject(True)> _
    Public Class RoleDataObject
        '/// <summary>
        '/// Used to get all roles available
        '/// </summary>
        '/// <returns></returns>
        '/// 
        <DataObjectMethod(DataObjectMethodType.Select, True)> _
        Public Shared Function GetRoles() As List(Of RoleData)
            Return GetRoles(Nothing, False)
        End Function

        '/// <summary>
        '/// Returns a collection of RoleData type values.  This specialized constructor lets you request by
        '/// an individual user
        '/// </summary>
        '/// <param name="userName">if nothing and showOnlyAssignedRolls==false, display all roles</param>
        '/// <param name="showOnlyAssignedRolls">if true, just show assigned roles</param>
        '/// <returns></returns>
        <DataObjectMethod(DataObjectMethodType.Select, False)> _
        Public Shared Function GetRoles(ByVal userName As String, ByVal showOnlyAssignedRolls As Boolean) As List(Of RoleData)
            Dim roleList = New List(Of RoleData)
            Dim roleListStr As String() = Roles.GetAllRoles()
            Dim roleName As String

            For Each roleName In roleListStr
                Dim userInRole As Boolean = False
                '// First, figure out if user is in role (if there is a user)
                If Not IsNothing(userName) Then
                    userInRole = Roles.IsUserInRole(userName, roleName)
                End If

                If (showOnlyAssignedRolls = False Or userInRole = True) Then
                    '// Getting usersInRole is only used for the count below
                    Dim usersInRole As String() = Roles.GetUsersInRole(roleName)
                    Dim rd As New RoleData()
                    rd.RoleName = roleName
                    rd.UserName = userName
                    rd.UserInRole = userInRole
                    rd.NumberOfUsersInRole = usersInRole.Length
                    roleList.Add(rd)
                End If
            Next

            '// FxCopy will give us a warning about returning a List rather than a Collection.
            '// We could copy the data, but not worth the trouble.
            Return roleList
        End Function


        '/// <summary>
        '/// Used for Inserting a new role.  Doesn't associate a user with a role.
        '/// This is not quite consistent with this object, but really what we want.
        '/// </summary>
        '/// <param name="RoleName">The Name of the role to insert</param>
        <DataObjectMethod(DataObjectMethodType.Insert, True)> _
        Public Shared Sub Insert(ByVal roleName As String)
            If (Roles.RoleExists(roleName) = False) Then
                Roles.CreateRole(roleName)
            End If
        End Sub

        '/// <summary>
        '/// Delete any given role while first removing any roles associated with existing users
        '/// </summary>
        '/// <param name="roleName">name of role to delete</param>
        <DataObjectMethod(DataObjectMethodType.Delete, True)> _
        Public Shared Sub Delete(ByVal roleName As String)
            '// remove this role from all users.  not sure if deleterole does this automagically
            Dim muc As MembershipUserCollection = Membership.GetAllUsers()
            Dim allUserNames(1) As String
            Dim mu As MembershipUser

            For Each mu In muc
                If (Roles.IsUserInRole(mu.UserName, roleName) = True) Then
                    allUserNames(0) = mu.UserName
                    Roles.RemoveUsersFromRole(allUserNames, roleName)
                End If
            Next
            Roles.DeleteRole(roleName)
        End Sub
    End Class

    '/// <summary>
    '/// Dataobject class used as a base for the collection
    '/// </summary>
    Public Class RoleData

        '// Non normalized column which counts current number of users in a role
        Private pvtNumberOfUsersInRole As Int32
        Public Property NumberOfUsersInRole() As int32
            Get
                Return pvtNumberOfUsersInRole
            End Get
            Set(ByVal value As int32)
                pvtNumberOfUsersInRole = value
            End Set
        End Property

        Private pvtRoleName As String
        <DataObjectField(True)> _
        Public Property RoleName() As String
            Get
                Return pvtRoleName
            End Get
            Set(ByVal value As String)
                pvtRoleName = value
            End Set
        End Property

        Private pvtUserName As String
        Public Property UserName() As String
            Get
                Return pvtUserName
            End Get
            Set(ByVal value As String)
                pvtUserName = value
            End Set
        End Property

        Private pvtUserInRole As Boolean
        Public Property UserInRole() As Boolean
            Get
                Return pvtUserInRole
            End Get
            Set(ByVal value As Boolean)
                pvtUserInRole = value
            End Set
        End Property

    End Class

End Namespace
