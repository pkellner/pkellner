using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Collections.Generic;

/// <summary>
/// Summary description for BO
/// </summary>
/// 
[DataObject(true)]
public class BO
{
    [DataObjectMethod(DataObjectMethodType.Insert, true)]
    public int InsertStuff(string name, string rbValue)
    {

        return 1;
    }

    [DataObjectMethod(DataObjectMethodType.Select, true)]
    public List<Stuff> GetStuff()
    {
        List<Stuff> li = new List<Stuff>();
        li.Add(new Stuff("peter", "3"));
        li.Add(new Stuff("Joe", "2"));
        li.Add(new Stuff("Sam", "4"));
        li.Add(new Stuff("Tom", "4"));
        li.Add(new Stuff("Ron", "1"));
        return li;
    }


    public BO()
    {
    }



}

public class Stuff
{
    private string name;

    public Stuff(string name, string rbValue)
    {
        this.name = name;
        this.rbvalue = rbValue;
    }

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    private string rbvalue;

    public string Rbvalue
    {
        get { return rbvalue; }
        set { rbvalue = value; }
    }

}
