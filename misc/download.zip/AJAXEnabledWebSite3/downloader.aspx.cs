using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SI_Project.Downloader;

public partial class downloader : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void StartBtn_Click(object sender, EventArgs e)
    {
        FileDownloader downloader = new FileDownloader();
        downloader.DownloadComplete += new EventHandler(downloader_DownloadComplete);
        downloader.ProgressChanged += new DownloadProgressHandler(downloader_ProgressChanged);
        downloader.Download("http://peterkellner.net/misc/a.zip", "HARDCODEINSIDEAPP");
    }

    void downloader_ProgressChanged(object sender, DownloadEventArgs e)
    {
        //throw new Exception("The method or operation is not implemented.");
    }

    void downloader_DownloadComplete(object sender, EventArgs e)
    {
        //throw new Exception("The method or operation is not implemented.");
    }
}
