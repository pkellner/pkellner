namespace SearchLight
{
    using System;
    using System.Collections.Generic;

    public class RssPersonItem
    {
        private string _title;
        private string _description;
        private string _lsId;
        private string _enclosure;
        private string _link;
        private string _pubDate;
        private string _lsRelevance;
        private string _lsOwnerID;
        private string _lsFileName;
        private List<ProfileItem> _lsProfileItem;
        private List<OwnerItem> _lsownerItem;



        public RssPersonItem()
        { }


        public RssPersonItem(string _title, string _description, string _lsId, string _enclosure,
            string _link, string _pubDate, string _lsRelevance, string _lsFileName, string _lsOwnerID,
            List<ProfileItem> _lsProfileItems, List<OwnerItem> _ownerItem)
        {
            this._title = _title;
            this._description = _description;
            this._lsId = _lsId;
            this._enclosure = _enclosure;
            this._link = _link;
            this._pubDate = _pubDate;
            this._lsRelevance = _lsRelevance;
            this._lsProfileItem = _lsProfileItems;
            this._lsOwnerID = _lsOwnerID;
            this._lsFileName = _lsFileName;
            this._lsownerItem = _ownerItem;
        }

        public List<OwnerItem> ownerItemList
        {
            get { return _lsownerItem; }
            set { _lsownerItem = value; }
        }


        public string lsFileName
        {
            get { return _lsFileName; }
            set { _lsFileName = value; }
        }


        public string lsOwnerID
        {
            get { return _lsOwnerID; }
            set { _lsOwnerID = value; }
        }

        public string title
        {
            get { return _title; }
            set { _title = value; }
        }

        public string description
        {
            get { return _description; }
            set { _description = value; }
        }

        public string lsId
        {
            get { return _lsId; }
            set { _lsId = value; }
        }

        public string enclosure
        {
            get { return _enclosure; }
            set { _enclosure = value; }
        }

        public string link
        {
            get { return _link; }
            set { _link = value; }
        }

        public string pubDate
        {
            get { return _pubDate; }
            set { _pubDate = value; }
        }

        public string lsRelevance
        {
            get { return _lsRelevance; }
            set { _lsRelevance = value; }
        }

        public List<ProfileItem> lsProfileItems
        {
            get { return _lsProfileItem; }
            set { _lsProfileItem = value; }
        }
    }
}