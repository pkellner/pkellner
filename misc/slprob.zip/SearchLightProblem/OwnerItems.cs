namespace SearchLight
{

    using System;

    /// <summary>
    /// Summary description for OwnerItems
    /// </summary>
    public class OwnerItem
    {
        public OwnerItem()
        {
        }

        private string _ownerEnclosure;
        private string _fileName;
        private string _fullPictureURL;
        private string _description;
        private string _pubDate;
        private string _title;
        private string _link;
        private string _lsID;

        public OwnerItem(string _ownerEnclosure, string _fileName, string _fullPictureURL, string _description, string _pubDate, string _title, string _link, string _lsID)
        {
            this._ownerEnclosure = _ownerEnclosure;
            this._fileName = _fileName;
            this._fullPictureURL = _fullPictureURL;
            this._description = _description;
            this._pubDate = _pubDate;
            this._title = _title;
            this._link = _link;
            this._lsID = _lsID;
        }

        public string ownerEnclosure
        {
            get { return _ownerEnclosure; }
            set { _ownerEnclosure = value; }
        }

        public string ownerfileName
        {
            get { return _fileName; }
            set { _fileName = value; }
        }

        public string OwnerfullPictureURL
        {
            get { return _fullPictureURL; }
            set { _fullPictureURL = value; }
        }

        public string ownerDescription
        {
            get { return _description; }
            set { _description = value; }
        }

        public string ownerPubDate
        {
            get { return _pubDate; }
            set { _pubDate = value; }
        }

        public string ownerTitle
        {
            get { return _title; }
            set { _title = value; }
        }

        public string ownerLink
        {
            get { return _link; }
            set { _link = value; }
        }

        public string ownerLsID
        {
            get { return _lsID; }
            set { _lsID = value; }
        }
    }
}