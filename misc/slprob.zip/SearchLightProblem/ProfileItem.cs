namespace SearchLight
{
    using System;



    /// <summary>
    /// Summary description for ProfileItem
    /// </summary>
    public class ProfileItem
    {
        public ProfileItem()
        {
        }

        private string _attribute;
        private string _value;

        public ProfileItem(string _attribute, string _value)
        {
            this._attribute = _attribute;
            this._value = _value;
        }

        public string attribute
        {
            get { return _attribute; }
            set { _attribute = value; }
        }

        public string value
        {
            get { return _value; }
            set { _value = value; }
        }
    }
}