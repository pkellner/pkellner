﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;
using Utils;

namespace WindowsFormsAppFileSync
{
    public partial class Form1 : Form
    {
        private static List<FileSyncPairInfo> fileSyncPairInfos;
        private const string FileNameForPersist = "SaveFile.txt";


        public Form1()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            

            var fileSyncPairInfo =
                new FileSyncPairInfo()
                    {
                        FolderPairName = textBoxPairName.Text,
                        RightFolder = textBoxRightDir.Text,
                        LeftFolder = textBoxLeftDir.Text
                    };
            fileSyncPairInfos.Add(fileSyncPairInfo);

            listBox1.Items.Add(PrettyFspi(fileSyncPairInfo));
        }

        private static string PrettyFspi(FileSyncPairInfo fileSyncPairInfo)
        {
            return String.Format("{0} : {1} <-> {2}", fileSyncPairInfo.FolderPairName,
                                 fileSyncPairInfo.LeftFolder, fileSyncPairInfo.RightFolder);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            fileSyncPairInfos = File.Exists(FileNameForPersist) ? 
                DeSerialize(FileNameForPersist) : new List<FileSyncPairInfo>();
            foreach (var fileSyncPairInfo in fileSyncPairInfos)
            {
                listBox1.Items.Add(PrettyFspi(fileSyncPairInfo));
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            Serialize(FileNameForPersist, fileSyncPairInfos);
        }

        public static void Serialize(string filename, List<FileSyncPairInfo> objectToSerialize)
        {
            var stream = File.Open(filename, FileMode.Create);
            var xmlFormatter = new BinaryFormatter();
            xmlFormatter.Serialize(stream, objectToSerialize);
            stream.Close();
        }

        public static List<FileSyncPairInfo> DeSerialize(string filename)
        {
            Stream stream = File.Open(filename, FileMode.Open);
            var xmlFormatter = new BinaryFormatter();
            var objectToSerialize = (List<FileSyncPairInfo>)xmlFormatter.Deserialize(stream);
            stream.Close();
            return objectToSerialize;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var fileSyncPairInfo = fileSyncPairInfos[listBox1.SelectedIndex];
            var fileSyncUtils = new FileSyncUtils();
            string retString = fileSyncUtils.ProcessFileSyncPairInfo(fileSyncPairInfo);
            labelResult.Text = retString;
        }



    }
}
