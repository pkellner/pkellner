﻿namespace SyncToyDesktopApp
{
    partial class DialogSyncResult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem17 = new System.Windows.Forms.ListViewItem(new string[] {
            "Delete Folder",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem18 = new System.Windows.Forms.ListViewItem(new string[] {
            "Delete",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem19 = new System.Windows.Forms.ListViewItem(new string[] {
            "Overwrite",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem20 = new System.Windows.Forms.ListViewItem(new string[] {
            "Rename",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem21 = new System.Windows.Forms.ListViewItem(new string[] {
            "New",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem22 = new System.Windows.Forms.ListViewItem(new string[] {
            "Create Folder",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem23 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "---------",
            "---------",
            "---------"}, -1);
            System.Windows.Forms.ListViewItem listViewItem24 = new System.Windows.Forms.ListViewItem(new string[] {
            "All Operations",
            "0",
            "0",
            "0"}, -1);
            this.PictureHeader = new System.Windows.Forms.PictureBox();
            this.LabelHeader = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ListResults = new System.Windows.Forms.ListView();
            this.ColumnOperation = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnSuccessful = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnFailed = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnTotal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LabelDestinationPath = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.LabelSourcePath = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.PanelLeftFolderImage = new System.Windows.Forms.Panel();
            this.StatusStripResults = new System.Windows.Forms.StatusStrip();
            this.TextStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.LabelMessage = new System.Windows.Forms.Label();
            this.ButtonClose = new System.Windows.Forms.Button();
            this.MainBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.LabelStatus = new System.Windows.Forms.Label();
            this.ProgressBarResult = new System.Windows.Forms.ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.PictureHeader)).BeginInit();
            this.StatusStripResults.SuspendLayout();
            this.SuspendLayout();
            // 
            // PictureHeader
            // 
            this.PictureHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.PictureHeader.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.syncToyGradientBar;
            this.PictureHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureHeader.Location = new System.Drawing.Point(0, -1);
            this.PictureHeader.Name = "PictureHeader";
            this.PictureHeader.Size = new System.Drawing.Size(885, 63);
            this.PictureHeader.TabIndex = 0;
            this.PictureHeader.TabStop = false;
            // 
            // LabelHeader
            // 
            this.LabelHeader.AutoSize = true;
            this.LabelHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(37)))), ((int)(((byte)(151)))));
            this.LabelHeader.Location = new System.Drawing.Point(12, 71);
            this.LabelHeader.Name = "LabelHeader";
            this.LabelHeader.Size = new System.Drawing.Size(372, 20);
            this.LabelHeader.TabIndex = 1;
            this.LabelHeader.Text = "The CRSyncFiles run completed successfully,";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(37)))), ((int)(((byte)(151)))));
            this.label2.Location = new System.Drawing.Point(12, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Run Results:";
            // 
            // ListResults
            // 
            this.ListResults.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColumnOperation,
            this.ColumnSuccessful,
            this.ColumnFailed,
            this.ColumnTotal});
            this.ListResults.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(37)))), ((int)(((byte)(151)))));
            this.ListResults.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.ListResults.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem17,
            listViewItem18,
            listViewItem19,
            listViewItem20,
            listViewItem21,
            listViewItem22,
            listViewItem23,
            listViewItem24});
            this.ListResults.Location = new System.Drawing.Point(16, 122);
            this.ListResults.MultiSelect = false;
            this.ListResults.Name = "ListResults";
            this.ListResults.Scrollable = false;
            this.ListResults.Size = new System.Drawing.Size(299, 174);
            this.ListResults.TabIndex = 3;
            this.ListResults.UseCompatibleStateImageBehavior = false;
            this.ListResults.View = System.Windows.Forms.View.Details;
            // 
            // ColumnOperation
            // 
            this.ColumnOperation.Text = "Operation";
            this.ColumnOperation.Width = 116;
            // 
            // ColumnSuccessful
            // 
            this.ColumnSuccessful.Text = "Successful";
            // 
            // ColumnFailed
            // 
            this.ColumnFailed.Text = "Failed";
            // 
            // ColumnTotal
            // 
            this.ColumnTotal.Text = "Total";
            // 
            // LabelDestinationPath
            // 
            this.LabelDestinationPath.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelDestinationPath.Location = new System.Drawing.Point(649, 202);
            this.LabelDestinationPath.Name = "LabelDestinationPath";
            this.LabelDestinationPath.Size = new System.Drawing.Size(223, 16);
            this.LabelDestinationPath.TabIndex = 16;
            this.LabelDestinationPath.Text = "label4";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_Rightgraphic1;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel3.Location = new System.Drawing.Point(624, 106);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(70, 72);
            this.panel3.TabIndex = 13;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_folder;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(624, 202);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(19, 16);
            this.panel2.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label5.Location = new System.Drawing.Point(621, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Right Folder:";
            // 
            // LabelSourcePath
            // 
            this.LabelSourcePath.Location = new System.Drawing.Point(362, 202);
            this.LabelSourcePath.Name = "LabelSourcePath";
            this.LabelSourcePath.Size = new System.Drawing.Size(223, 16);
            this.LabelSourcePath.TabIndex = 12;
            this.LabelSourcePath.Text = "label4";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_folder;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(337, 202);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(19, 16);
            this.panel1.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label3.Location = new System.Drawing.Point(334, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Left Folder:";
            // 
            // PanelLeftFolderImage
            // 
            this.PanelLeftFolderImage.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_LeftGraphic1;
            this.PanelLeftFolderImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelLeftFolderImage.Location = new System.Drawing.Point(337, 106);
            this.PanelLeftFolderImage.Name = "PanelLeftFolderImage";
            this.PanelLeftFolderImage.Size = new System.Drawing.Size(70, 72);
            this.PanelLeftFolderImage.TabIndex = 9;
            // 
            // StatusStripResults
            // 
            this.StatusStripResults.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TextStatus});
            this.StatusStripResults.Location = new System.Drawing.Point(0, 417);
            this.StatusStripResults.Name = "StatusStripResults";
            this.StatusStripResults.Size = new System.Drawing.Size(885, 22);
            this.StatusStripResults.TabIndex = 17;
            this.StatusStripResults.Text = "Progress";
            // 
            // TextStatus
            // 
            this.TextStatus.Name = "TextStatus";
            this.TextStatus.Size = new System.Drawing.Size(0, 17);
            // 
            // LabelMessage
            // 
            this.LabelMessage.Location = new System.Drawing.Point(19, 302);
            this.LabelMessage.Name = "LabelMessage";
            this.LabelMessage.Size = new System.Drawing.Size(296, 23);
            this.LabelMessage.TabIndex = 18;
            this.LabelMessage.Text = "LabelMessage";
            // 
            // ButtonClose
            // 
            this.ButtonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonClose.Location = new System.Drawing.Point(795, 381);
            this.ButtonClose.Name = "ButtonClose";
            this.ButtonClose.Size = new System.Drawing.Size(75, 23);
            this.ButtonClose.TabIndex = 19;
            this.ButtonClose.Text = "Close";
            this.ButtonClose.UseVisualStyleBackColor = true;
            this.ButtonClose.Click += new System.EventHandler(this.CallBackClose);
            // 
            // MainBackgroundWorker
            // 
            this.MainBackgroundWorker.WorkerReportsProgress = true;
            this.MainBackgroundWorker.WorkerSupportsCancellation = true;
            this.MainBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.PerformOperation);
            this.MainBackgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.ProgressUpdate);
            this.MainBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.OperationCompleted);
            // 
            // LabelStatus
            // 
            this.LabelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelStatus.Location = new System.Drawing.Point(13, 331);
            this.LabelStatus.Name = "LabelStatus";
            this.LabelStatus.Size = new System.Drawing.Size(856, 13);
            this.LabelStatus.TabIndex = 20;
            this.LabelStatus.Text = "label1";
            // 
            // ProgressBarResult
            // 
            this.ProgressBarResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ProgressBarResult.Location = new System.Drawing.Point(14, 350);
            this.ProgressBarResult.Name = "ProgressBarResult";
            this.ProgressBarResult.Size = new System.Drawing.Size(855, 17);
            this.ProgressBarResult.TabIndex = 21;
            // 
            // DialogSyncResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 439);
            this.Controls.Add(this.ProgressBarResult);
            this.Controls.Add(this.LabelStatus);
            this.Controls.Add(this.ButtonClose);
            this.Controls.Add(this.LabelMessage);
            this.Controls.Add(this.StatusStripResults);
            this.Controls.Add(this.LabelDestinationPath);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.LabelSourcePath);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PanelLeftFolderImage);
            this.Controls.Add(this.ListResults);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LabelHeader);
            this.Controls.Add(this.PictureHeader);
            this.MinimumSize = new System.Drawing.Size(893, 473);
            this.Name = "DialogSyncResult";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Results:<Folder Pair Name>";
            this.Load += new System.EventHandler(this.DialogResultLoad);
            ((System.ComponentModel.ISupportInitialize)(this.PictureHeader)).EndInit();
            this.StatusStripResults.ResumeLayout(false);
            this.StatusStripResults.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox PictureHeader;
        private System.Windows.Forms.Label LabelHeader;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView ListResults;
        private System.Windows.Forms.ColumnHeader ColumnOperation;
        private System.Windows.Forms.ColumnHeader ColumnSuccessful;
        private System.Windows.Forms.ColumnHeader ColumnFailed;
        private System.Windows.Forms.ColumnHeader ColumnTotal;
        private System.Windows.Forms.Label LabelDestinationPath;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LabelSourcePath;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel PanelLeftFolderImage;
        private System.Windows.Forms.StatusStrip StatusStripResults;
        private System.Windows.Forms.Label LabelMessage;
        private System.Windows.Forms.Button ButtonClose;
        private System.Windows.Forms.ToolStripStatusLabel TextStatus;
        private System.ComponentModel.BackgroundWorker MainBackgroundWorker;
        private System.Windows.Forms.Label LabelStatus;
        private System.Windows.Forms.ProgressBar ProgressBarResult;
    }
}