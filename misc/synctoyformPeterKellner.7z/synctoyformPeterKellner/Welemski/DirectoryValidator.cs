﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Welemski.Utility {
    /// <summary>
    /// Various utilities for handling common tasks.
    /// </summary>
    /// 
    public class DirectoryValidator {



        /// <summary>
        /// Class constructor
        /// </summary>
        /// <param name="aPath">An absolute path</param>
        public DirectoryValidator(string aPath) {
            this.DirectoryPath = aPath;
        }




        public string DirectoryPath {
            get;
            set;
        }


        /// <summary>
        /// Checks if the given file papth is a valid directory and it exists.
        /// </summary>
        /// <param name="aPath">An absolute path</param>
        /// <returns>0 for successfull</returns>
        /// <returns>-1 if the specified path does not exists</returns>
        /// <returns>-2 if </returns>
        public DirectoryValidatorResult Validate() {
            string currentPath = this.DirectoryPath.ToUpper();
            if (currentPath.Contains(":\\"))
            {
                if (Directory.Exists(currentPath))
                {
                    return DirectoryValidatorResult.Exists;
                }else{
                    return DirectoryValidatorResult.DoesNotExists;
                }
            }
            else 
            {
                return DirectoryValidatorResult.InvalidPath;
            }
        }
    }
}
