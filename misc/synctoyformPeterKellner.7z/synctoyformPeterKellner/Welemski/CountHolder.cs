﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Welemski.Collections {

    public class CountHolder {
        public CountHolder() {
            Success = 0;
            Fail = 0;
        }

        public CountHolder(int sucess, int failed)
        {
            Success = sucess;
            Fail = failed;
        }

        public int Success { get; set; }
        public int Fail { get; set; }
        public int Total { get { return Success + Fail; } }

        public void Add(CountHolder countHolder)
        {
            Add(new List<CountHolder>{countHolder});
        }

        public void Add(List<CountHolder> countHolders)
        {
            foreach (var countHolder in countHolders)
            {
                Success += countHolder.Success;
                Fail += countHolder.Fail;
            }
        }
    }
}
