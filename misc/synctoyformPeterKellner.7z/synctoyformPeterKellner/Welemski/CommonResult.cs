﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Welemski.Utility
{
   public enum CommonResult
    {
        SaveSuccessful=3,
        Valid = 2,
        Exists = 1,
        NoError=0,
        NotFound=-1,
        Invalid=-2,
        SaveFailed = -3
    }
}
