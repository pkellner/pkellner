﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Welemski.IO {



    /// <summary>
    /// Represents a file or folder on a given folder tree.
    /// Use this class to get information on various files or folders recursively.
    /// </summary>
    public  class FileNode {

        public FileNode() {
        }

        /// <summary>
        /// Initialize FileNode object with a given root path.
        /// </summary>
        /// <param name="absolutePath"></param>
        public FileNode(string absolutePath) {
            _path = absolutePath;
            _attributes = File.GetAttributes(_path);
        }

        /// <summary>
        /// Initialize FileNode object with a given root path and a parent node
        /// </summary>
        /// <param name="absolutePath"></param>
        /// <param name="parentNode"></param>
        public FileNode(string absolutePath, FileNode parentNode) {
            _path = absolutePath;
            _parentNode = parentNode;
            _attributes = File.GetAttributes(_path);
        }


        private string _path;
        private FileAttributes _attributes;
        private FileNode _parentNode;


        public string Path { get{ return _path; }}
        public FileNode ParentNode { get { return _parentNode; } }
        public FileAttributes FileAttributes { get { return _attributes; } }
        

        public bool IsDirectory()
        {
            if (_attributes == FileAttributes.Directory) {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Determine if this current node is a root path.
        /// </summary>
        public bool IsRootPath
        {
          get { return (_parentNode.Path == _path) ? true : false; }
        }

        /// <summary>
        /// Object information that this node represents.
        /// </summary>
        /// <returns>DirectoryInfo object if this current node is folder else returns FileInfo</returns>
        public object GetInfo() {
            if(IsDirectory()){
                DirectoryInfo info = new DirectoryInfo(_path);
                return info;
            }else{
                FileInfo info = new FileInfo(_path);
                return info;
            }
        }

        public string FileName
        {
            get
            {
                if(IsDirectory())
                {
                    DirectoryInfo directoryInfo = (DirectoryInfo) GetInfo();
                    return directoryInfo.Name;
                }
                FileInfo fileInfo = (FileInfo) GetInfo();
                return fileInfo.Name;
            }
        }

        

        /// <summary>
        /// Retrieves the files and folders the current path.
        /// </summary>
        /// <param name="parentNode">Set this to null if the current node is a parent node</param>
        /// <param name="recursive">If set to true, this method will get all files and folders recursively.</param>
        /// <returns></returns>
        public List<FileNode> ChildNodes(FileNode parentNode,bool recursive) {

            List<FileNode> childNodes = new List<FileNode>();

            _parentNode = parentNode ?? this;

            if(IsDirectory()){
                
                //Get all directories first
                string[] directories = Directory.GetDirectories(_path);
                foreach (var directory in directories) {
                    FileNode directoryNode = new FileNode(directory);
                    childNodes.Add(directoryNode);
                    if (recursive) {
                        childNodes.AddRange(directoryNode.ChildNodes(directoryNode,true));
                    }
                }

                //Get all files after
                string[] files = Directory.GetFiles(_path);
                childNodes.AddRange(files.Select(file => new FileNode(file)));
                return childNodes;
            }
            return childNodes;
        }

    }
}
