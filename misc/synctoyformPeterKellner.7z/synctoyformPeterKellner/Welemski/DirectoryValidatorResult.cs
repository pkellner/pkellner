﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Welemski.Utility {
    public enum DirectoryValidatorResult {
        InvalidPath = -2,
        DoesNotExists = -1,
        Exists = 0
    }
}
