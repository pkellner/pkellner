﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;

using FileSyncUtility;

namespace Welemski.Utility
{
   
       /// <summary>
       /// Manages the folder pair database
       /// </summary>
       public class FileSyncPairManager{        

            public FileSyncPairManager(string aFileName)
            {
                FileName = aFileName;
                _message = string.Empty;
            }


            public FileSyncPairManager() {
                FileName = "DefaultPair.xml";
                _message = string.Empty;
            }

            /// <summary>
            /// Sets and gets the file that contains the saved folder pairs
            /// </summary>
            public string FileName {get;set;}

           /// <summary>
           /// Use this property to get the current folder pair
           /// </summary>
            public FileSyncPairInfo CurrentFolderPair{ get; set; }

           /// <summary>
           /// The current folder pair index from the lists of folder pairs
           /// </summary>
            public int CurrentFolderPairIndex { get; set; }


           /// <summary>
           /// Generic message. Use this property to get various information results.
           /// </summary>
            public string Message {
                get {
                    return _message;
                }
            }

           private string _message;


        

           /// <summary>
           /// Gets all available folder pairs
           /// </summary>
           /// <returns>Lists of FileSyncPairInfo objects</returns>
            public List<FileSyncPairInfo> AvailableFolderPairs()
            {
               

                if(File.Exists(FileName))
                {
                    Stream stream;
                    IFormatter formatter = new BinaryFormatter();
                    stream = new FileStream(FileName, FileMode.Open);
                    List<FileSyncPairInfo> availablePairInfos = (List<FileSyncPairInfo>)formatter.Deserialize(stream);
                    stream.Close();
                    return availablePairInfos;
                }
               return new List<FileSyncPairInfo>();
            }


           /// <summary>
           /// Updates folder pair database
           /// </summary>
            /// <param name="aList">Lists of FileSyncPairInfo objects</param>
           /// <returns></returns>
            public bool UpdateFolderPairs(List<FileSyncPairInfo> aList)
            {
                Stream stream;
                try
                {
                    IFormatter formater = new BinaryFormatter();
                    stream = new FileStream(FileName, FileMode.Create);
                    formater.Serialize(stream, aList);
                    stream.Close();
                    return true;
                }
                catch (Exception pairException)
                {
                    Console.WriteLine("ERROR : Failed to serialize an object");
                    Console.WriteLine("{0}", pairException.Message);
                    return false;
                }
            }


            /// <summary>
            /// Updates the lists of folder pairs in the database with a given name and folder pair object.
            /// </summary>
            /// <param name="folderPairName">The folder pair name. 
            /// NOTE: If you renamed the folder pair please use the original folder pair name prior to saving
            /// </param>
            /// <param name="folderPair">A FileSyncPairInfo object</param>
            /// <returns></returns>
            public bool UpdateFolderPairNamed(string folderPairName, FileSyncPairInfo folderPair)
            {
                if (HasFolderPairNamed(folderPairName)) {
                    List<FileSyncPairInfo> availableFolderPairs = AvailableFolderPairs();
                    availableFolderPairs.RemoveAt(CurrentFolderPairIndex);
                    availableFolderPairs.Insert(CurrentFolderPairIndex, folderPair);
                    return UpdateFolderPairs(availableFolderPairs);
                }
                return false;
            }


           /// <summary>
            /// Adds folder pair
            /// </summary>
            /// <param name="aPair"></param>
            /// <returns></returns>
            public CommonResult AddFolderPair(FileSyncPairInfo aPair)
            {
                if (HasFolderPairNamed(aPair.FolderPairName))
                {
                    return CommonResult.Exists;
                }
               List<FileSyncPairInfo> availableFolderPairs = AvailableFolderPairs();
               availableFolderPairs.Add(aPair);
               return UpdateFolderPairs(availableFolderPairs) ? CommonResult.SaveSuccessful : CommonResult.SaveFailed;
            }

           /// <summary>
           /// Checks to see if a folder pair with a given name exists.
           /// </summary>
           /// <param name="aName"></param>
           /// <returns></returns>
           public bool HasFolderPairNamed(string aName){
               List<FileSyncPairInfo> availableFolderPairs = AvailableFolderPairs();
               foreach (var pairItem in availableFolderPairs)
               {
                   if (pairItem.FolderPairName == aName) {
                       CurrentFolderPair = pairItem;
                       CurrentFolderPairIndex = availableFolderPairs.IndexOf(pairItem);
                       return true;
                   }
               }

               return false;
           }


           /// <summary>
           /// Removes a folder pair with a given name
           /// </summary>
           /// <param name="aName"></param>
           /// <returns></returns>
           public bool RemoveFolderPairNamed(string aName)
           {
               if(HasFolderPairNamed(aName)){
                   List<FileSyncPairInfo> availableFolderPairs = AvailableFolderPairs();
                   try {
                       availableFolderPairs.RemoveAt(CurrentFolderPairIndex);
                       return UpdateFolderPairs(availableFolderPairs);
                   } catch (ArgumentOutOfRangeException) {
                       return false;
                   }
               }
               return false;
           }

           /// <summary>
           /// Rename the folder pair with a given new name
           /// </summary>
           /// <param name="oldName"></param>
           /// <param name="newName"></param>
           /// <returns></returns>
           public bool RenameFolderPair(string oldName, string newName)
           {
               if(HasFolderPairNamed(oldName)){
                       if(HasFolderPairNamed(newName)){
                           return false;
                       }
                   CurrentFolderPair.FolderPairName = newName;
                   List<FileSyncPairInfo> availableFolderPairs = AvailableFolderPairs();
                   availableFolderPairs.RemoveAt(CurrentFolderPairIndex);
                   availableFolderPairs.Insert(CurrentFolderPairIndex, CurrentFolderPair);
                   return UpdateFolderPairs(availableFolderPairs);
               }
               return false;
           }

           /// <summary>
           /// Updates the last run datetime info for a given folder pair name
           /// </summary>
           /// <param name="lastRun"></param>
           /// <param name="pairName"></param>
           /// <returns></returns>
           public bool UpdateLastRunForFolderPairNamed(DateTime lastRun, string pairName)
           {
               if(HasFolderPairNamed(pairName)){
                   CurrentFolderPair.LastRun = string.Format("{0:d} {1:T}", lastRun, lastRun);
                   List<FileSyncPairInfo> availableFolderPairs = AvailableFolderPairs();
                   try {
                       availableFolderPairs.RemoveAt(CurrentFolderPairIndex);
                       availableFolderPairs.Insert(CurrentFolderPairIndex, CurrentFolderPair);
                       return UpdateFolderPairs(availableFolderPairs);
                   } catch (Exception) {
                       Console.WriteLine("ERROR : FAILED TO UPDATE LAST RUN ENTRY");
                       return false;
                   }
               }
               return false;
           }
       }
}
