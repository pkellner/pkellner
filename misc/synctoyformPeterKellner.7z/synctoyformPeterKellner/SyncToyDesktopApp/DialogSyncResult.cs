﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Reflection;
using System.Resources;
using System.Diagnostics;
using System.Diagnostics.Eventing;

using FileSyncUtility;
using SyncToyDesktopApp.Properties;
using Welemski.Collections;

namespace SyncToyDesktopApp
{

   public partial class DialogSyncResult : Form
    {
       private ResourceManager _resourceManager;

       private CountHolder _deletedFolder;
       private CountHolder _deletedFile;
       private CountHolder _overwritten;
       private CountHolder _renamed;
       private CountHolder _createdFolder;
       private CountHolder _createdFile;
       private CountHolder _allOperations;
       private string _logFileName;
        
        public DialogSyncResult()
        {
            InitializeComponent();
            _resourceManager = new ResourceManager("SyncToyDesktopApp.Properties.Resources", Assembly.GetExecutingAssembly());
            ListResults.Clear();
            _deletedFolder = new CountHolder();
            _deletedFile = new CountHolder();
            _overwritten = new CountHolder();
            _renamed = new CountHolder();
            _createdFolder = new CountHolder();
            _createdFile = new CountHolder();
            _allOperations = new CountHolder();
            LabelMessage.Text = "";
            LabelStatus.Text = "";
            _logFileName = _resourceManager.GetString("LOG_FILE_PATH");
        }

        
        private delegate void SetStatusMessageCallback(string message);
        private void SetStatusMessage(string message)
        {
           if(LabelStatus.InvokeRequired)
           {
               SetStatusMessageCallback callback = new SetStatusMessageCallback(SetStatusMessage);
               Invoke(callback,new object[]{message});
           }else
           {
               LabelStatus.Text = message;
           }
        }

       private delegate void SetProgressBarPropertyCallback(ProgressBarStyle aStyle);
       private void SetProgressBarProperty(ProgressBarStyle aStyle)
       {
           if(ProgressBarResult.InvokeRequired)
           {
               SetProgressBarPropertyCallback callback = new SetProgressBarPropertyCallback(SetProgressBarProperty);
               Invoke(callback, new object[] {aStyle});
           }else
           {
               ProgressBarResult.Style = aStyle;
           }
       }

       
        public void SetLogFilePath(string filePath)
        {
            _logFileName = filePath;
        }

        public FileSynchronization FileSynchronizer { get; set; }
        public FileSyncPairInfo FolderPair{ get; set; }
        public List<FileSyncPairInfo> FolderPairs { get; set; }


        public bool DebugEnabled { get; set; }
        public bool ShouldProcess{ get; set;}
        public bool ShouldProcessAll { get; set; }
        public bool DoPreviewMode { get; set; }

        private void DialogResultLoad(object sender, EventArgs e)
        {

            if (ShouldProcess)
            {
                ButtonClose.Text = Resources.TEXT_STOP;
                if (ShouldProcessAll)
                {
                    LabelSourcePath.Text = Resources.TEXT_MULTIPLE_PAIRS;
                    LabelDestinationPath.Text = Resources.TEXT_MULTIPLE_PAIRS;
                    LabelHeader.Text = Resources.TEXT_RUNNING_MULTIPLE_PAIRS;
                    Text = Resources.TEXT_RESULTS_ALL_PAIRS;
                }
                else
                {
                    LabelSourcePath.Text = FolderPair.LeftFolder;
                    LabelDestinationPath.Text = FolderPair.RightFolder;
                    LabelHeader.Text = LabelHeader.Text = String.Format(Resources.TEXT_RUNNING_CRSYNCFILES_FOR, FolderPair.FolderPairName);
                    Text = "Results: " + FolderPair.FolderPairName;
                }
                MainBackgroundWorker.RunWorkerAsync();
            }
            else
            {
                InitializeTableResults();
            }
        }
        

        /// <summary>
        /// Initializes the results view
        /// </summary>
        private void InitializeTableResults(){


            // Need to optimize updating screen.  recreating a listview this way is going to cause the flash.
            // Check with Miles/Stephen for better way to do it. I've not done much forms programming
            // May need to do something like generate static text and just update individual numbers on screen.
            // this solution is a good general purpose way to do it, but since we always show the same type of
            // numbers, we can hardcode that display.

             ListResults.Clear();

            ListResults.Columns.Add("Operations",130);
            ListResults.Columns.Add("Successful");
            ListResults.Columns.Add("Failed");
            ListResults.Columns.Add("Total");

            ListViewItem itemDeletedFolder = ListViewItemCreate("Deleted Folder", _deletedFolder);
            ListViewItem itemDeletedFile = ListViewItemCreate("Deleted", _deletedFile);
            ListViewItem itemOverwritten = ListViewItemCreate("Overwrite", _overwritten);
            ListViewItem itemRename = ListViewItemCreate("Rename", _renamed);
            ListViewItem itemNew = ListViewItemCreate("New", _createdFile);
            ListViewItem itemCreatedFolder = ListViewItemCreate("Create Folder", _createdFolder);
    
            ListViewItem itemSpacer = new ListViewItem(" ");
            itemSpacer.SubItems.Add("---------");
            itemSpacer.SubItems.Add("---------");
            itemSpacer.SubItems.Add("---------");

            ListViewItem itemOperations = ListViewItemCreate("All Operations", _allOperations);

            ListResults.Items.Add(itemDeletedFolder);
            ListResults.Items.Add(itemDeletedFile);
            ListResults.Items.Add(itemOverwritten);
            ListResults.Items.Add(itemRename);
            ListResults.Items.Add(itemNew);
            ListResults.Items.Add(itemCreatedFolder);
            ListResults.Items.Add(itemSpacer);
            ListResults.Items.Add(itemOperations);

        }

        private static ListViewItem ListViewItemCreate(string itemName, CountHolder countHolder) {
            var listViewItem = new ListViewItem(itemName);
            var ints = new List<int> { countHolder.Success, countHolder.Fail, countHolder.Total };
            foreach (var i in ints) {
                listViewItem.SubItems.Add(String.Format("{0}", i));
            }
            return listViewItem;
        }




        private void PerformOperation(object sender, DoWorkEventArgs e)
        {
            FileSynchronizer = ShouldProcessAll
                                   ? new FileSynchronization(FolderPairs)
                                   : new FileSynchronization(FolderPair);
            FileSynchronizer.VerboseEnabled = true;
            FileSynchronizer.SetLog(_logFileName);
            FileSynchronizer.SynchronizationMessages += SynchronizationMessages;
            FileSynchronizer.SynchronizationStarted += SynchronizationStarted;

            FileSynchronizer.FileSynUpdateUIWithProgressIng += FileSynchronizer_FileSynUpdateUIWithProgressIng;

            // update screen with totals every second (better if this was more like 100 ms)
            // this will cause a timer ot be run every 1000 milliseconds that will cause the 
            // FileSynchronizer_FileSynUpdateUIWithProgressIng method to be called trigger the event FileSynUpdateUIWithProgressIng
            // to be fired giving control to this dialog the ability to update all the totals.  All the totals are passed in the args.
            int updateStatsInterval = 1000;


            // this inserts an artificial pause in progress events so that it's easier to debug and demostrate.
            int pauseTimeMs = 250; 
               

            if (DoPreviewMode)
            {
                Console.WriteLine("LOG: Running in preview mode please wait...");
                FileSynchronizer.PreviewMode = true;

                FileSynchronizer.Synchronize(updateStatsInterval, pauseTimeMs);
                    // fire FileSynUpdateUIWithProgressIng event every 250 ms 
                Console.WriteLine("LOG: Running in actual synchronization please wait...");
                FileSynchronizer.PreviewMode = false;
                FileSynchronizer.FilesSyncing += FileSynchronizationUpdate;
                FileSynchronizer.FilesSyncingCompleted += FileSynchronizationFinished;
                FileSynchronizer.Synchronize(updateStatsInterval, pauseTimeMs);

            }
            else
            {
                Console.WriteLine("LOG: Running in actual synchronization please wait...");
                FileSynchronizer.FilesSyncing += FileSynchronizationUpdate;
                FileSynchronizer.FilesSyncingCompleted += FileSynchronizationFinished;
                FileSynchronizer.PreviewMode = false;
                FileSynchronizer.Synchronize(updateStatsInterval, pauseTimeMs);
            }
        }


       void FileSynchronizer_FileSynUpdateUIWithProgressIng(object sender, FileSynchronization.FileSynUpdateUIWithProgressEventHandlerArgs args)
       {
           UpdateScreenWithTotals();
       }

     

       private void SynchronizationStarted(object sender, FileSyncStartedEventArgs e)
       {
           if(e.PreviewMode)
           {
               SetProgressBarProperty(ProgressBarStyle.Marquee);
           }else
           {
               SetProgressBarProperty(ProgressBarStyle.Continuous);
           }
       }

       private void SynchronizationMessages(object sender, FileSyncMessageEventArgs args)
       {
           SetStatusMessage(args.Message);
       }

       private void OperationCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            ButtonClose.Enabled = true;
            //_allOperations.Total = FileSynchronization.FilesChanged;
            UpdateScreenWithTotals();

           //Cursor = Cursors.Arrow;
            ButtonClose.Text = Resources.TEXT_CLOSE;
        }

       private void UpdateScreenWithTotals()
       {
           InitializeTableResults();
           //LabelStatus.Text = Resources.TEXT_COMPLETED;
           LabelHeader.Text = Resources.TEXT_RUN_COMPLETED;
           LabelMessage.Text = FileSynchronizer.Message;
            
           //Update statistics 
           _deletedFolder.Success = FileSynchronizer.TotalDeletedFolders;
           _deletedFile.Success = FileSynchronizer.TotalDeletedFiles;
           _overwritten.Success = FileSynchronizer.TotalOverWrittenFiles;
           _renamed.Success = FileSynchronizer.TotalRenamedFiles;
           _createdFile.Success = FileSynchronizer.TotalCreatedFiles;
           _createdFolder.Success = FileSynchronizer.TotalCreatedFolders;
         
           _allOperations.Add(_deletedFolder);
           _allOperations.Add(_deletedFile);
           _allOperations.Add(_overwritten);
           _allOperations.Add(_renamed);
           _allOperations.Add(_createdFile);
           _allOperations.Add(_createdFolder);

           InitializeTableResults();
       }

    

       private void CallBackClose(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (button.Text == Resources.TEXT_CLOSE)
            {
                Close();
            }
            else if(button.Text == Resources.TEXT_STOP)
            {
                //MainBackgroundWorker.CancelAsync();
                FileSynchronizer.CancelPending = true;
                ButtonClose.Text = Resources.TEXT_CLOSE;
            }
        }

        private void ProgressUpdate(object sender, ProgressChangedEventArgs e) {
            ProgressBarResult.Value = e.ProgressPercentage;
        }

        private void FileSynchronizationUpdate(object sender, FileSyncEventArgs args) {
            FileSynchronization fileSyncUtil = sender as FileSynchronization;
            MainBackgroundWorker.ReportProgress(fileSyncUtil.Progress);
            //LabelStatus.Text = fileSyncUtil.Message;
        }

        private void FileSynchronizationFinished(object sender, FileSyncEventArgs args){
            FileSynchronization fileSyncUtil = sender as FileSynchronization;
            MainBackgroundWorker.ReportProgress(fileSyncUtil.Progress);

            //NOTE : Temporary
            if (DebugEnabled)
            {
                if (!EventLog.SourceExists(Program.EventSource))
                {
                    EventLog.CreateEventSource(Program.EventSource, "Application");
                }

                if (ShouldProcessAll)
                {
                    EventLog.WriteEntry(Program.EventSource,
                                        "CRSyncFiles Synchronization was Successful for all Folder Pairs.",
                                        EventLogEntryType.Information);
                }
                else
                {
                    EventLog.WriteEntry(Program.EventSource,
                                        "CRSyncFiles Synchronization was Successful for Folder Pair : " +
                                        FolderPair.FolderPairName, EventLogEntryType.Information);
                }
            }
        }
    }
}
