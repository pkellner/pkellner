﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

using FileSyncUtility;
using DataAccess.Enums;
using SyncToyDesktopApp.Properties;
using Welemski.Collections;

namespace SyncToyDesktopApp {
    public partial class DialogPreview : Form
    {

        private CountHolder _deletedFolder;
        private CountHolder _deletedFile;
        private CountHolder _overwritten;
        private CountHolder _renamed;
        private CountHolder _createdFile;
        private CountHolder _createdFolder;
        private CountHolder _allOperations;
        private List<FileSyncApplyingChangesEventArgs> _applyingChangesEventArguments;
        
        


        public DialogPreview() {
            InitializeComponent();
            InitializeStatistics();
            ShouldProcessAll = false;
        }

        /// <summary>
        /// Initializes preview dialog with a default folder pair object.
        /// </summary>
        /// <param name="folderPair"></param>
        public DialogPreview(FileSyncPairInfo folderPair){
            InitializeComponent();
            InitializeStatistics();
            FolderPair = folderPair;
            ShouldProcessAll = false;
        }

        /// <summary>
        /// Initializes preview dialog with a default folder pairs to process.
        /// </summary>
        /// <param name="folderPairs"></param>
        public DialogPreview(List<FileSyncPairInfo> folderPairs) {
            InitializeComponent();
            InitializeStatistics();
            FolderPairs = folderPairs;
            ShouldProcessAll = true;
        }

        public FileSyncPairInfo FolderPair { get; set; }
        public List<FileSyncPairInfo> FolderPairs { get; set; }
        public FileSynchronization FileSynchronizer { get ; set; }
        public bool ShouldProcessAll { get; set; }

        private delegate void SetStatusMessageCallback(string message);
        private void SetStatusMessage(string message)
        {
            if (LabelMessage.InvokeRequired)
            {
                SetStatusMessageCallback callback = new SetStatusMessageCallback(SetStatusMessage);
                Invoke(callback, new object[] { message });
            }
            else
            {
                LabelMessage.Text = message;
            }
        }

        private void DialogPreviewLoad(object sender, EventArgs e) {

            //Initialize labels
            LabelTotalBytesToCopy.Text = "";
            LabelCopyMessage.Text = "";
            LabelSkipMessage.Text = "";

            if (ShouldProcessAll) {
                LabelDestinationPath.Text = LabelSourcePath.Text = Resources.TEXT_MULTIPLE_PAIRS;
                Text = Resources.TEXT_PREVIEW_FOR_MULTIPLE_PAIRS;
            } else {
                LabelSourcePath.Text = FolderPair.LeftFolder;
                LabelDestinationPath.Text = FolderPair.RightFolder;
                Text = string.Format(Resources.TEXT_PREVIEW_FOR, FolderPair.FolderPairName);
            }

            OperationFilter.SelectedIndex = 0;
            InitializeResultsListView();
            InitializeOperationsListView();
            ProgressBar.Style = ProgressBarStyle.Marquee;
            PreviewWorker.RunWorkerAsync();
        }

        

         private void InitializeStatistics()
         {
             _deletedFolder = new CountHolder();
             _deletedFile = new CountHolder();
             _overwritten = new CountHolder();
             _renamed = new CountHolder();
             _createdFolder = new CountHolder();
             _createdFile = new CountHolder();
             _allOperations = new CountHolder();
         }

       private void InitializeOperationsListView() {
            ListViewOperations.Clear();
            ListViewOperations.Columns.Add("Active", 50);
            ListViewOperations.Columns.Add("Operation", 80);
            ListViewOperations.Columns.Add("Source File", 120);
            ListViewOperations.Columns.Add("Source Path", 120);
            ListViewOperations.Columns.Add("Last Modified", 120);
            ListViewOperations.Columns.Add("Target File", 120);
            ListViewOperations.Columns.Add("Target Path", 120);
            ListViewOperations.Columns.Add("Last Modified", 120);
            ListViewOperations.Columns.Add("Bytes to Copy", 100);

            ListViewOperations.CheckBoxes = true;

            //TODO: Loop through the operations here

            ListViewOperations.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            ListViewOperations.View = View.Details;
        }

        delegate void UpdateOperationListViewCallback(string operation, string sourceFile, string sourcePath,string sourceLastModified, string targetFile, string targetPath,string targetLastModified,string bytesToCopy);

        public void UpdateOperationListView(string operation, string sourceFile, string sourcePath, string sourceLastModified ,string targetFile, string targetPath,string targetLastModified,string bytesToCopy) {
            ListViewItem operationItem = new ListViewItem();
            operationItem.Checked = true;
            operationItem.SubItems.Add(operation);
            operationItem.SubItems.Add(sourceFile);
            operationItem.SubItems.Add(sourcePath);
            operationItem.SubItems.Add(sourceLastModified); //Last Modified
            operationItem.SubItems.Add(targetFile);
            operationItem.SubItems.Add(targetPath);
            operationItem.SubItems.Add(targetLastModified); //Last Modified
            operationItem.SubItems.Add(bytesToCopy); //Bytes
            if (ListViewOperations.InvokeRequired) {
                UpdateOperationListViewCallback operationListCallback = new UpdateOperationListViewCallback(UpdateOperationListView);
                Invoke(operationListCallback,new object[]{operation,sourceFile,sourcePath,sourceLastModified,targetFile,targetPath,targetLastModified,bytesToCopy});

            } else {
                ListViewOperations.Items.Add(operationItem);
            }

            
        }

        

        private void InitializeResultsListView() {
            ListViewResults.Clear();
            ListViewResults.Columns.Add("Operations", 130);
            ListViewResults.Columns.Add("Count", 60);

            ListViewItem itemDeletedFolderCount = new ListViewItem("Deleted Folder");
            itemDeletedFolderCount.SubItems.Add(_deletedFolder.Success.ToString());

            ListViewItem itemDeletedFileCount = new ListViewItem("Deleted");
            itemDeletedFileCount.SubItems.Add(_deletedFile.Success.ToString());

            ListViewItem itemOverwrittenCount = new ListViewItem("Overwritten");
            itemOverwrittenCount.SubItems.Add(_overwritten.Success.ToString());

            ListViewItem itemRenamedCount = new ListViewItem("Rename");
            itemRenamedCount.SubItems.Add(_renamed.Success.ToString());

            ListViewItem itemNewFileCount = new ListViewItem("New");
            itemNewFileCount.SubItems.Add(_createdFile.Success.ToString());

            ListViewItem itemNewFolderCount = new ListViewItem("Create Folder");
            itemNewFolderCount.SubItems.Add(_createdFolder.Success.ToString());

            ListViewItem itemSpacer = new ListViewItem(" ");
            itemSpacer.SubItems.Add("------");

            ListViewItem itemAllOperations = new ListViewItem("All Operations");
            _allOperations.Add(new List<CountHolder>{_deletedFolder,
                                                    _deletedFile,
                                                    _overwritten,
                                                    _renamed,
                                                    _createdFile,
                                                    _createdFolder});

            itemAllOperations.SubItems.Add(_allOperations.Success.ToString());

            ListViewResults.Items.Add(itemDeletedFolderCount);
            ListViewResults.Items.Add(itemDeletedFileCount);
            ListViewResults.Items.Add(itemOverwrittenCount);
            ListViewResults.Items.Add(itemRenamedCount);
            ListViewResults.Items.Add(itemNewFileCount);
            ListViewResults.Items.Add(itemNewFolderCount);
            ListViewResults.Items.Add(itemSpacer);
            ListViewResults.Items.Add(itemAllOperations);

            ListViewResults.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            ListViewResults.View = View.Details;
            ListViewResults.Scrollable = false;
        }

        private void CallBackClose(object sender, EventArgs e) {
            Close();
        }

        private void CallBackStop(object sender, EventArgs e) {
            //TODO
            Console.WriteLine("TODO : DialogPreview.CallBackStop");
        }

        private void CallBackRun(object sender, EventArgs e) {
            
            if (ShouldProcessAll) {
                DialogSyncResult dialogRun = new DialogSyncResult
                                                 {
                                                     DoPreviewMode = false,
                                                     ShouldProcess = true,
                                                     ShouldProcessAll = true,
                                                     FolderPairs = FolderPairs,
                                                     FileSynchronizer = FileSynchronizer
                                                 };
                Hide();
                dialogRun.ShowDialog(Program.MainWindow);
            } else {
                DialogSyncResult dialogRun = new DialogSyncResult
                                                 {
                                                     DoPreviewMode = false,
                                                     ShouldProcess = true,
                                                     FolderPair = FolderPair,
                                                     FileSynchronizer = FileSynchronizer
                                                 };
                Hide();
                dialogRun.ShowDialog(Program.MainWindow);
            }
        }

        private void DialogPreviewResized(object sender, EventArgs e) {
            //InitializeTabView(TabMain.SelectedTab);
        }

        /// <summary>
        /// The default background workder callback
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DoPreview(object sender, DoWorkEventArgs e) {
            _applyingChangesEventArguments = new List<FileSyncApplyingChangesEventArgs>();
            FileSynchronizer = ShouldProcessAll ? new FileSynchronization(FolderPairs, true) : new FileSynchronization(FolderPair, true);
            FileSynchronizer.VerboseEnabled = false;
            FileSynchronizer.DestinationFileApplyingChanges += FileSynchronizerDestinationFileApplyingChanges;
            FileSynchronizer.SynchronizationMessages += new FileSyncMessageEventHandler(PreviewMessages);
            FileSynchronizer.Synchronize();
        }

        private void PreviewMessages(object sender, FileSyncMessageEventArgs e)
        {
            SetStatusMessage(e.Message);
        }
        

        void FileSynchronizerDestinationFileApplyingChanges(object sender, FileSyncApplyingChangesEventArgs e) {
            //Console.WriteLine(string.Format("TARGET FILE = {0}", e.TargetFile));
            //UpdateOperationListView(e.ChangeType,e.SourceFile,e.SourcePath,"",e.TargetFile,e.TargetPath,e.TargetLastModified,e.BytesToCopy);
            //UpdateOperationListView(e.ChangeTypeDisplayString, e.NewFileData.Name, e.SourcePath, "", e.NewFileData.Name,
            //                        e.DestinationPath, e.LastModified, e.TotalBytesToCopy.ToString());
            _applyingChangesEventArguments.Add(e);
        }

        private void PreviewProgressChanged(object sender, ProgressChangedEventArgs e) {
            
        }

        private void PreviewCompleted(object sender, RunWorkerCompletedEventArgs e) {
            ProgressBar.Style = ProgressBarStyle.Continuous;
            ProgressBar.Value = 100;
            ButtonClose.Enabled = true;
            _renamed.Success = FileSynchronizer.TotalRenamedFiles;
            _createdFolder.Success = FileSynchronizer.TotalCreatedFolders;
            _createdFile.Success = FileSynchronizer.TotalCreatedFiles;
            _overwritten.Success = FileSynchronizer.TotalOverWrittenFiles;
            _deletedFolder.Success = FileSynchronizer.TotalDeletedFolders;
            _deletedFile.Success = FileSynchronizer.TotalDeletedFiles;
            InitializeResultsListView();
            LabelSkipMessage.Text = string.Format(Resources.TEXT_FOUND_FILES_THAT_DID_NOT_REQUIRE_ACTION, FileSynchronizer.TotalSkippedFiles);
            LabelTotalBytesToCopy.Text = string.Format(Resources.TEXT_TOTAL_BYTES_TO_COPY, FileSynchronizer.TotalBytesToCopy);
            ButtonRun.Enabled = true;

            //Display lists of files and folders to be changed
            
            foreach (FileSyncApplyingChangesEventArgs arg in _applyingChangesEventArguments)
            {
                UpdateOperationListView(arg.ChangeTypeDisplayString, arg.NewFileData.Name, arg.SourcePath, "", arg.NewFileData.Name,
                                        arg.DestinationPath, arg.LastModified, arg.TotalBytesToCopy.ToString());
            }

            Console.WriteLine("LOG : Preview Worker Done");
        }

        

    }
}
