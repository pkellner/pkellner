﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

using FileSyncUtility;
using DataAccess.Enums;

using SyncToyDesktopApp.Properties;

using Welemski.Utility;

namespace SyncToyDesktopApp {
    public partial class DialogChangeAction : Form {

        private ResourceManager _resourceManager;

        public DialogChangeAction() {
            InitializeComponent();
            _resourceManager = new ResourceManager("SyncToyDesktopApp.Properties.Resources", Assembly.GetExecutingAssembly());
        }


        private void DialogChangeActionLoad(object sender, EventArgs e) {
            Text = string.Format(Resources.TEXT_CHANGE_ACTION_FOR, FolderPair.FolderPairName);

            
            int actionTypeId = FolderPair.FolderPairActionTypeId;
            switch(actionTypeId){
                case (int)FolderPairActionTypeEnum.Synchronize :
                    OptionSynchronize.Checked = true;
                    break;
                case (int)FolderPairActionTypeEnum.Contribute:
                    OptionContribute.Checked = true;
                    break;
                case (int)FolderPairActionTypeEnum.Echo:
                    OptionEcho.Checked = true;
                    break;
                default :
                    OptionSynchronize.Checked = true;
                    break;
            }

        }

        /// <summary>
        /// Required. Must be set during every call this window
        /// </summary>
        public FileSyncPairInfo FolderPair { get; set; }

        /// <summary>
        /// Required. Must be set during every call this window
        /// </summary>
        public FileSyncPairManager PairManager { get; set; }


        private void ShowSynchronizeToolTip(object sender, EventArgs e) {
            ToolTip toolTip = new ToolTip();
            string explanation = _resourceManager.GetString("SYNC_INFO_SYNCHRONIZE");
            toolTip.SetToolTip(OptionSynchronize, explanation);
        }

        private void ShowEchoToolTip(object sender, EventArgs e) {
            ToolTip toolTip = new ToolTip();
            string explanation = _resourceManager.GetString("SYNC_INFO_ECHO");
            toolTip.SetToolTip(OptionEcho, explanation);
        }

        private void ShowContributeToolTip(object sender, EventArgs e) {
            ToolTip toolTip = new ToolTip();
            string explanation = _resourceManager.GetString("SYNC_INFO_CONTRIBUTE");
            toolTip.SetToolTip(OptionContribute, explanation);
        }

        private void SelectSynchronize(object sender, EventArgs e) {
            string explanation = _resourceManager.GetString("SYNC_INFO_SYNCHRONIZE");
            LabelShortExplanation.Text = explanation;
            FolderPair.FolderPairActionTypeId = (int)FolderPairActionTypeEnum.Synchronize;
            //Console.WriteLine("SYNCHRONIZE");
        }

        private void SelectEcho(object sender, EventArgs e) {
            string explanation = _resourceManager.GetString("SYNC_INFO_ECHO");
            LabelShortExplanation.Text = explanation;
            FolderPair.FolderPairActionTypeId = (int)FolderPairActionTypeEnum.Echo;
            //Console.WriteLine("ECho");
        }

        private void SelectContribute(object sender, EventArgs e) {
            string explanation = _resourceManager.GetString("SYNC_INFO_CONTRIBUTE");
            LabelShortExplanation.Text = explanation;
            FolderPair.FolderPairActionTypeId = (int)FolderPairActionTypeEnum.Contribute;
            //Console.WriteLine("CONTRIBUTE");
        }

        private void CallBackOk(object sender, EventArgs e) {
            if (PairManager.UpdateFolderPairNamed(FolderPair.FolderPairName, FolderPair)) {
                //DO NOTHING
            } else {
                Console.WriteLine("ERROR : FAILED TO UPDATE FOLDER PAIR'S ACTION TYPE");
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private void CallBackCancel(object sender, EventArgs e) {
            DialogResult = DialogResult.Cancel;
            Close();
        }
        
    }
}
