﻿namespace SyncToyDesktopApp {
    partial class DialogCustomerFeedbackOptions {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.PanelDefault = new System.Windows.Forms.Panel();
            this.LabelCEIP = new System.Windows.Forms.Label();
            this.LinkToTheProgramDocument = new System.Windows.Forms.LinkLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.OptionToNotParticipate = new System.Windows.Forms.RadioButton();
            this.OptionToParticipate = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ButtonOk = new System.Windows.Forms.Button();
            this.ButtonCloseCustomerFeedbackOptions = new System.Windows.Forms.Button();
            this.PanelDefault.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelDefault
            // 
            this.PanelDefault.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelDefault.BackColor = System.Drawing.Color.White;
            this.PanelDefault.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PanelDefault.Controls.Add(this.LabelCEIP);
            this.PanelDefault.Controls.Add(this.LinkToTheProgramDocument);
            this.PanelDefault.Controls.Add(this.groupBox1);
            this.PanelDefault.Controls.Add(this.label1);
            this.PanelDefault.Controls.Add(this.shapeContainer1);
            this.PanelDefault.Location = new System.Drawing.Point(5, 6);
            this.PanelDefault.Name = "PanelDefault";
            this.PanelDefault.Size = new System.Drawing.Size(458, 421);
            this.PanelDefault.TabIndex = 0;
            // 
            // LabelCEIP
            // 
            this.LabelCEIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCEIP.Location = new System.Drawing.Point(13, 52);
            this.LabelCEIP.Name = "LabelCEIP";
            this.LabelCEIP.Size = new System.Drawing.Size(436, 143);
            this.LabelCEIP.TabIndex = 5;
            this.LabelCEIP.Text = "<some text>";
            // 
            // LinkToTheProgramDocument
            // 
            this.LinkToTheProgramDocument.AutoSize = true;
            this.LinkToTheProgramDocument.Location = new System.Drawing.Point(17, 376);
            this.LinkToTheProgramDocument.Name = "LinkToTheProgramDocument";
            this.LinkToTheProgramDocument.Size = new System.Drawing.Size(316, 13);
            this.LinkToTheProgramDocument.TabIndex = 4;
            this.LinkToTheProgramDocument.TabStop = true;
            this.LinkToTheProgramDocument.Text = "Read more about the Customer Experience Improvement Program";
            this.LinkToTheProgramDocument.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LoadProgramDocument);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.OptionToNotParticipate);
            this.groupBox1.Controls.Add(this.OptionToParticipate);
            this.groupBox1.Location = new System.Drawing.Point(16, 274);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(430, 96);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Settings";
            // 
            // OptionToNotParticipate
            // 
            this.OptionToNotParticipate.AutoSize = true;
            this.OptionToNotParticipate.Location = new System.Drawing.Point(18, 58);
            this.OptionToNotParticipate.Name = "OptionToNotParticipate";
            this.OptionToNotParticipate.Size = new System.Drawing.Size(165, 17);
            this.OptionToNotParticipate.TabIndex = 1;
            this.OptionToNotParticipate.TabStop = true;
            this.OptionToNotParticipate.Text = "No, I don\'t wish to participate.";
            this.OptionToNotParticipate.UseVisualStyleBackColor = true;
            // 
            // OptionToParticipate
            // 
            this.OptionToParticipate.AutoSize = true;
            this.OptionToParticipate.Location = new System.Drawing.Point(18, 22);
            this.OptionToParticipate.Name = "OptionToParticipate";
            this.OptionToParticipate.Size = new System.Drawing.Size(363, 30);
            this.OptionToParticipate.TabIndex = 0;
            this.OptionToParticipate.TabStop = true;
            this.OptionToParticipate.Text = "Yes, I am willing to participate anonymously in the Customer Experience \r\nImprove" +
                "ment Program. (Recommended)";
            this.OptionToParticipate.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Experience Improvement Program";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(456, 419);
            this.shapeContainer1.TabIndex = 1;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lineShape1.BorderWidth = 2;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 16;
            this.lineShape1.X2 = 449;
            this.lineShape1.Y1 = 33;
            this.lineShape1.Y2 = 33;
            // 
            // ButtonOk
            // 
            this.ButtonOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonOk.Location = new System.Drawing.Point(301, 443);
            this.ButtonOk.Name = "ButtonOk";
            this.ButtonOk.Size = new System.Drawing.Size(75, 23);
            this.ButtonOk.TabIndex = 7;
            this.ButtonOk.Text = "OK";
            this.ButtonOk.UseVisualStyleBackColor = true;
            this.ButtonOk.Click += new System.EventHandler(this.CallBackOk);
            // 
            // ButtonCloseCustomerFeedbackOptions
            // 
            this.ButtonCloseCustomerFeedbackOptions.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonCloseCustomerFeedbackOptions.Location = new System.Drawing.Point(382, 443);
            this.ButtonCloseCustomerFeedbackOptions.Name = "ButtonCloseCustomerFeedbackOptions";
            this.ButtonCloseCustomerFeedbackOptions.Size = new System.Drawing.Size(75, 23);
            this.ButtonCloseCustomerFeedbackOptions.TabIndex = 6;
            this.ButtonCloseCustomerFeedbackOptions.Text = "Cancel";
            this.ButtonCloseCustomerFeedbackOptions.UseVisualStyleBackColor = true;
            this.ButtonCloseCustomerFeedbackOptions.Click += new System.EventHandler(this.CallBackCancel);
            // 
            // DialogCustomerFeedbackOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 478);
            this.Controls.Add(this.ButtonOk);
            this.Controls.Add(this.PanelDefault);
            this.Controls.Add(this.ButtonCloseCustomerFeedbackOptions);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(485, 516);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(485, 516);
            this.Name = "DialogCustomerFeedbackOptions";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CRSyncFiles Customer Feedback Options";
            this.PanelDefault.ResumeLayout(false);
            this.PanelDefault.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelDefault;
        private System.Windows.Forms.Label label1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton OptionToParticipate;
        private System.Windows.Forms.RadioButton OptionToNotParticipate;
        private System.Windows.Forms.LinkLabel LinkToTheProgramDocument;
        private System.Windows.Forms.Label LabelCEIP;
        private System.Windows.Forms.Button ButtonOk;
        private System.Windows.Forms.Button ButtonCloseCustomerFeedbackOptions;
    }
}