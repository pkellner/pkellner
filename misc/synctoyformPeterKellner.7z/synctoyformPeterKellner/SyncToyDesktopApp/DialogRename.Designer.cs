﻿namespace SyncToyDesktopApp {
    partial class DialogRename {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.LabelRename = new System.Windows.Forms.Label();
            this.TextBoxFolderPairName = new System.Windows.Forms.TextBox();
            this.ButtonCancel = new System.Windows.Forms.Button();
            this.ButtonOK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LabelRename
            // 
            this.LabelRename.AutoSize = true;
            this.LabelRename.Location = new System.Drawing.Point(12, 27);
            this.LabelRename.Name = "LabelRename";
            this.LabelRename.Size = new System.Drawing.Size(99, 13);
            this.LabelRename.TabIndex = 0;
            this.LabelRename.Text = "Rename folder pair:";
            // 
            // TextBoxFolderPairName
            // 
            this.TextBoxFolderPairName.Location = new System.Drawing.Point(15, 44);
            this.TextBoxFolderPairName.Name = "TextBoxFolderPairName";
            this.TextBoxFolderPairName.Size = new System.Drawing.Size(224, 20);
            this.TextBoxFolderPairName.TabIndex = 1;
            // 
            // ButtonCancel
            // 
            this.ButtonCancel.Location = new System.Drawing.Point(163, 69);
            this.ButtonCancel.Name = "ButtonCancel";
            this.ButtonCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonCancel.TabIndex = 2;
            this.ButtonCancel.Text = "Cancel";
            this.ButtonCancel.UseVisualStyleBackColor = true;
            this.ButtonCancel.Click += new System.EventHandler(this.CancelRename);
            // 
            // ButtonOK
            // 
            this.ButtonOK.Location = new System.Drawing.Point(82, 69);
            this.ButtonOK.Name = "ButtonOK";
            this.ButtonOK.Size = new System.Drawing.Size(75, 23);
            this.ButtonOK.TabIndex = 3;
            this.ButtonOK.Text = "OK";
            this.ButtonOK.UseVisualStyleBackColor = true;
            this.ButtonOK.Click += new System.EventHandler(this.RenameFolderPair);
            // 
            // DialogRename
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(251, 104);
            this.Controls.Add(this.ButtonOK);
            this.Controls.Add(this.ButtonCancel);
            this.Controls.Add(this.TextBoxFolderPairName);
            this.Controls.Add(this.LabelRename);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(267, 142);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(267, 142);
            this.Name = "DialogRename";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rename";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelRename;
        private System.Windows.Forms.TextBox TextBoxFolderPairName;
        private System.Windows.Forms.Button ButtonCancel;
        private System.Windows.Forms.Button ButtonOK;
    }
}