﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

using DataAccess.Enums;
using FileSyncUtility;
using SyncToyDesktopApp.Properties;
using Welemski.Utility;

namespace SyncToyDesktopApp
{
    public partial class Main : Form
    {
        public DialogSyncToyLogs DialogSyncToyLogs;
        public DialogFolderPairWizard DialogFolderPairWizard;
        public DialogCustomerFeedbackOptions DialogCutomerFeedbackOptions;
        public DialogSyncResult DialogSyncToyResult;

        private ResourceManager _resourceManager;
        private List<FileSyncPairInfo> _availableFolderPairs;
        private FileSyncPairManager _pairManager;
        private Brush _brushFolderPairs;

        private string _fileName;

        const string FolderPairDefaultLabel = "All Folder Pairs";

        public Main()
        {
            InitializeComponent();
            
        }

        private void MainLoad(object sender, EventArgs e)
        {
            _resourceManager = new ResourceManager("SyncToyDesktopApp.Properties.Resources", Assembly.GetExecutingAssembly());
            
            //TODO : the filename should point to the specified file name in the user settings
            _fileName = "folderpairs.db";
            _pairManager = new FileSyncPairManager(_fileName);

            //Initialize application name
            Text = Resources.TEXT_APPLICATION_NAME;
            
            InitializeFolderPairs();
            InitializeDefaultPages();
            InitializeDefaultActions();
        }

        //------------------------ HELPER METHODS ------------------------------

        private void ShowDefaultPage()
        {
            TabPageDefault.Show();
            TabPageAllFolderPairs.Hide();            
            TabPageFolderPairSettings.Hide();
            PagesDefault.SelectTab(TabPageDefault);

            //Initialize texts
            LabelLaunchTitle.Text = Resources.TEXT_WELCOME_TITLE;
        }

        private void ShowFolderPairSettings()
        {
            TabPageFolderPairSettings.Show();
            TabPageAllFolderPairs.Hide();
            TabPageDefault.Hide();
            PagesDefault.SelectTab(TabPageFolderPairSettings);
        }

        private void ShowAllFolderPairs()
        {
            TabPageAllFolderPairs.Show();
            TabPageDefault.Hide();
            TabPageFolderPairSettings.Hide();
            PagesDefault.SelectTab(TabPageAllFolderPairs);
        }

        //This ensures availability of default action when folder pairs list is empty
        private void InitializeDefaultActions() {
            if(ListOfFolderPairs.Items.Count >= 2 ){
                ButtonRenameFolderPair.Enabled = true;
                ButtonDeleteFolderPair.Enabled = true;
                ButtonCreateNewFolderPair.Enabled = true;
                ButtonPreview.Enabled = true;
                ButtonRun.Enabled = true;
                LoadFolderPairNamed((string)ListOfFolderPairs.SelectedItem);
                ListOfFolderPairs.Show();
                ListOfFolderPairs.SetSelected(0, true);
                ListOfFolderPairs.Select();
                ListOfFolderPairs.Focus();
             }else{
                ButtonRenameFolderPair.Enabled = false;
                ButtonDeleteFolderPair.Enabled = false;
                ButtonCreateNewFolderPair.Enabled = true;
                ButtonPreview.Enabled = false;
                ButtonRun.Enabled = false;
                ShowDefaultPage();
                ListOfFolderPairs.Hide();
            }
            //TODO
        }

        //This hides the tabs of our default pages from displaying
        private void InitializeDefaultPages() {
            RectangleF rect = new RectangleF(TabPageDefault.Left,
                                            TabPageDefault.Top,
                                            TabPageDefault.Width,
                                            TabPageDefault.Height);

            PagesDefault.Region = new Region(rect);
            
                                            
        }

        private void InitializeDefaultPages(TabPage pageReference) {
            RectangleF rect = new RectangleF(pageReference.Left,
                                            pageReference.Top,
                                            pageReference.Width,
                                            pageReference.Height);

            PagesDefault.Region = new Region(rect);
        }


        /// <summary>
        /// Initializes and updates the list of available folder pairs.
        /// </summary>
        private void InitializeFolderPairs()
        {
            
            _availableFolderPairs = _pairManager.AvailableFolderPairs();
            ListOfFolderPairs.Items.Clear();
            
            foreach (var pairItem in _availableFolderPairs)
            {
                Console.WriteLine("Adding {0}", pairItem.FolderPairName);
                ListOfFolderPairs.Items.Add(pairItem.FolderPairName);
                ListOfFolderPairs.Refresh();
            }

            if (_availableFolderPairs.Count >= 1)
            {
                if(_availableFolderPairs.Count >= 10){
                    ListOfFolderPairs.Items.Insert(0, FolderPairDefaultLabel);
                }else{
                    ListOfFolderPairs.Items.Insert(_availableFolderPairs.Count,FolderPairDefaultLabel);
                }
            }

        }

        /// <summary>
        /// Loads the information about the folder pair.
        /// Also perform a preselect on the current folder.
        /// </summary>
        /// <param name="aName">The name of the folder pair</param>
        private void LoadFolderPairNamed(string aName)
        {
            LabelFolderPairName.Text = aName;
            if(_pairManager.HasFolderPairNamed(aName)){
                LabelSourcePath.Text = _pairManager.CurrentFolderPair.LeftFolder;
                LabelDestinationPath.Text = _pairManager.CurrentFolderPair.RightFolder;
                LabelSyncType.Text = ((FolderPairActionTypeEnum)_pairManager.CurrentFolderPair.FolderPairActionTypeId).ToString();
                string lastRun = _pairManager.CurrentFolderPair.LastRun;
                if ((lastRun == null) || (lastRun.Length == 0) || (lastRun == "")) {
                    LabelLastRun.Text = Resources.TEXT_NOT_RUN_YET;
                } else {
                    LabelLastRun.Text = string.Format("Last run: {0}", lastRun);
                }

                //Let's preselect it for the user
                int folderPairIndex = ListOfFolderPairs.Items.IndexOf(aName);
                ListOfFolderPairs.SelectedIndex = folderPairIndex;
            }
        }


        private void InitializeAllFolderPairsListView()
        {
            ListViewAllFolderPairs.Clear();
            ListViewAllFolderPairs.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            ListViewAllFolderPairs.View = View.Details;
            ListViewAllFolderPairs.Columns.Add("Active",150);
            ListViewAllFolderPairs.Columns.Add("Name",105);
            ListViewAllFolderPairs.Columns.Add("Left Folder",150);
            ListViewAllFolderPairs.Columns.Add("Right Folder",150);
            ListViewAllFolderPairs.CheckBoxes = true;
            

            List<FileSyncPairInfo> pairItems = _pairManager.AvailableFolderPairs();
            foreach(var pairItem in pairItems){
                ListViewItem viewItem = new ListViewItem();
                viewItem.Checked = true;
                viewItem.SubItems.Add(pairItem.FolderPairName);
                viewItem.SubItems.Add(pairItem.LeftFolder);
                viewItem.SubItems.Add(pairItem.RightFolder);
                ListViewAllFolderPairs.Items.Add(viewItem);
            }
            
        }


        //------------------------ CALL BACKS ----------------------------------

        //Performs custom draws for our folder pairs list
        private void CallBackDrawItemForListOfFolderPairs(Object sender,DrawItemEventArgs eventArgs)
        {
            ListBox listBox = (ListBox) sender;
            _brushFolderPairs = Brushes.DarkBlue;

            Rectangle itemBoundingBox = eventArgs.Bounds;
            StringFormat stringFormat = new StringFormat();

            itemBoundingBox.Offset(0, 5);
            eventArgs.DrawBackground();

            if ((eventArgs.State & DrawItemState.Selected) == DrawItemState.Selected)
            {
                _brushFolderPairs = Brushes.AliceBlue;
            }
            else
            {
                _brushFolderPairs = Brushes.DarkBlue;
            }

            eventArgs.Graphics.DrawString(ListOfFolderPairs.Items[eventArgs.Index].ToString(),
                                          eventArgs.Font,
                                          _brushFolderPairs,
                                          itemBoundingBox,
                                          stringFormat);
            
        }

        void CallBackExit(object sender, EventArgs e){
            Application.Exit();
        }

        private void CallBackFolderPairSelection(object sender, EventArgs e) {
            if (ListOfFolderPairs.SelectedItem.ToString() == FolderPairDefaultLabel) {
                ShowAllFolderPairs();
                ButtonDeleteFolderPair.Enabled = false;
                ButtonRenameFolderPair.Enabled = false;
                ButtonPreview.Text = Resources.TEXT_PREVIEW_ALL;
                ButtonRun.Text = Resources.TEXT_RUN_ALL;
                ButtonRun.Enabled = true;
                ButtonPreview.Enabled = true;
                InitializeAllFolderPairsListView();
            } else {
                LoadFolderPairNamed((string)ListOfFolderPairs.SelectedItem);
                ShowFolderPairSettings();
                ButtonDeleteFolderPair.Enabled = true;
                ButtonRenameFolderPair.Enabled = true;
                ButtonPreview.Text = Resources.TEXT_PREVIEW;
                ButtonRun.Text = Resources.TEXT_RUN;
                ButtonRun.Enabled = true;
                ButtonPreview.Enabled = true;
            }
        }

        private void CallBackViewLog(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            DialogSyncToyLogs = new DialogSyncToyLogs();
            DialogSyncToyLogs.ShowDialog();
            Cursor = Cursors.Arrow;
        }

        private void CallBackSyncToyHelp(object sender, EventArgs e) {
            //TODO
            Console.WriteLine("TODO");
        }

        private void CallBackScheduleSyncToy(object sender, EventArgs e) {
            //TODO
            Console.WriteLine("TODO");
        }

        private void CallBackForum(object sender, EventArgs e) {
            //TODO
            Console.WriteLine("TODO");
        }

        private void CallBackCustomerFeedbackOptions(object sender, EventArgs e) {
            Console.WriteLine("TODO");
            DialogCutomerFeedbackOptions = new DialogCustomerFeedbackOptions();
            DialogCutomerFeedbackOptions.ShowDialog();
        }

        private void CallBackAbout(object sender, EventArgs e) {
            string aboutThisApp = _resourceManager.GetString("TEXT_ABOUT");
            string titleAbout = _resourceManager.GetString("TITLE_ABOUT");
            MessageBox.Show(aboutThisApp, titleAbout, MessageBoxButtons.OK, MessageBoxIcon.Information); 
        }

        private void CallBackRenameFolderPair(object sender, EventArgs e) {
            string currentFolderName = ListOfFolderPairs.SelectedItem as string;
            DialogRename dialogRename = new DialogRename();
            dialogRename.FolderPairName = currentFolderName;
            dialogRename.FolderDatabaseName = _fileName;
            DialogResult dialogRenameResult = dialogRename.ShowDialog(this);
            if(dialogRenameResult == DialogResult.OK){
                string newName = dialogRename.FolderPairName;
                if (currentFolderName == newName) {
                    //DO NOTHING
                } else {
                    if (_pairManager.RenameFolderPair(currentFolderName, newName)) {
                        InitializeFolderPairs();
                        InitializeDefaultActions();
                        LoadFolderPairNamed(newName);
                    } else {
                        throw new ApplicationException(string.Format("Failed to rename folder pair named {0} to {1}",currentFolderName,newName));
                    }
                }
            }
        }

        private void CallBackDeleteFolderPair(object sender, EventArgs e) {
            string currentFolderPairName = (string)ListOfFolderPairs.SelectedItem;
            DialogResult deleteResult = MessageBox.Show(string.Format("Are you sure you want to delete the folder pair named \"{0}\"?", currentFolderPairName),Resources.TEXT_APPLICATION_NAME,MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            Console.WriteLine(string.Format("CURRENT DELETE BUTTON {0}", deleteResult));
            if(deleteResult == DialogResult.Yes){
                Console.WriteLine(string.Format("REMOVING FOLDER PAIR NAMED {0}", currentFolderPairName));
                if (_pairManager.RemoveFolderPairNamed(currentFolderPairName)) {
                    Console.WriteLine("FOLDER PAIR DELETION SUCCESSFUL");
                } else {
                    Console.WriteLine("FOLDER PAIR DELETION FAILED");
                }
                InitializeFolderPairs();
                InitializeDefaultActions();
            }
        }

        private void CallBackCreateNewFolderPair(object sender, EventArgs e) {
            DialogFolderPairWizard = new DialogFolderPairWizard();
            DialogFolderPairWizard.PairManager = _pairManager;
            System.Windows.Forms.DialogResult folderPairWizardResult = DialogFolderPairWizard.ShowDialog();
            if (folderPairWizardResult == DialogResult.OK) {
                FileSyncPairInfo currentFolderPair = DialogFolderPairWizard.FolderPair;
                _availableFolderPairs.Add(currentFolderPair);
                _pairManager.UpdateFolderPairs(_availableFolderPairs);
                ListOfFolderPairs.Show();
                InitializeFolderPairs();
                LoadFolderPairNamed(currentFolderPair.FolderPairName);
                Console.WriteLine("CURRENT ITEM {0}", currentFolderPair.FolderPairName);
            }
            Console.WriteLine("{0}", folderPairWizardResult.ToString());
        }

        private void CallBackPreview(object sender, EventArgs e) {
            
            Button aButton = sender as Button;
            if (aButton.Text == Resources.TEXT_PREVIEW_ALL) {
                DialogPreview runPreview = new DialogPreview(_pairManager.AvailableFolderPairs());
                runPreview.ShowDialog();
            } else {
                string selectedFolderPair = ListOfFolderPairs.SelectedItem as string;
                if(_pairManager.HasFolderPairNamed(selectedFolderPair)){
                    DialogPreview runPreview = new DialogPreview(_pairManager.CurrentFolderPair);
                    runPreview.ShowDialog();
                }else{
                    MessageBox.Show(Resources.TEXT_NO_FOLDER_PAIR_ASSOCIATED_WITH_THAT_NAME,Resources.TEXT_APPLICATION_NAME,MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }

        }

        private void CallBackRun(object sender, EventArgs e) {
            Button eventSender = (Button)sender;
            if (eventSender.Text == Resources.TEXT_RUN)
            {
                string currentFolderPairItem = (string)ListOfFolderPairs.SelectedItem;
                if (_pairManager.HasFolderPairNamed(currentFolderPairItem))
                {
                    FileSyncPairInfo currentFolderPair = _pairManager.CurrentFolderPair;
                    _pairManager.UpdateLastRunForFolderPairNamed(DateTime.Now, currentFolderPair.FolderPairName);
                    DialogSyncToyResult = new DialogSyncResult
                                              {
                                                  FolderPair = currentFolderPair,
                                                  DoPreviewMode = true,
                                                  ShouldProcess = true
                                              };
                    
                    DialogSyncToyResult.ShowDialog(this);
                    InitializeFolderPairs();
                    ListOfFolderPairs.SelectedItem = currentFolderPairItem;
                }
                else
                {
                    MessageBox.Show(Resources.TEXT_SELECTED_PAIR_DOES_NOT_EXISTS);
                }
            }
            else if (eventSender.Text == Resources.TEXT_RUN_ALL)
            {
                List<FileSyncPairInfo> folderPairsToProcess = new List<FileSyncPairInfo>();
                List<FileSyncPairInfo> availableFolderPairs = _pairManager.AvailableFolderPairs();
                ListView.ListViewItemCollection viewItems =  ListViewAllFolderPairs.Items;
                for (int index = 0; index < viewItems.Count; index++)
                {
                    ListViewItem currentItem = viewItems[index];
                    if(currentItem.Checked){
                        FileSyncPairInfo folderPair = availableFolderPairs[index];
                        folderPairsToProcess.Add(folderPair);
                        _pairManager.UpdateLastRunForFolderPairNamed(DateTime.Now, folderPair.FolderPairName);
                    }
                }

                DialogSyncToyResult = new DialogSyncResult
                                          {
                                              FolderPairs = folderPairsToProcess,
                                              DoPreviewMode = true,
                                              ShouldProcess = true,
                                              ShouldProcessAll = true
                                          };
                DialogSyncToyResult.ShowDialog(this);

            }
            else
            {
                DialogSyncToyResult = new DialogSyncResult();
                DialogSyncToyResult.ShowDialog(this);
            }
        }

        private void ChangeAction(object sender, LinkLabelLinkClickedEventArgs e) {
            string selectedFolderPairName = ListOfFolderPairs.SelectedItem as string;
            if (_pairManager.HasFolderPairNamed(selectedFolderPairName)) {
                FileSyncPairInfo selectedFolderPair = _pairManager.CurrentFolderPair;
                DialogChangeAction changeAction = new DialogChangeAction();
                changeAction.FolderPair = selectedFolderPair;
                changeAction.PairManager = _pairManager;
                DialogResult changeResult = changeAction.ShowDialog();
                if (changeResult == DialogResult.OK) {
                    InitializeFolderPairs();
                    ListOfFolderPairs.SelectedItem = selectedFolderPairName;
                    LoadFolderPairNamed(selectedFolderPairName);
                }
                
            } else {
                Console.WriteLine(string.Format("WARNING: SELECTED FOLDER PAIR NAMED {0} NOT FOUND!", selectedFolderPairName));
            }
        }

        private void MainWindowResized(object sender, EventArgs e) {
            InitializeDefaultPages(PagesDefault.SelectedTab);
        }

        private void CallBackChangeOptions(object sender, LinkLabelLinkClickedEventArgs e) {
            string currentPairName = ListOfFolderPairs.SelectedItem as string;
            if(_pairManager.HasFolderPairNamed(currentPairName)){
                DialogChangeOption changeOption = new DialogChangeOption(_pairManager.CurrentFolderPair, _pairManager);
                changeOption.ShowDialog(this);
            }else{
                Console.WriteLine(string.Format("WARNING: SELECTED FOLDER PAIR NAMED {0} NOT FOUND!", currentPairName));
            }
        }

        private void CallBackFolderPairSelectionBlur(object sender, EventArgs e)
        {
            Console.WriteLine("XXXXXXXXXXXXXXXXXX");
            ListOfFolderPairs.ResetForeColor();
        }

        

        


      

       

    }
}
