﻿namespace SyncToyDesktopApp {
    partial class DialogChangeAction {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.PanelHeader = new System.Windows.Forms.Panel();
            this.LinkMoreInfo = new System.Windows.Forms.LinkLabel();
            this.PanelMoreInfo = new System.Windows.Forms.Panel();
            this.GroupShortExplanation = new System.Windows.Forms.GroupBox();
            this.LabelShortExplanation = new System.Windows.Forms.Label();
            this.PanelSynchronizationType = new System.Windows.Forms.Panel();
            this.OptionContribute = new System.Windows.Forms.RadioButton();
            this.OptionEcho = new System.Windows.Forms.RadioButton();
            this.OptionSynchronize = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ButtonCancel = new System.Windows.Forms.Button();
            this.ButtonOK = new System.Windows.Forms.Button();
            this.GroupShortExplanation.SuspendLayout();
            this.PanelSynchronizationType.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelHeader
            // 
            this.PanelHeader.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.syncToyGradientBar;
            this.PanelHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PanelHeader.Location = new System.Drawing.Point(-5, -1);
            this.PanelHeader.Name = "PanelHeader";
            this.PanelHeader.Size = new System.Drawing.Size(459, 66);
            this.PanelHeader.TabIndex = 0;
            // 
            // LinkMoreInfo
            // 
            this.LinkMoreInfo.AutoSize = true;
            this.LinkMoreInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LinkMoreInfo.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LinkMoreInfo.Location = new System.Drawing.Point(209, 240);
            this.LinkMoreInfo.Name = "LinkMoreInfo";
            this.LinkMoreInfo.Size = new System.Drawing.Size(95, 13);
            this.LinkMoreInfo.TabIndex = 4;
            this.LinkMoreInfo.TabStop = true;
            this.LinkMoreInfo.Text = "More Information...";
            // 
            // PanelMoreInfo
            // 
            this.PanelMoreInfo.BackColor = System.Drawing.Color.Transparent;
            this.PanelMoreInfo.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncoyUI_HELP;
            this.PanelMoreInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelMoreInfo.Cursor = System.Windows.Forms.Cursors.Help;
            this.PanelMoreInfo.Location = new System.Drawing.Point(184, 237);
            this.PanelMoreInfo.Name = "PanelMoreInfo";
            this.PanelMoreInfo.Size = new System.Drawing.Size(17, 17);
            this.PanelMoreInfo.TabIndex = 44;
            // 
            // GroupShortExplanation
            // 
            this.GroupShortExplanation.Controls.Add(this.LabelShortExplanation);
            this.GroupShortExplanation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.GroupShortExplanation.Location = new System.Drawing.Point(184, 96);
            this.GroupShortExplanation.Name = "GroupShortExplanation";
            this.GroupShortExplanation.Size = new System.Drawing.Size(230, 135);
            this.GroupShortExplanation.TabIndex = 43;
            this.GroupShortExplanation.TabStop = false;
            this.GroupShortExplanation.Text = "Short Explanation";
            // 
            // LabelShortExplanation
            // 
            this.LabelShortExplanation.Location = new System.Drawing.Point(6, 19);
            this.LabelShortExplanation.Name = "LabelShortExplanation";
            this.LabelShortExplanation.Size = new System.Drawing.Size(218, 103);
            this.LabelShortExplanation.TabIndex = 0;
            // 
            // PanelSynchronizationType
            // 
            this.PanelSynchronizationType.Controls.Add(this.OptionContribute);
            this.PanelSynchronizationType.Controls.Add(this.OptionEcho);
            this.PanelSynchronizationType.Controls.Add(this.OptionSynchronize);
            this.PanelSynchronizationType.Location = new System.Drawing.Point(4, 96);
            this.PanelSynchronizationType.Name = "PanelSynchronizationType";
            this.PanelSynchronizationType.Size = new System.Drawing.Size(157, 122);
            this.PanelSynchronizationType.TabIndex = 0;
            // 
            // OptionContribute
            // 
            this.OptionContribute.AutoSize = true;
            this.OptionContribute.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.OptionContribute.Location = new System.Drawing.Point(11, 61);
            this.OptionContribute.Name = "OptionContribute";
            this.OptionContribute.Size = new System.Drawing.Size(73, 17);
            this.OptionContribute.TabIndex = 3;
            this.OptionContribute.TabStop = true;
            this.OptionContribute.Text = "Contribute";
            this.OptionContribute.UseVisualStyleBackColor = true;
            this.OptionContribute.Click += new System.EventHandler(this.SelectContribute);
            this.OptionContribute.MouseHover += new System.EventHandler(this.ShowContributeToolTip);
            // 
            // OptionEcho
            // 
            this.OptionEcho.AutoSize = true;
            this.OptionEcho.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.OptionEcho.Location = new System.Drawing.Point(11, 38);
            this.OptionEcho.Name = "OptionEcho";
            this.OptionEcho.Size = new System.Drawing.Size(50, 17);
            this.OptionEcho.TabIndex = 2;
            this.OptionEcho.TabStop = true;
            this.OptionEcho.Text = "Echo";
            this.OptionEcho.UseVisualStyleBackColor = true;
            this.OptionEcho.Click += new System.EventHandler(this.SelectEcho);
            this.OptionEcho.MouseHover += new System.EventHandler(this.ShowEchoToolTip);
            // 
            // OptionSynchronize
            // 
            this.OptionSynchronize.AutoSize = true;
            this.OptionSynchronize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.OptionSynchronize.Location = new System.Drawing.Point(11, 15);
            this.OptionSynchronize.Name = "OptionSynchronize";
            this.OptionSynchronize.Size = new System.Drawing.Size(83, 17);
            this.OptionSynchronize.TabIndex = 1;
            this.OptionSynchronize.TabStop = true;
            this.OptionSynchronize.Text = "Synchronize";
            this.OptionSynchronize.UseVisualStyleBackColor = true;
            this.OptionSynchronize.Click += new System.EventHandler(this.SelectSynchronize);
            this.OptionSynchronize.MouseHover += new System.EventHandler(this.ShowSynchronizeToolTip);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label3.Location = new System.Drawing.Point(12, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 15);
            this.label3.TabIndex = 41;
            this.label3.Text = "What do you want to do?";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(446, 364);
            this.shapeContainer1.TabIndex = 46;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(154)))), ((int)(((byte)(192)))));
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 18;
            this.lineShape1.X2 = 428;
            this.lineShape1.Y1 = 305;
            this.lineShape1.Y2 = 305;
            // 
            // ButtonCancel
            // 
            this.ButtonCancel.Location = new System.Drawing.Point(354, 329);
            this.ButtonCancel.Name = "ButtonCancel";
            this.ButtonCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonCancel.TabIndex = 6;
            this.ButtonCancel.Text = "Cancel";
            this.ButtonCancel.UseVisualStyleBackColor = true;
            this.ButtonCancel.Click += new System.EventHandler(this.CallBackCancel);
            // 
            // ButtonOK
            // 
            this.ButtonOK.Location = new System.Drawing.Point(273, 329);
            this.ButtonOK.Name = "ButtonOK";
            this.ButtonOK.Size = new System.Drawing.Size(75, 23);
            this.ButtonOK.TabIndex = 5;
            this.ButtonOK.Text = "OK";
            this.ButtonOK.UseVisualStyleBackColor = true;
            this.ButtonOK.Click += new System.EventHandler(this.CallBackOk);
            // 
            // DialogChangeAction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 364);
            this.Controls.Add(this.ButtonOK);
            this.Controls.Add(this.ButtonCancel);
            this.Controls.Add(this.LinkMoreInfo);
            this.Controls.Add(this.PanelMoreInfo);
            this.Controls.Add(this.GroupShortExplanation);
            this.Controls.Add(this.PanelSynchronizationType);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PanelHeader);
            this.Controls.Add(this.shapeContainer1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(462, 402);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(462, 402);
            this.Name = "DialogChangeAction";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DialogChangeAction";
            this.Load += new System.EventHandler(this.DialogChangeActionLoad);
            this.GroupShortExplanation.ResumeLayout(false);
            this.PanelSynchronizationType.ResumeLayout(false);
            this.PanelSynchronizationType.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PanelHeader;
        private System.Windows.Forms.LinkLabel LinkMoreInfo;
        private System.Windows.Forms.Panel PanelMoreInfo;
        private System.Windows.Forms.GroupBox GroupShortExplanation;
        private System.Windows.Forms.Label LabelShortExplanation;
        private System.Windows.Forms.Panel PanelSynchronizationType;
        private System.Windows.Forms.RadioButton OptionContribute;
        private System.Windows.Forms.RadioButton OptionEcho;
        private System.Windows.Forms.RadioButton OptionSynchronize;
        private System.Windows.Forms.Label label3;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Button ButtonCancel;
        private System.Windows.Forms.Button ButtonOK;
    }
}