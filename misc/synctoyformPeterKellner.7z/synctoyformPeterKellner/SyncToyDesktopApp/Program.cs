﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;
using System.Diagnostics.Eventing;

namespace SyncToyDesktopApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                MainWindow = new Main();
                Application.Run(MainWindow);
            }catch(Exception e)
            {
               if(DebugEnabled)
               {

                   if (!EventLog.SourceExists(Program.EventSource))
                   {
                       EventLog.CreateEventSource(Program.EventSource, "CRSyncFiles");
                   }

                   //Logs
                   EventLog.WriteEntry(EventSource, e.Message, EventLogEntryType.Error);

               }
            }
        }

        public static string EventSource = "ConnectionRoad - CRSyncFiles";
        public static Main MainWindow { get; set; }
        public static bool DebugEnabled { get; set; }
    }
}
