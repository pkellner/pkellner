﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SyncToyDesktopApp.Properties;
using System.Net;

namespace SyncToyDesktopApp {
    public partial class DialogCustomerFeedbackOptions : Form {
        public DialogCustomerFeedbackOptions() {
            InitializeComponent();

            //Initialize name
            Text = Resources.TEXT_CUSTOMER_FEEDBACK_OPTION_TITLE;

            //Initialize texts
            LabelCEIP.Text = Resources.TEXT_CUSTOMER_EXPERIENCE_IMPROVEMENT_PROGRAM_INFO;
        }

         private void CallBackCancel(object sender, EventArgs e) {
             Close();
        }

         private void CallBackOk(object sender, EventArgs e) {
             //TODO
             Close();
         }

         private void LoadProgramDocument(object sender, LinkLabelLinkClickedEventArgs e) {
             System.Diagnostics.Process.Start("http://www.microsoft.com/products/ceip/en-us/privacypolicy.mspx");
         }
    }
}
