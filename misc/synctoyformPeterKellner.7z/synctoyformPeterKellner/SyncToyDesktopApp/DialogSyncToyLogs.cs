﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;
using System.IO;
using SyncToyDesktopApp.Properties;


namespace SyncToyDesktopApp {
    public partial class DialogSyncToyLogs : Form {

        private ResourceManager DefaultResourceManager;
        private string LogFileName;

        public DialogSyncToyLogs() {
            InitializeComponent();
            DefaultResourceManager = new ResourceManager("SyncToyDesktopApp.Properties.Resources", Assembly.GetExecutingAssembly());
            LogFileName = DefaultResourceManager.GetString("LOG_FILE_PATH");
            
            //Initialize name
            Text = Resources.TEXT_SHORT_NAME + "Log";
            
            try{
                StreamReader logReader = new StreamReader(LogFileName);
                TextLogs.Text = logReader.ReadToEnd();
                logReader.Close();
            }catch(Exception logReaderExeption){
                //DO NOTHING FOR NOW
            }
        }

        private void CallBackClose(object sender, EventArgs e) {
             Close();
        }

         private void CallBackClearLogs(object sender, EventArgs e)
         {
             if(File.Exists(LogFileName)){
                 File.Delete(LogFileName);
                 TextLogs.Clear();
             }
         }

    }
}
