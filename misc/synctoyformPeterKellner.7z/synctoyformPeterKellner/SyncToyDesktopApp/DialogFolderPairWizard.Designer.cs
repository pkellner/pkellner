﻿namespace SyncToyDesktopApp {
    partial class DialogFolderPairWizard {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.PanelHeader = new System.Windows.Forms.Panel();
            this.TabControlWizard = new System.Windows.Forms.TabControl();
            this.TabPageFolderPair = new System.Windows.Forms.TabPage();
            this.ButtonBackDefault = new System.Windows.Forms.Button();
            this.ButtonGoToStep2 = new System.Windows.Forms.Button();
            this.ButtonCancelStep1 = new System.Windows.Forms.Button();
            this.ButtonBrowseDestination = new System.Windows.Forms.Button();
            this.ButtonBrowseSource = new System.Windows.Forms.Button();
            this.TextBoxDestination = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TextBoxSource = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LabelChooseFolder = new System.Windows.Forms.Label();
            this.PanelFolderImage = new System.Windows.Forms.Panel();
            this.PanelDestinationImage = new System.Windows.Forms.Panel();
            this.PanelSourceImage = new System.Windows.Forms.Panel();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.TabPageMethod = new System.Windows.Forms.TabPage();
            this.LinkMoreInfo = new System.Windows.Forms.LinkLabel();
            this.PanelMoreInfo = new System.Windows.Forms.Panel();
            this.GroupShortExplanation = new System.Windows.Forms.GroupBox();
            this.LabelShortExplanation = new System.Windows.Forms.Label();
            this.PanelSynchronizationType = new System.Windows.Forms.Panel();
            this.OptionContribute = new System.Windows.Forms.RadioButton();
            this.OptionEcho = new System.Windows.Forms.RadioButton();
            this.OptionSynchronize = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.ButtonBackToStep1 = new System.Windows.Forms.Button();
            this.ButtonGoToStep3 = new System.Windows.Forms.Button();
            this.ButtonCancelStep2 = new System.Windows.Forms.Button();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.TabPagePairName = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.TextBoxFolderPairName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ButtonBackToStep2 = new System.Windows.Forms.Button();
            this.ButtonFinish = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.shapeContainer3 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.DialogSourceBrowser = new System.Windows.Forms.FolderBrowserDialog();
            this.DialogDestinationBrowser = new System.Windows.Forms.FolderBrowserDialog();
            this.TabControlWizard.SuspendLayout();
            this.TabPageFolderPair.SuspendLayout();
            this.TabPageMethod.SuspendLayout();
            this.GroupShortExplanation.SuspendLayout();
            this.PanelSynchronizationType.SuspendLayout();
            this.TabPagePairName.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelHeader
            // 
            this.PanelHeader.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.syncToyGradientBar;
            this.PanelHeader.Location = new System.Drawing.Point(-6, -6);
            this.PanelHeader.Name = "PanelHeader";
            this.PanelHeader.Size = new System.Drawing.Size(462, 64);
            this.PanelHeader.TabIndex = 0;
            // 
            // TabControlWizard
            // 
            this.TabControlWizard.Controls.Add(this.TabPageFolderPair);
            this.TabControlWizard.Controls.Add(this.TabPageMethod);
            this.TabControlWizard.Controls.Add(this.TabPagePairName);
            this.TabControlWizard.Location = new System.Drawing.Point(3, 40);
            this.TabControlWizard.Name = "TabControlWizard";
            this.TabControlWizard.SelectedIndex = 0;
            this.TabControlWizard.Size = new System.Drawing.Size(450, 332);
            this.TabControlWizard.TabIndex = 11;
            // 
            // TabPageFolderPair
            // 
            this.TabPageFolderPair.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(246)))), ((int)(((byte)(252)))));
            this.TabPageFolderPair.Controls.Add(this.ButtonBackDefault);
            this.TabPageFolderPair.Controls.Add(this.ButtonGoToStep2);
            this.TabPageFolderPair.Controls.Add(this.ButtonCancelStep1);
            this.TabPageFolderPair.Controls.Add(this.ButtonBrowseDestination);
            this.TabPageFolderPair.Controls.Add(this.ButtonBrowseSource);
            this.TabPageFolderPair.Controls.Add(this.TextBoxDestination);
            this.TabPageFolderPair.Controls.Add(this.panel1);
            this.TabPageFolderPair.Controls.Add(this.TextBoxSource);
            this.TabPageFolderPair.Controls.Add(this.label2);
            this.TabPageFolderPair.Controls.Add(this.label1);
            this.TabPageFolderPair.Controls.Add(this.LabelChooseFolder);
            this.TabPageFolderPair.Controls.Add(this.PanelFolderImage);
            this.TabPageFolderPair.Controls.Add(this.PanelDestinationImage);
            this.TabPageFolderPair.Controls.Add(this.PanelSourceImage);
            this.TabPageFolderPair.Controls.Add(this.shapeContainer1);
            this.TabPageFolderPair.Location = new System.Drawing.Point(4, 22);
            this.TabPageFolderPair.Name = "TabPageFolderPair";
            this.TabPageFolderPair.Padding = new System.Windows.Forms.Padding(3);
            this.TabPageFolderPair.Size = new System.Drawing.Size(442, 306);
            this.TabPageFolderPair.TabIndex = 0;
            this.TabPageFolderPair.Text = "tabPage1";
            // 
            // ButtonBackDefault
            // 
            this.ButtonBackDefault.Enabled = false;
            this.ButtonBackDefault.Location = new System.Drawing.Point(186, 272);
            this.ButtonBackDefault.Name = "ButtonBackDefault";
            this.ButtonBackDefault.Size = new System.Drawing.Size(75, 23);
            this.ButtonBackDefault.TabIndex = 4;
            this.ButtonBackDefault.Text = "< Back";
            this.ButtonBackDefault.UseVisualStyleBackColor = true;
            // 
            // ButtonGoToStep2
            // 
            this.ButtonGoToStep2.Enabled = false;
            this.ButtonGoToStep2.Location = new System.Drawing.Point(267, 272);
            this.ButtonGoToStep2.Name = "ButtonGoToStep2";
            this.ButtonGoToStep2.Size = new System.Drawing.Size(75, 23);
            this.ButtonGoToStep2.TabIndex = 5;
            this.ButtonGoToStep2.Text = "Next >";
            this.ButtonGoToStep2.UseVisualStyleBackColor = true;
            this.ButtonGoToStep2.Click += new System.EventHandler(this.CallBackGoToStep2);
            // 
            // ButtonCancelStep1
            // 
            this.ButtonCancelStep1.Location = new System.Drawing.Point(348, 272);
            this.ButtonCancelStep1.Name = "ButtonCancelStep1";
            this.ButtonCancelStep1.Size = new System.Drawing.Size(75, 23);
            this.ButtonCancelStep1.TabIndex = 6;
            this.ButtonCancelStep1.Text = "Cancel";
            this.ButtonCancelStep1.UseVisualStyleBackColor = true;
            this.ButtonCancelStep1.Click += new System.EventHandler(this.CallBackCancel);
            // 
            // ButtonBrowseDestination
            // 
            this.ButtonBrowseDestination.Location = new System.Drawing.Point(231, 194);
            this.ButtonBrowseDestination.Name = "ButtonBrowseDestination";
            this.ButtonBrowseDestination.Size = new System.Drawing.Size(75, 23);
            this.ButtonBrowseDestination.TabIndex = 3;
            this.ButtonBrowseDestination.Text = "Browse...";
            this.ButtonBrowseDestination.UseVisualStyleBackColor = true;
            this.ButtonBrowseDestination.Click += new System.EventHandler(this.CallBackBrowseDestination);
            // 
            // ButtonBrowseSource
            // 
            this.ButtonBrowseSource.Location = new System.Drawing.Point(20, 194);
            this.ButtonBrowseSource.Name = "ButtonBrowseSource";
            this.ButtonBrowseSource.Size = new System.Drawing.Size(75, 23);
            this.ButtonBrowseSource.TabIndex = 1;
            this.ButtonBrowseSource.Text = "Browse...";
            this.ButtonBrowseSource.UseVisualStyleBackColor = true;
            this.ButtonBrowseSource.Click += new System.EventHandler(this.CallBackBrowseSource);
            // 
            // TextBoxDestination
            // 
            this.TextBoxDestination.Location = new System.Drawing.Point(253, 168);
            this.TextBoxDestination.Name = "TextBoxDestination";
            this.TextBoxDestination.Size = new System.Drawing.Size(165, 20);
            this.TextBoxDestination.TabIndex = 2;
            this.TextBoxDestination.TextChanged += new System.EventHandler(this.CallBackDestinationChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_folder;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Location = new System.Drawing.Point(231, 168);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(16, 15);
            this.panel1.TabIndex = 14;
            // 
            // TextBoxSource
            // 
            this.TextBoxSource.Location = new System.Drawing.Point(39, 168);
            this.TextBoxSource.Name = "TextBoxSource";
            this.TextBoxSource.Size = new System.Drawing.Size(165, 20);
            this.TextBoxSource.TabIndex = 0;
            this.TextBoxSource.Leave += new System.EventHandler(this.CallBackCheckSource);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label2.Location = new System.Drawing.Point(228, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Right folder:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label1.Location = new System.Drawing.Point(14, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Left Folder:";
            // 
            // LabelChooseFolder
            // 
            this.LabelChooseFolder.AutoSize = true;
            this.LabelChooseFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelChooseFolder.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LabelChooseFolder.Location = new System.Drawing.Point(14, 21);
            this.LabelChooseFolder.Name = "LabelChooseFolder";
            this.LabelChooseFolder.Size = new System.Drawing.Size(206, 16);
            this.LabelChooseFolder.TabIndex = 13;
            this.LabelChooseFolder.Text = "Choose the folders you want:";
            // 
            // PanelFolderImage
            // 
            this.PanelFolderImage.BackColor = System.Drawing.Color.Transparent;
            this.PanelFolderImage.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_folder;
            this.PanelFolderImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelFolderImage.Location = new System.Drawing.Point(17, 168);
            this.PanelFolderImage.Name = "PanelFolderImage";
            this.PanelFolderImage.Size = new System.Drawing.Size(16, 15);
            this.PanelFolderImage.TabIndex = 11;
            // 
            // PanelDestinationImage
            // 
            this.PanelDestinationImage.BackColor = System.Drawing.Color.Transparent;
            this.PanelDestinationImage.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_Rightgraphic1;
            this.PanelDestinationImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelDestinationImage.Location = new System.Drawing.Point(231, 53);
            this.PanelDestinationImage.Name = "PanelDestinationImage";
            this.PanelDestinationImage.Size = new System.Drawing.Size(68, 70);
            this.PanelDestinationImage.TabIndex = 12;
            // 
            // PanelSourceImage
            // 
            this.PanelSourceImage.BackColor = System.Drawing.Color.Transparent;
            this.PanelSourceImage.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_LeftGraphic1;
            this.PanelSourceImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelSourceImage.Location = new System.Drawing.Point(17, 53);
            this.PanelSourceImage.Name = "PanelSourceImage";
            this.PanelSourceImage.Size = new System.Drawing.Size(68, 70);
            this.PanelSourceImage.TabIndex = 10;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(436, 300);
            this.shapeContainer1.TabIndex = 31;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(154)))), ((int)(((byte)(192)))));
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 10;
            this.lineShape1.X2 = 421;
            this.lineShape1.Y1 = 252;
            this.lineShape1.Y2 = 252;
            // 
            // TabPageMethod
            // 
            this.TabPageMethod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(246)))), ((int)(((byte)(252)))));
            this.TabPageMethod.Controls.Add(this.LinkMoreInfo);
            this.TabPageMethod.Controls.Add(this.PanelMoreInfo);
            this.TabPageMethod.Controls.Add(this.GroupShortExplanation);
            this.TabPageMethod.Controls.Add(this.PanelSynchronizationType);
            this.TabPageMethod.Controls.Add(this.label3);
            this.TabPageMethod.Controls.Add(this.ButtonBackToStep1);
            this.TabPageMethod.Controls.Add(this.ButtonGoToStep3);
            this.TabPageMethod.Controls.Add(this.ButtonCancelStep2);
            this.TabPageMethod.Controls.Add(this.shapeContainer2);
            this.TabPageMethod.Location = new System.Drawing.Point(4, 22);
            this.TabPageMethod.Name = "TabPageMethod";
            this.TabPageMethod.Padding = new System.Windows.Forms.Padding(3);
            this.TabPageMethod.Size = new System.Drawing.Size(442, 306);
            this.TabPageMethod.TabIndex = 1;
            this.TabPageMethod.Text = "tabPage2";
            // 
            // LinkMoreInfo
            // 
            this.LinkMoreInfo.AutoSize = true;
            this.LinkMoreInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LinkMoreInfo.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LinkMoreInfo.Location = new System.Drawing.Point(211, 174);
            this.LinkMoreInfo.Name = "LinkMoreInfo";
            this.LinkMoreInfo.Size = new System.Drawing.Size(95, 13);
            this.LinkMoreInfo.TabIndex = 4;
            this.LinkMoreInfo.TabStop = true;
            this.LinkMoreInfo.Text = "More Information...";
            // 
            // PanelMoreInfo
            // 
            this.PanelMoreInfo.BackColor = System.Drawing.Color.Transparent;
            this.PanelMoreInfo.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncoyUI_HELP;
            this.PanelMoreInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelMoreInfo.Cursor = System.Windows.Forms.Cursors.Help;
            this.PanelMoreInfo.Location = new System.Drawing.Point(186, 171);
            this.PanelMoreInfo.Name = "PanelMoreInfo";
            this.PanelMoreInfo.Size = new System.Drawing.Size(17, 17);
            this.PanelMoreInfo.TabIndex = 39;
            // 
            // GroupShortExplanation
            // 
            this.GroupShortExplanation.Controls.Add(this.LabelShortExplanation);
            this.GroupShortExplanation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.GroupShortExplanation.Location = new System.Drawing.Point(186, 30);
            this.GroupShortExplanation.Name = "GroupShortExplanation";
            this.GroupShortExplanation.Size = new System.Drawing.Size(230, 135);
            this.GroupShortExplanation.TabIndex = 38;
            this.GroupShortExplanation.TabStop = false;
            this.GroupShortExplanation.Text = "Short Explanation";
            // 
            // LabelShortExplanation
            // 
            this.LabelShortExplanation.Location = new System.Drawing.Point(6, 19);
            this.LabelShortExplanation.Name = "LabelShortExplanation";
            this.LabelShortExplanation.Size = new System.Drawing.Size(218, 103);
            this.LabelShortExplanation.TabIndex = 0;
            // 
            // PanelSynchronizationType
            // 
            this.PanelSynchronizationType.Controls.Add(this.OptionContribute);
            this.PanelSynchronizationType.Controls.Add(this.OptionEcho);
            this.PanelSynchronizationType.Controls.Add(this.OptionSynchronize);
            this.PanelSynchronizationType.Location = new System.Drawing.Point(6, 30);
            this.PanelSynchronizationType.Name = "PanelSynchronizationType";
            this.PanelSynchronizationType.Size = new System.Drawing.Size(157, 122);
            this.PanelSynchronizationType.TabIndex = 0;
            // 
            // OptionContribute
            // 
            this.OptionContribute.AutoSize = true;
            this.OptionContribute.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.OptionContribute.Location = new System.Drawing.Point(11, 61);
            this.OptionContribute.Name = "OptionContribute";
            this.OptionContribute.Size = new System.Drawing.Size(73, 17);
            this.OptionContribute.TabIndex = 3;
            this.OptionContribute.TabStop = true;
            this.OptionContribute.Text = "Contribute";
            this.OptionContribute.UseVisualStyleBackColor = true;
            this.OptionContribute.CheckedChanged += new System.EventHandler(this.SelectContribute);
            this.OptionContribute.MouseHover += new System.EventHandler(this.ShowContributeToolTip);
            // 
            // OptionEcho
            // 
            this.OptionEcho.AutoSize = true;
            this.OptionEcho.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.OptionEcho.Location = new System.Drawing.Point(11, 38);
            this.OptionEcho.Name = "OptionEcho";
            this.OptionEcho.Size = new System.Drawing.Size(50, 17);
            this.OptionEcho.TabIndex = 2;
            this.OptionEcho.TabStop = true;
            this.OptionEcho.Text = "Echo";
            this.OptionEcho.UseVisualStyleBackColor = true;
            this.OptionEcho.CheckedChanged += new System.EventHandler(this.SelectEcho);
            this.OptionEcho.MouseHover += new System.EventHandler(this.ShowEchoToolTip);
            // 
            // OptionSynchronize
            // 
            this.OptionSynchronize.AutoSize = true;
            this.OptionSynchronize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.OptionSynchronize.Location = new System.Drawing.Point(11, 15);
            this.OptionSynchronize.Name = "OptionSynchronize";
            this.OptionSynchronize.Size = new System.Drawing.Size(83, 17);
            this.OptionSynchronize.TabIndex = 1;
            this.OptionSynchronize.TabStop = true;
            this.OptionSynchronize.Text = "Synchronize";
            this.OptionSynchronize.UseVisualStyleBackColor = true;
            this.OptionSynchronize.Click += new System.EventHandler(this.SelectSynchronize);
            this.OptionSynchronize.MouseHover += new System.EventHandler(this.ShowSynchronizeToolTip);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label3.Location = new System.Drawing.Point(14, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 15);
            this.label3.TabIndex = 35;
            this.label3.Text = "What do you want to do?";
            // 
            // ButtonBackToStep1
            // 
            this.ButtonBackToStep1.Location = new System.Drawing.Point(186, 272);
            this.ButtonBackToStep1.Name = "ButtonBackToStep1";
            this.ButtonBackToStep1.Size = new System.Drawing.Size(75, 23);
            this.ButtonBackToStep1.TabIndex = 5;
            this.ButtonBackToStep1.Text = "< Back";
            this.ButtonBackToStep1.UseVisualStyleBackColor = true;
            this.ButtonBackToStep1.Click += new System.EventHandler(this.CallBackGoToStep1);
            // 
            // ButtonGoToStep3
            // 
            this.ButtonGoToStep3.Location = new System.Drawing.Point(267, 272);
            this.ButtonGoToStep3.Name = "ButtonGoToStep3";
            this.ButtonGoToStep3.Size = new System.Drawing.Size(75, 23);
            this.ButtonGoToStep3.TabIndex = 6;
            this.ButtonGoToStep3.Text = "Next >";
            this.ButtonGoToStep3.UseVisualStyleBackColor = true;
            this.ButtonGoToStep3.Click += new System.EventHandler(this.CallBackGoToStep3);
            // 
            // ButtonCancelStep2
            // 
            this.ButtonCancelStep2.Location = new System.Drawing.Point(348, 272);
            this.ButtonCancelStep2.Name = "ButtonCancelStep2";
            this.ButtonCancelStep2.Size = new System.Drawing.Size(75, 23);
            this.ButtonCancelStep2.TabIndex = 7;
            this.ButtonCancelStep2.Text = "Cancel";
            this.ButtonCancelStep2.UseVisualStyleBackColor = true;
            this.ButtonCancelStep2.Click += new System.EventHandler(this.CallBackCancel);
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape2});
            this.shapeContainer2.Size = new System.Drawing.Size(436, 300);
            this.shapeContainer2.TabIndex = 41;
            this.shapeContainer2.TabStop = false;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(154)))), ((int)(((byte)(192)))));
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 10;
            this.lineShape2.X2 = 421;
            this.lineShape2.Y1 = 252;
            this.lineShape2.Y2 = 252;
            // 
            // TabPagePairName
            // 
            this.TabPagePairName.Controls.Add(this.panel2);
            this.TabPagePairName.Controls.Add(this.label5);
            this.TabPagePairName.Controls.Add(this.TextBoxFolderPairName);
            this.TabPagePairName.Controls.Add(this.label4);
            this.TabPagePairName.Controls.Add(this.ButtonBackToStep2);
            this.TabPagePairName.Controls.Add(this.ButtonFinish);
            this.TabPagePairName.Controls.Add(this.button3);
            this.TabPagePairName.Controls.Add(this.shapeContainer3);
            this.TabPagePairName.Location = new System.Drawing.Point(4, 22);
            this.TabPagePairName.Name = "TabPagePairName";
            this.TabPagePairName.Padding = new System.Windows.Forms.Padding(3);
            this.TabPagePairName.Size = new System.Drawing.Size(442, 306);
            this.TabPagePairName.TabIndex = 2;
            this.TabPagePairName.Text = "tabPage1";
            this.TabPagePairName.UseVisualStyleBackColor = true;
            this.TabPagePairName.Click += new System.EventHandler(this.TabPagePairName_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncoyUI_HELP;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel2.Cursor = System.Windows.Forms.Cursors.Help;
            this.panel2.Location = new System.Drawing.Point(193, 64);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(17, 17);
            this.panel2.TabIndex = 41;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label5.Location = new System.Drawing.Point(8, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 13);
            this.label5.TabIndex = 40;
            this.label5.Text = "For example, \"My Pics Backup\"";
            // 
            // TextBoxFolderPairName
            // 
            this.TextBoxFolderPairName.Location = new System.Drawing.Point(11, 61);
            this.TextBoxFolderPairName.Name = "TextBoxFolderPairName";
            this.TextBoxFolderPairName.Size = new System.Drawing.Size(176, 20);
            this.TextBoxFolderPairName.TabIndex = 0;
            this.TextBoxFolderPairName.TextChanged += new System.EventHandler(this.CallBackFolderPairNameChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label4.Location = new System.Drawing.Point(8, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 15);
            this.label4.TabIndex = 38;
            this.label4.Text = "Name your folder pair:";
            // 
            // ButtonBackToStep2
            // 
            this.ButtonBackToStep2.Location = new System.Drawing.Point(186, 272);
            this.ButtonBackToStep2.Name = "ButtonBackToStep2";
            this.ButtonBackToStep2.Size = new System.Drawing.Size(75, 23);
            this.ButtonBackToStep2.TabIndex = 1;
            this.ButtonBackToStep2.Text = "< Back";
            this.ButtonBackToStep2.UseVisualStyleBackColor = true;
            this.ButtonBackToStep2.Click += new System.EventHandler(this.CallBackBackToStep2);
            // 
            // ButtonFinish
            // 
            this.ButtonFinish.Enabled = false;
            this.ButtonFinish.Location = new System.Drawing.Point(267, 272);
            this.ButtonFinish.Name = "ButtonFinish";
            this.ButtonFinish.Size = new System.Drawing.Size(75, 23);
            this.ButtonFinish.TabIndex = 2;
            this.ButtonFinish.Text = "Finish";
            this.ButtonFinish.UseVisualStyleBackColor = true;
            this.ButtonFinish.Click += new System.EventHandler(this.ButtonFolderPairWizardFinished);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(348, 272);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "Cancel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.CallBackCancel);
            // 
            // shapeContainer3
            // 
            this.shapeContainer3.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer3.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer3.Name = "shapeContainer3";
            this.shapeContainer3.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape3});
            this.shapeContainer3.Size = new System.Drawing.Size(436, 300);
            this.shapeContainer3.TabIndex = 42;
            this.shapeContainer3.TabStop = false;
            // 
            // lineShape3
            // 
            this.lineShape3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(154)))), ((int)(((byte)(192)))));
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 10;
            this.lineShape3.X2 = 421;
            this.lineShape3.Y1 = 252;
            this.lineShape3.Y2 = 252;
            // 
            // DialogSourceBrowser
            // 
            this.DialogSourceBrowser.Description = "Choose the left folder you want:";
            // 
            // DialogFolderPairWizard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(246)))), ((int)(((byte)(252)))));
            this.ClientSize = new System.Drawing.Size(446, 369);
            this.Controls.Add(this.TabControlWizard);
            this.Controls.Add(this.PanelHeader);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(462, 407);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(462, 407);
            this.Name = "DialogFolderPairWizard";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Step Name ( 0 of 0 )";
            this.Load += new System.EventHandler(this.DialogLoad);
            this.TabControlWizard.ResumeLayout(false);
            this.TabPageFolderPair.ResumeLayout(false);
            this.TabPageFolderPair.PerformLayout();
            this.TabPageMethod.ResumeLayout(false);
            this.TabPageMethod.PerformLayout();
            this.GroupShortExplanation.ResumeLayout(false);
            this.PanelSynchronizationType.ResumeLayout(false);
            this.PanelSynchronizationType.PerformLayout();
            this.TabPagePairName.ResumeLayout(false);
            this.TabPagePairName.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelHeader;
        private System.Windows.Forms.TabControl TabControlWizard;
        private System.Windows.Forms.TabPage TabPageFolderPair;
        private System.Windows.Forms.Button ButtonBrowseDestination;
        private System.Windows.Forms.Button ButtonBrowseSource;
        private System.Windows.Forms.TextBox TextBoxDestination;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox TextBoxSource;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LabelChooseFolder;
        private System.Windows.Forms.Panel PanelFolderImage;
        private System.Windows.Forms.Panel PanelDestinationImage;
        private System.Windows.Forms.Panel PanelSourceImage;
        private System.Windows.Forms.TabPage TabPageMethod;
        private System.Windows.Forms.Button ButtonBackDefault;
        private System.Windows.Forms.Button ButtonGoToStep2;
        private System.Windows.Forms.Button ButtonCancelStep1;
        private System.Windows.Forms.Button ButtonBackToStep1;
        private System.Windows.Forms.Button ButtonGoToStep3;
        private System.Windows.Forms.Button ButtonCancelStep2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton OptionSynchronize;
        private System.Windows.Forms.RadioButton OptionEcho;
        private System.Windows.Forms.RadioButton OptionContribute;
        private System.Windows.Forms.Panel PanelSynchronizationType;
        private System.Windows.Forms.GroupBox GroupShortExplanation;
        private System.Windows.Forms.Label LabelShortExplanation;
        private System.Windows.Forms.LinkLabel LinkMoreInfo;
        private System.Windows.Forms.FolderBrowserDialog DialogSourceBrowser;
        private System.Windows.Forms.FolderBrowserDialog DialogDestinationBrowser;
        private System.Windows.Forms.TabPage TabPagePairName;
        private System.Windows.Forms.Button ButtonBackToStep2;
        private System.Windows.Forms.Button ButtonFinish;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TextBoxFolderPairName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel PanelMoreInfo;
        private System.Windows.Forms.Panel panel2;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
    }
}