﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;
using System.Globalization;
using System.Text.RegularExpressions;
using SyncToyDesktopApp.Properties;
using Welemski.Utility;

using FileSyncUtility;
using DataAccess.Enums;

namespace SyncToyDesktopApp {
    public partial class DialogFolderPairWizard : Form {

        private Assembly _assembly;
        private ResourceManager _resourceManager;

        

        
        public DialogFolderPairWizard() {
            InitializeComponent();
            
            _assembly = Assembly.GetExecutingAssembly();
            _resourceManager = new ResourceManager("SyncToyDesktopApp.Properties.Resources", _assembly);
            InitializeTabControlWizard();
            FolderPair = new FileSyncPairInfo();
            OptionSynchronize.Checked = true;
        }

        public void InitializeTabControlWizard(){
            RectangleF rect = new RectangleF(TabPageFolderPair.Left,
                                              TabPageFolderPair.Top,
                                              TabPageFolderPair.Width,
                                              TabPageFolderPair.Height);
            string defaultExplanation = _resourceManager.GetString("SYNC_INFO_SYNCHRONIZE");
            LabelShortExplanation.Text = defaultExplanation;

            TabControlWizard.Region = new Region(rect);
            ButtonBackDefault.Enabled = false;
            ButtonGoToStep2.Enabled = false;
            Text = Resources.TEXT_CREATE_PAIR_STEP_1;
           
        }


        //------------------------- PROPERTIES -------------------------------------

        public Boolean Create {
            get;
            set;
        }

        public DirectoryInfo SourceFolder {
            get; 
            set;
        }

        public DirectoryInfo DestinationFolder {
            get;
            set;
        }

        public FileSyncPairInfo FolderPair
        {
            get;
            set;
        }


        public FileSyncPairManager PairManager
        {
            get;
            set;
        }


        //------------------------- CALLBACKS -------------------------------------

        private void CallBackCancel(object sender, EventArgs e) {
            Close();
        }

        private void CallBackBrowseSource(object sender, EventArgs e) {

            DialogResult dialogResult =  DialogSourceBrowser.ShowDialog(this);
            if(dialogResult == DialogResult.OK)
            {
                TextBoxSource.Text = DialogSourceBrowser.SelectedPath;
            }
        }

        private void CallBackBrowseDestination(object sender, EventArgs e) {
            DialogResult dialogResult = DialogDestinationBrowser.ShowDialog();
            if (dialogResult == DialogResult.OK)
            {
                TextBoxDestination.Text = DialogDestinationBrowser.SelectedPath;
            }
        }

        private void CallBackCheckSource(object sender, EventArgs e) {
            if (ActiveControl.Name == "TextBoxDestination") {
                string currentSource = TextBoxSource.Text;
                DirectoryValidator validator = new DirectoryValidator(currentSource);
                DirectoryValidatorResult result = validator.Validate();

                //Checks if source path exists and is in valid file path format
                if (result == DirectoryValidatorResult.Exists) {
                    SourceFolder = new DirectoryInfo(TextBoxSource.Text);
                    
                } else if (result == DirectoryValidatorResult.DoesNotExists) {
                    string errorMessage = String.Format(_resourceManager.GetString("ERROR_DIRECTORY_DOES_NOT_EXISTS"), currentSource);
                    MessageBox.Show(this, errorMessage, Resources.TEXT_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else if (result == DirectoryValidatorResult.InvalidPath) {
                    string errorMessage = _resourceManager.GetString("ERROR_DIRECTORY_PATH");
                    MessageBox.Show(this, errorMessage, Resources.TEXT_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    
                }
            } 
        }

        private void CallBackDestinationChanged(object sender, EventArgs e) {
            if ((TextBoxDestination.TextLength >= 1) && (TextBoxSource.TextLength >= 1)) {
                ButtonGoToStep2.Enabled = true;
            }else{
                ButtonGoToStep2.Enabled = false;
            }
        }

        private void CallBackGoToStep2(object sender, EventArgs e) {
            string currentDestination = TextBoxDestination.Text;
            DirectoryValidator destiantionValidator = new DirectoryValidator(currentDestination);
            DirectoryValidatorResult result = destiantionValidator.Validate();

            //Checks if source path exists and is in valid file path format
            if (result == DirectoryValidatorResult.Exists) {
                DestinationFolder = new DirectoryInfo(TextBoxDestination.Text);

                string currentSource = TextBoxSource.Text;
                DirectoryValidator sourceValidator = new DirectoryValidator(currentSource);
                DirectoryValidatorResult sourceResult = sourceValidator.Validate();

                //Checks if source path exists and is in valid file path format
                if (sourceResult == DirectoryValidatorResult.Exists) {

                    if(TextBoxSource.Text.ToUpper() == TextBoxDestination.Text.ToUpper()){
                        MessageBox.Show(this, Resources.ERROR_RECURSIVE_FOLDER, Resources.TEXT_RECURSIVE_FOLDERS, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }else{
                        FolderPair.LeftFolder = TextBoxSource.Text;
                        FolderPair.RightFolder = TextBoxDestination.Text;
                        Text = Resources.TEXT_CREATE_PAIR_STEP_2;
                        //Let's move to the next step
                        TabControlWizard.SelectTab(1);
                        OptionSynchronize.Select();
                    }


                } else if (sourceResult == DirectoryValidatorResult.DoesNotExists) {
                    string errorMessage = String.Format(_resourceManager.GetString("ERROR_DIRECTORY_DOES_NOT_EXISTS"), currentSource);
                    MessageBox.Show(this, errorMessage, Resources.TEXT_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else if (sourceResult == DirectoryValidatorResult.InvalidPath) {
                    string errorMessage = _resourceManager.GetString("ERROR_DIRECTORY_PATH");
                    MessageBox.Show(this, errorMessage, Resources.TEXT_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            } else if (result == DirectoryValidatorResult.DoesNotExists) {
                string errorMessage = String.Format(_resourceManager.GetString("ERROR_DIRECTORY_DOES_NOT_EXISTS"), currentDestination);
                MessageBox.Show(this, errorMessage, Resources.TEXT_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else if (result == DirectoryValidatorResult.InvalidPath) {
                string errorMessage = _resourceManager.GetString("ERROR_DIRECTORY_PATH");
                MessageBox.Show(this, errorMessage, Resources.TEXT_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CallBackGoToStep3(object sender, EventArgs e) {
            Text = Resources.TEXT_CREATE_PAIR_STEP_3;
            TabControlWizard.SelectTab(2);
            TextBoxFolderPairName.Select();
        }

        private void CallBackGoToStep1(object sender, EventArgs e) {
            Text = Resources.TEXT_CREATE_PAIR_STEP_1;
            TabControlWizard.SelectTab(0);
        }

        private void ShowSynchronizeToolTip(object sender, EventArgs e) {
            ToolTip toolTip = new ToolTip();
            string explanation = _resourceManager.GetString("SYNC_INFO_SYNCHRONIZE");
            toolTip.SetToolTip(OptionSynchronize,explanation);
        }

        private void ShowEchoToolTip(object sender, EventArgs e) {
            ToolTip toolTip = new ToolTip();
            string explanation = _resourceManager.GetString("SYNC_INFO_ECHO");
            toolTip.SetToolTip(OptionEcho, explanation);
        }

        private void ShowContributeToolTip(object sender, EventArgs e) {
            ToolTip toolTip = new ToolTip();
            string explanation = _resourceManager.GetString("SYNC_INFO_CONTRIBUTE");
            toolTip.SetToolTip(OptionContribute, explanation);
        }

        private void SelectSynchronize(object sender, EventArgs e) {
            string explanation = _resourceManager.GetString("SYNC_INFO_SYNCHRONIZE");
            LabelShortExplanation.Text = explanation;
            ButtonGoToStep3.Enabled = true;
            FolderPair.FolderPairActionTypeId = (int)FolderPairActionTypeEnum.Synchronize;
            //Console.WriteLine("SYNCHRONIZE");
        }

        private void SelectEcho(object sender, EventArgs e) {
            string explanation = _resourceManager.GetString("SYNC_INFO_ECHO");
            LabelShortExplanation.Text = explanation;
            ButtonGoToStep3.Enabled = true;
            FolderPair.FolderPairActionTypeId = (int)FolderPairActionTypeEnum.Echo;
            //Console.WriteLine("ECho");
        }

        private void SelectContribute(object sender, EventArgs e) {
            string explanation = _resourceManager.GetString("SYNC_INFO_CONTRIBUTE");
            LabelShortExplanation.Text = explanation;
            ButtonGoToStep3.Enabled = true;
            FolderPair.FolderPairActionTypeId = (int)FolderPairActionTypeEnum.Contribute;
            //Console.WriteLine("CONTRIBUTE");
        }

        private void CallBackBackToStep2(object sender, EventArgs e)
        {
            Text = Resources.TEXT_CREATE_PAIR_STEP_2;
            TabControlWizard.SelectTab(1);
        }

        private void CallBackFolderPairNameChanged(object sender, EventArgs e)
        {
            if(TextBoxFolderPairName.Text != null){
                if (TextBoxFolderPairName.TextLength >= 1)
                {
                    if (PairManager.HasFolderPairNamed(TextBoxFolderPairName.Text))
                    {
                        ButtonFinish.Enabled = false;
                    }
                    else
                    {
                        ButtonFinish.Enabled = true;
                    }
                }
                else
                {
                    ButtonFinish.Enabled = false;
                }
            }
        }

        private void ButtonFolderPairWizardFinished(object sender, EventArgs e)
        {
            
            string newFolderPairName = TextBoxFolderPairName.Text;
            if (Regex.Match(newFolderPairName, @"[a-zA-Z0-9].*\s*").Success) {
                FolderPair.FolderPairName = newFolderPairName;
                DialogResult = DialogResult.OK;
                Close();
            }else{
                MessageBox.Show(Resources.ERROR_FOLDER_PAIR_NAME, Resources.TEXT_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void TabPagePairName_Click(object sender, EventArgs e)
        {

        }

        private void DialogLoad(object sender, EventArgs e)
        {
            TextBoxSource.Select();
        }

        


       

        


    }
}
