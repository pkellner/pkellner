﻿namespace SyncToyDesktopApp {
    partial class DialogSyncToyLogs {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.TextLogs = new System.Windows.Forms.TextBox();
            this.ButtonCloseSyncToyLogs = new System.Windows.Forms.Button();
            this.ButtonClearSyncToyLogs = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TextLogs
            // 
            this.TextLogs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.TextLogs.BackColor = System.Drawing.Color.White;
            this.TextLogs.Location = new System.Drawing.Point(12, 12);
            this.TextLogs.Multiline = true;
            this.TextLogs.Name = "TextLogs";
            this.TextLogs.ReadOnly = true;
            this.TextLogs.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextLogs.Size = new System.Drawing.Size(605, 352);
            this.TextLogs.TabIndex = 0;
            // 
            // ButtonCloseSyncToyLogs
            // 
            this.ButtonCloseSyncToyLogs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonCloseSyncToyLogs.Location = new System.Drawing.Point(542, 381);
            this.ButtonCloseSyncToyLogs.Name = "ButtonCloseSyncToyLogs";
            this.ButtonCloseSyncToyLogs.Size = new System.Drawing.Size(75, 23);
            this.ButtonCloseSyncToyLogs.TabIndex = 0;
            this.ButtonCloseSyncToyLogs.Text = "Close";
            this.ButtonCloseSyncToyLogs.UseVisualStyleBackColor = true;
            this.ButtonCloseSyncToyLogs.Click += new System.EventHandler(this.CallBackClose);
            // 
            // ButtonClearSyncToyLogs
            // 
            this.ButtonClearSyncToyLogs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonClearSyncToyLogs.Location = new System.Drawing.Point(451, 381);
            this.ButtonClearSyncToyLogs.Name = "ButtonClearSyncToyLogs";
            this.ButtonClearSyncToyLogs.Size = new System.Drawing.Size(75, 23);
            this.ButtonClearSyncToyLogs.TabIndex = 1;
            this.ButtonClearSyncToyLogs.Text = "Clear Log";
            this.ButtonClearSyncToyLogs.UseVisualStyleBackColor = true;
            this.ButtonClearSyncToyLogs.Click += new System.EventHandler(this.CallBackClearLogs);
            // 
            // DialogSyncToyLogs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 416);
            this.Controls.Add(this.ButtonClearSyncToyLogs);
            this.Controls.Add(this.ButtonCloseSyncToyLogs);
            this.Controls.Add(this.TextLogs);
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(400, 200);
            this.Name = "DialogSyncToyLogs";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CRSyncFiles Log";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TextLogs;
        private System.Windows.Forms.Button ButtonCloseSyncToyLogs;
        private System.Windows.Forms.Button ButtonClearSyncToyLogs;
    }
}