﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using FileSyncUtility;
using SyncToyDesktopApp.Properties;
using Welemski.Utility;
using Welemski.IO;

namespace SyncToyDesktopApp {
    public partial class DialogSubFolders : Form {
        public DialogSubFolders() {
            InitializeComponent();
        }

        public DialogSubFolders(FileSyncPairInfo folderPair, FileSyncPairManager pairManager) {
            InitializeComponent();
            FolderPair = folderPair;
            PairManager = pairManager;
            LabelSourcePath.Text = FolderPair.LeftFolder;
            LabelDestinationPath.Text = FolderPair.RightFolder;
            LabelPairName.Text = FolderPair.FolderPairName;
            Text = Resources.TEXT_SELECT_SUBFOLDERS_FOR + FolderPair.FolderPairName;
        }

        public override sealed string Text
        {
            get { return base.Text; }
            set { base.Text = value; }
        }

        private void DialogSubFoldersLoad(object sender, EventArgs e) {
            InitializeTreeViews();
        }

        public FileSyncPairInfo FolderPair { get; set; }
        public FileSyncPairManager PairManager { get; set; }

        private void WindowResized(object sender, EventArgs e) {
            //This is the total free space we compare the total width between this window and the two treeviews.
            int defaultSpacer = 68; 

            //The viewable width for each treeview minus the spacer on each sides.
            int viewableWidth = (Width - defaultSpacer) / 2;

            LeftFolderTree.Width = viewableWidth;
            RightFolderTree.Width = viewableWidth;

            int rightFolderPosition = RightFolderTree.Location.X;
            LabelRightFolder.Left = rightFolderPosition;
        }

        private void InitializeFolderTree(string path, TreeNode parentTreeNode) {
            FileNode fileNode = new FileNode(path);
            List<FileNode> childNodes = fileNode.ChildNodes(null, false);
            foreach(FileNode childNode in childNodes){
                TreeNode treeNode = new TreeNode(childNode.FileName);

                //Temporarily set to true
                treeNode.Checked = true;

                parentTreeNode.Nodes.Add(treeNode);
                if(childNode.IsDirectory()){
                    treeNode.ExpandAll();
                    InitializeFolderTree(childNode.Path, treeNode);
                }
            }
            
        }

        private void InitializeTreeViews() {
            LeftFolderTree.Nodes.Clear();
            RightFolderTree.Nodes.Clear();

            LeftFolderTree.CheckBoxes = true;
            RightFolderTree.CheckBoxes = true;

            TreeNode leftTreeNode = new TreeNode(FolderPair.LeftFolder);
            TreeNode rightTreeNode = new TreeNode(FolderPair.RightFolder);

            //Temporarily set to true
            leftTreeNode.Checked = true;
            rightTreeNode.Checked = true;

            leftTreeNode.ExpandAll();
            rightTreeNode.ExpandAll();

            InitializeFolderTree(FolderPair.LeftFolder, leftTreeNode);
            InitializeFolderTree(FolderPair.RightFolder, rightTreeNode);

            LeftFolderTree.Nodes.Add(leftTreeNode);
            RightFolderTree.Nodes.Add(rightTreeNode);
        }

        private void ButtonCancelClick(object sender, EventArgs e) {
            Close();
        }

        
    }
}
