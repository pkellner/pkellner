﻿namespace SyncToyDesktopApp
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Active");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.PanelDefault = new System.Windows.Forms.Panel();
            this.PagesDefault = new System.Windows.Forms.TabControl();
            this.TabPageDefault = new System.Windows.Forms.TabPage();
            this.LinkSyncToyHelp = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.LinkCreateNewFolderPair = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.LabelLaunchTitle = new System.Windows.Forms.Label();
            this.PictureLaunchBackground = new System.Windows.Forms.PictureBox();
            this.TabPageFolderPairSettings = new System.Windows.Forms.TabPage();
            this.PanelOptions = new System.Windows.Forms.Panel();
            this.LinkChangeOptions = new System.Windows.Forms.LinkLabel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.shapeContainer3 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ovalShape7 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape6 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape5 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape4 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape3 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.LinkChangeAction = new System.Windows.Forms.LinkLabel();
            this.LabelLastRun = new System.Windows.Forms.Label();
            this.LabelSyncType = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.LabelDestinationPath = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.LabelSourcePath = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.LabelFolderPairName = new System.Windows.Forms.Label();
            this.PanelLeftFolderImage = new System.Windows.Forms.Panel();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.TabPageAllFolderPairs = new System.Windows.Forms.TabPage();
            this.ListViewAllFolderPairs = new System.Windows.Forms.ListView();
            this.ColumnHeaderActive = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ButtonRenameFolderPair = new System.Windows.Forms.Button();
            this.ButtonDeleteFolderPair = new System.Windows.Forms.Button();
            this.ButtonCreateNewFolderPair = new System.Windows.Forms.Button();
            this.ButtonPreview = new System.Windows.Forms.Button();
            this.ButtonRun = new System.Windows.Forms.Button();
            this.ListOfFolderPairs = new System.Windows.Forms.ListBox();
            this.MainMenuDefault = new System.Windows.Forms.MainMenu(this.components);
            this.MenuItemFile = new System.Windows.Forms.MenuItem();
            this.MenuItemViewLog = new System.Windows.Forms.MenuItem();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.MenuItemExit = new System.Windows.Forms.MenuItem();
            this.menuItem5 = new System.Windows.Forms.MenuItem();
            this.menuItem6 = new System.Windows.Forms.MenuItem();
            this.menuItem7 = new System.Windows.Forms.MenuItem();
            this.menuItem8 = new System.Windows.Forms.MenuItem();
            this.menuItem9 = new System.Windows.Forms.MenuItem();
            this.menuItem10 = new System.Windows.Forms.MenuItem();
            this.defaultItemFile = new System.Windows.Forms.ToolStripMenuItem();
            this.fileItemViewLog = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.fileItemExit = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.learnHowToScheduleSyncToyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.syncToyForumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerFeedbackOptionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutSyncToyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PanelHeaderImage = new System.Windows.Forms.Panel();
            this.PanelSyntoyHeader = new System.Windows.Forms.Panel();
            this.PanelDefault.SuspendLayout();
            this.PagesDefault.SuspendLayout();
            this.TabPageDefault.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureLaunchBackground)).BeginInit();
            this.TabPageFolderPairSettings.SuspendLayout();
            this.PanelOptions.SuspendLayout();
            this.TabPageAllFolderPairs.SuspendLayout();
            this.PanelSyntoyHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelDefault
            // 
            this.PanelDefault.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelDefault.BackColor = System.Drawing.Color.White;
            this.PanelDefault.Controls.Add(this.PagesDefault);
            this.PanelDefault.Location = new System.Drawing.Point(154, 62);
            this.PanelDefault.Name = "PanelDefault";
            this.PanelDefault.Size = new System.Drawing.Size(618, 511);
            this.PanelDefault.TabIndex = 2;
            // 
            // PagesDefault
            // 
            this.PagesDefault.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.PagesDefault.Controls.Add(this.TabPageDefault);
            this.PagesDefault.Controls.Add(this.TabPageFolderPairSettings);
            this.PagesDefault.Controls.Add(this.TabPageAllFolderPairs);
            this.PagesDefault.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PagesDefault.Location = new System.Drawing.Point(3, -19);
            this.PagesDefault.Name = "PagesDefault";
            this.PagesDefault.SelectedIndex = 0;
            this.PagesDefault.Size = new System.Drawing.Size(612, 517);
            this.PagesDefault.TabIndex = 100;
            this.PagesDefault.TabStop = false;
            // 
            // TabPageDefault
            // 
            this.TabPageDefault.BackColor = System.Drawing.Color.White;
            this.TabPageDefault.Controls.Add(this.LinkSyncToyHelp);
            this.TabPageDefault.Controls.Add(this.label2);
            this.TabPageDefault.Controls.Add(this.LinkCreateNewFolderPair);
            this.TabPageDefault.Controls.Add(this.label1);
            this.TabPageDefault.Controls.Add(this.LabelLaunchTitle);
            this.TabPageDefault.Controls.Add(this.PictureLaunchBackground);
            this.TabPageDefault.Location = new System.Drawing.Point(4, 22);
            this.TabPageDefault.Name = "TabPageDefault";
            this.TabPageDefault.Padding = new System.Windows.Forms.Padding(3);
            this.TabPageDefault.Size = new System.Drawing.Size(604, 491);
            this.TabPageDefault.TabIndex = 0;
            this.TabPageDefault.Text = "tabPage1";
            // 
            // LinkSyncToyHelp
            // 
            this.LinkSyncToyHelp.ActiveLinkColor = System.Drawing.Color.Red;
            this.LinkSyncToyHelp.AutoSize = true;
            this.LinkSyncToyHelp.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LinkSyncToyHelp.Location = new System.Drawing.Point(222, 74);
            this.LinkSyncToyHelp.Name = "LinkSyncToyHelp";
            this.LinkSyncToyHelp.Size = new System.Drawing.Size(95, 13);
            this.LinkSyncToyHelp.TabIndex = 1;
            this.LinkSyncToyHelp.TabStop = true;
            this.LinkSyncToyHelp.Text = "CRSyncFiles Help.";
            this.LinkSyncToyHelp.Click += new System.EventHandler(this.CallBackSyncToyHelp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label2.Location = new System.Drawing.Point(74, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "For help getting started, select";
            // 
            // LinkCreateNewFolderPair
            // 
            this.LinkCreateNewFolderPair.ActiveLinkColor = System.Drawing.Color.Red;
            this.LinkCreateNewFolderPair.AutoSize = true;
            this.LinkCreateNewFolderPair.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(68)))), ((int)(((byte)(121)))));
            this.LinkCreateNewFolderPair.Location = new System.Drawing.Point(258, 50);
            this.LinkCreateNewFolderPair.Name = "LinkCreateNewFolderPair";
            this.LinkCreateNewFolderPair.Size = new System.Drawing.Size(119, 13);
            this.LinkCreateNewFolderPair.TabIndex = 0;
            this.LinkCreateNewFolderPair.TabStop = true;
            this.LinkCreateNewFolderPair.Text = "Create New Folder Pair.";
            this.LinkCreateNewFolderPair.Click += new System.EventHandler(this.CallBackCreateNewFolderPair);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(68)))), ((int)(((byte)(121)))));
            this.label1.Location = new System.Drawing.Point(74, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "To start working with CRSyncFiles, select";
            // 
            // LabelLaunchTitle
            // 
            this.LabelLaunchTitle.AutoSize = true;
            this.LabelLaunchTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelLaunchTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(37)))), ((int)(((byte)(151)))));
            this.LabelLaunchTitle.Location = new System.Drawing.Point(56, 12);
            this.LabelLaunchTitle.Name = "LabelLaunchTitle";
            this.LabelLaunchTitle.Size = new System.Drawing.Size(190, 24);
            this.LabelLaunchTitle.TabIndex = 1;
            this.LabelLaunchTitle.Text = "Welcome to SyncToy";
            // 
            // PictureLaunchBackground
            // 
            this.PictureLaunchBackground.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_Launch_gif;
            this.PictureLaunchBackground.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PictureLaunchBackground.Location = new System.Drawing.Point(6, 68);
            this.PictureLaunchBackground.Name = "PictureLaunchBackground";
            this.PictureLaunchBackground.Size = new System.Drawing.Size(495, 323);
            this.PictureLaunchBackground.TabIndex = 0;
            this.PictureLaunchBackground.TabStop = false;
            // 
            // TabPageFolderPairSettings
            // 
            this.TabPageFolderPairSettings.BackColor = System.Drawing.Color.White;
            this.TabPageFolderPairSettings.Controls.Add(this.PanelOptions);
            this.TabPageFolderPairSettings.Controls.Add(this.LinkChangeAction);
            this.TabPageFolderPairSettings.Controls.Add(this.LabelLastRun);
            this.TabPageFolderPairSettings.Controls.Add(this.LabelSyncType);
            this.TabPageFolderPairSettings.Controls.Add(this.label6);
            this.TabPageFolderPairSettings.Controls.Add(this.LabelDestinationPath);
            this.TabPageFolderPairSettings.Controls.Add(this.panel3);
            this.TabPageFolderPairSettings.Controls.Add(this.panel2);
            this.TabPageFolderPairSettings.Controls.Add(this.label5);
            this.TabPageFolderPairSettings.Controls.Add(this.LabelSourcePath);
            this.TabPageFolderPairSettings.Controls.Add(this.panel1);
            this.TabPageFolderPairSettings.Controls.Add(this.label3);
            this.TabPageFolderPairSettings.Controls.Add(this.LabelFolderPairName);
            this.TabPageFolderPairSettings.Controls.Add(this.PanelLeftFolderImage);
            this.TabPageFolderPairSettings.Controls.Add(this.shapeContainer1);
            this.TabPageFolderPairSettings.Location = new System.Drawing.Point(4, 22);
            this.TabPageFolderPairSettings.Name = "TabPageFolderPairSettings";
            this.TabPageFolderPairSettings.Padding = new System.Windows.Forms.Padding(3);
            this.TabPageFolderPairSettings.Size = new System.Drawing.Size(604, 491);
            this.TabPageFolderPairSettings.TabIndex = 1;
            this.TabPageFolderPairSettings.Text = "tabPage2";
            // 
            // PanelOptions
            // 
            this.PanelOptions.BackColor = System.Drawing.Color.White;
            this.PanelOptions.Controls.Add(this.LinkChangeOptions);
            this.PanelOptions.Controls.Add(this.label14);
            this.PanelOptions.Controls.Add(this.label13);
            this.PanelOptions.Controls.Add(this.label12);
            this.PanelOptions.Controls.Add(this.label11);
            this.PanelOptions.Controls.Add(this.label10);
            this.PanelOptions.Controls.Add(this.label9);
            this.PanelOptions.Controls.Add(this.label8);
            this.PanelOptions.Controls.Add(this.label7);
            this.PanelOptions.Controls.Add(this.shapeContainer3);
            this.PanelOptions.Location = new System.Drawing.Point(17, 248);
            this.PanelOptions.Name = "PanelOptions";
            this.PanelOptions.Size = new System.Drawing.Size(571, 118);
            this.PanelOptions.TabIndex = 13;
            // 
            // LinkChangeOptions
            // 
            this.LinkChangeOptions.AutoSize = true;
            this.LinkChangeOptions.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LinkChangeOptions.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LinkChangeOptions.Location = new System.Drawing.Point(6, 94);
            this.LinkChangeOptions.Name = "LinkChangeOptions";
            this.LinkChangeOptions.Size = new System.Drawing.Size(90, 13);
            this.LinkChangeOptions.TabIndex = 23;
            this.LinkChangeOptions.TabStop = true;
            this.LinkChangeOptions.Text = "Change options...";
            this.LinkChangeOptions.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CallBackChangeOptions);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(112)))), ((int)(((byte)(172)))));
            this.label14.Location = new System.Drawing.Point(315, 48);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 13);
            this.label14.TabIndex = 22;
            this.label14.Text = "Active for run all";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(112)))), ((int)(((byte)(172)))));
            this.label13.Location = new System.Drawing.Point(315, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(191, 13);
            this.label13.TabIndex = 21;
            this.label13.Text = "Save overwritten files in the recycle bin";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(112)))), ((int)(((byte)(172)))));
            this.label12.Location = new System.Drawing.Point(183, 48);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(112, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "All subfolders included";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(112)))), ((int)(((byte)(172)))));
            this.label11.Location = new System.Drawing.Point(183, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "No files excluded";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(112)))), ((int)(((byte)(172)))));
            this.label10.Location = new System.Drawing.Point(24, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(129, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "No file attributes excluded";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(112)))), ((int)(((byte)(172)))));
            this.label9.Location = new System.Drawing.Point(24, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Do not check file contents";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(112)))), ((int)(((byte)(172)))));
            this.label8.Location = new System.Drawing.Point(24, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "All files included";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label7.Location = new System.Drawing.Point(3, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Options for this folder pair:";
            // 
            // shapeContainer3
            // 
            this.shapeContainer3.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer3.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer3.Name = "shapeContainer3";
            this.shapeContainer3.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ovalShape7,
            this.ovalShape6,
            this.ovalShape5,
            this.ovalShape4,
            this.ovalShape3,
            this.ovalShape2,
            this.ovalShape1});
            this.shapeContainer3.Size = new System.Drawing.Size(571, 118);
            this.shapeContainer3.TabIndex = 15;
            this.shapeContainer3.TabStop = false;
            // 
            // ovalShape7
            // 
            this.ovalShape7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape7.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape7.Location = new System.Drawing.Point(301, 51);
            this.ovalShape7.Name = "ovalShape7";
            this.ovalShape7.Size = new System.Drawing.Size(8, 8);
            // 
            // ovalShape6
            // 
            this.ovalShape6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape6.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape6.Location = new System.Drawing.Point(301, 30);
            this.ovalShape6.Name = "ovalShape6";
            this.ovalShape6.Size = new System.Drawing.Size(8, 8);
            // 
            // ovalShape5
            // 
            this.ovalShape5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape5.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape5.Location = new System.Drawing.Point(169, 51);
            this.ovalShape5.Name = "ovalShape5";
            this.ovalShape5.Size = new System.Drawing.Size(8, 8);
            // 
            // ovalShape4
            // 
            this.ovalShape4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape4.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape4.Location = new System.Drawing.Point(169, 30);
            this.ovalShape4.Name = "ovalShape4";
            this.ovalShape4.Size = new System.Drawing.Size(8, 8);
            // 
            // ovalShape3
            // 
            this.ovalShape3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape3.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape3.Location = new System.Drawing.Point(9, 73);
            this.ovalShape3.Name = "ovalShape3";
            this.ovalShape3.Size = new System.Drawing.Size(8, 8);
            // 
            // ovalShape2
            // 
            this.ovalShape2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape2.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape2.Location = new System.Drawing.Point(9, 51);
            this.ovalShape2.Name = "ovalShape2";
            this.ovalShape2.Size = new System.Drawing.Size(8, 8);
            // 
            // ovalShape1
            // 
            this.ovalShape1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ovalShape1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape1.Location = new System.Drawing.Point(9, 30);
            this.ovalShape1.Name = "ovalShape1";
            this.ovalShape1.Size = new System.Drawing.Size(8, 8);
            // 
            // LinkChangeAction
            // 
            this.LinkChangeAction.AutoSize = true;
            this.LinkChangeAction.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LinkChangeAction.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LinkChangeAction.Location = new System.Drawing.Point(16, 214);
            this.LinkChangeAction.Name = "LinkChangeAction";
            this.LinkChangeAction.Size = new System.Drawing.Size(85, 13);
            this.LinkChangeAction.TabIndex = 12;
            this.LinkChangeAction.TabStop = true;
            this.LinkChangeAction.Text = "Change action...";
            this.LinkChangeAction.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ChangeAction);
            // 
            // LabelLastRun
            // 
            this.LabelLastRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelLastRun.Location = new System.Drawing.Point(381, 462);
            this.LabelLastRun.Name = "LabelLastRun";
            this.LabelLastRun.Size = new System.Drawing.Size(207, 23);
            this.LabelLastRun.TabIndex = 11;
            this.LabelLastRun.Text = "--:--";
            this.LabelLastRun.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // LabelSyncType
            // 
            this.LabelSyncType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelSyncType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LabelSyncType.Location = new System.Drawing.Point(97, 199);
            this.LabelSyncType.Name = "LabelSyncType";
            this.LabelSyncType.Size = new System.Drawing.Size(160, 13);
            this.LabelSyncType.TabIndex = 10;
            this.LabelSyncType.Text = "<SyncToy Action>";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label6.Location = new System.Drawing.Point(16, 199);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "SyncToy Action:";
            // 
            // LabelDestinationPath
            // 
            this.LabelDestinationPath.Location = new System.Drawing.Point(354, 173);
            this.LabelDestinationPath.Name = "LabelDestinationPath";
            this.LabelDestinationPath.Size = new System.Drawing.Size(223, 16);
            this.LabelDestinationPath.TabIndex = 8;
            this.LabelDestinationPath.Text = "label4";
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_Rightgraphic1;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel3.Location = new System.Drawing.Point(329, 77);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(70, 72);
            this.panel3.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_folder;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(329, 173);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(19, 16);
            this.panel2.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label5.Location = new System.Drawing.Point(326, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Right Folder:";
            // 
            // LabelSourcePath
            // 
            this.LabelSourcePath.Location = new System.Drawing.Point(44, 173);
            this.LabelSourcePath.Name = "LabelSourcePath";
            this.LabelSourcePath.Size = new System.Drawing.Size(223, 16);
            this.LabelSourcePath.TabIndex = 4;
            this.LabelSourcePath.Text = "label4";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_folder;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(19, 173);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(19, 16);
            this.panel1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label3.Location = new System.Drawing.Point(16, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Left Folder:";
            // 
            // LabelFolderPairName
            // 
            this.LabelFolderPairName.AutoSize = true;
            this.LabelFolderPairName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelFolderPairName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.LabelFolderPairName.Location = new System.Drawing.Point(15, 23);
            this.LabelFolderPairName.Name = "LabelFolderPairName";
            this.LabelFolderPairName.Size = new System.Drawing.Size(167, 20);
            this.LabelFolderPairName.TabIndex = 1;
            this.LabelFolderPairName.Text = "<Folder Pair Name>";
            // 
            // PanelLeftFolderImage
            // 
            this.PanelLeftFolderImage.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_LeftGraphic1;
            this.PanelLeftFolderImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelLeftFolderImage.Location = new System.Drawing.Point(19, 77);
            this.PanelLeftFolderImage.Name = "PanelLeftFolderImage";
            this.PanelLeftFolderImage.Size = new System.Drawing.Size(70, 72);
            this.PanelLeftFolderImage.TabIndex = 0;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape3,
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(589, 485);
            this.shapeContainer1.TabIndex = 2;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape3
            // 
            this.lineShape3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(154)))), ((int)(((byte)(192)))));
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 15;
            this.lineShape3.X2 = 574;
            this.lineShape3.Y1 = 236;
            this.lineShape3.Y2 = 236;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(217)))), ((int)(((byte)(253)))));
            this.lineShape1.BorderWidth = 2;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 14;
            this.lineShape1.X2 = 575;
            this.lineShape1.Y1 = 52;
            this.lineShape1.Y2 = 52;
            // 
            // TabPageAllFolderPairs
            // 
            this.TabPageAllFolderPairs.BackColor = System.Drawing.Color.White;
            this.TabPageAllFolderPairs.Controls.Add(this.ListViewAllFolderPairs);
            this.TabPageAllFolderPairs.Controls.Add(this.panel5);
            this.TabPageAllFolderPairs.Controls.Add(this.panel4);
            this.TabPageAllFolderPairs.Controls.Add(this.label4);
            this.TabPageAllFolderPairs.Controls.Add(this.shapeContainer2);
            this.TabPageAllFolderPairs.Location = new System.Drawing.Point(4, 22);
            this.TabPageAllFolderPairs.Name = "TabPageAllFolderPairs";
            this.TabPageAllFolderPairs.Padding = new System.Windows.Forms.Padding(3);
            this.TabPageAllFolderPairs.Size = new System.Drawing.Size(604, 491);
            this.TabPageAllFolderPairs.TabIndex = 2;
            this.TabPageAllFolderPairs.Text = "tabPage1";
            // 
            // ListViewAllFolderPairs
            // 
            this.ListViewAllFolderPairs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ListViewAllFolderPairs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColumnHeaderActive});
            this.ListViewAllFolderPairs.FullRowSelect = true;
            this.ListViewAllFolderPairs.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.ListViewAllFolderPairs.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.ListViewAllFolderPairs.Location = new System.Drawing.Point(19, 156);
            this.ListViewAllFolderPairs.MultiSelect = false;
            this.ListViewAllFolderPairs.Name = "ListViewAllFolderPairs";
            this.ListViewAllFolderPairs.Size = new System.Drawing.Size(560, 263);
            this.ListViewAllFolderPairs.TabIndex = 7;
            this.ListViewAllFolderPairs.UseCompatibleStateImageBehavior = false;
            this.ListViewAllFolderPairs.View = System.Windows.Forms.View.Details;
            // 
            // ColumnHeaderActive
            // 
            this.ColumnHeaderActive.Text = "Active";
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_Rightgraphic1;
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel5.Location = new System.Drawing.Point(297, 80);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(72, 70);
            this.panel5.TabIndex = 6;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_LeftGraphic1;
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel4.Location = new System.Drawing.Point(18, 80);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(72, 70);
            this.panel4.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label4.Location = new System.Drawing.Point(15, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "All Folder Pairs";
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape2});
            this.shapeContainer2.Size = new System.Drawing.Size(589, 485);
            this.shapeContainer2.TabIndex = 3;
            this.shapeContainer2.TabStop = false;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(217)))), ((int)(((byte)(253)))));
            this.lineShape2.BorderWidth = 2;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 14;
            this.lineShape2.X2 = 575;
            this.lineShape2.Y1 = 52;
            this.lineShape2.Y2 = 52;
            // 
            // ButtonRenameFolderPair
            // 
            this.ButtonRenameFolderPair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ButtonRenameFolderPair.Location = new System.Drawing.Point(152, 586);
            this.ButtonRenameFolderPair.Name = "ButtonRenameFolderPair";
            this.ButtonRenameFolderPair.Size = new System.Drawing.Size(126, 23);
            this.ButtonRenameFolderPair.TabIndex = 3;
            this.ButtonRenameFolderPair.Text = "Rename Folder Pair";
            this.ButtonRenameFolderPair.UseVisualStyleBackColor = true;
            this.ButtonRenameFolderPair.Click += new System.EventHandler(this.CallBackRenameFolderPair);
            // 
            // ButtonDeleteFolderPair
            // 
            this.ButtonDeleteFolderPair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ButtonDeleteFolderPair.Location = new System.Drawing.Point(284, 586);
            this.ButtonDeleteFolderPair.Name = "ButtonDeleteFolderPair";
            this.ButtonDeleteFolderPair.Size = new System.Drawing.Size(126, 23);
            this.ButtonDeleteFolderPair.TabIndex = 4;
            this.ButtonDeleteFolderPair.Text = "Delete Folder Pair";
            this.ButtonDeleteFolderPair.UseVisualStyleBackColor = true;
            this.ButtonDeleteFolderPair.Click += new System.EventHandler(this.CallBackDeleteFolderPair);
            // 
            // ButtonCreateNewFolderPair
            // 
            this.ButtonCreateNewFolderPair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ButtonCreateNewFolderPair.Location = new System.Drawing.Point(416, 586);
            this.ButtonCreateNewFolderPair.Name = "ButtonCreateNewFolderPair";
            this.ButtonCreateNewFolderPair.Size = new System.Drawing.Size(126, 23);
            this.ButtonCreateNewFolderPair.TabIndex = 5;
            this.ButtonCreateNewFolderPair.Text = "Create New Folder Pair";
            this.ButtonCreateNewFolderPair.UseVisualStyleBackColor = true;
            this.ButtonCreateNewFolderPair.Click += new System.EventHandler(this.CallBackCreateNewFolderPair);
            // 
            // ButtonPreview
            // 
            this.ButtonPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonPreview.Location = new System.Drawing.Point(608, 586);
            this.ButtonPreview.Name = "ButtonPreview";
            this.ButtonPreview.Size = new System.Drawing.Size(72, 23);
            this.ButtonPreview.TabIndex = 6;
            this.ButtonPreview.Text = "Preview";
            this.ButtonPreview.UseVisualStyleBackColor = true;
            this.ButtonPreview.Click += new System.EventHandler(this.CallBackPreview);
            // 
            // ButtonRun
            // 
            this.ButtonRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonRun.Location = new System.Drawing.Point(686, 586);
            this.ButtonRun.Name = "ButtonRun";
            this.ButtonRun.Size = new System.Drawing.Size(72, 23);
            this.ButtonRun.TabIndex = 7;
            this.ButtonRun.Text = "Run";
            this.ButtonRun.UseVisualStyleBackColor = true;
            this.ButtonRun.Click += new System.EventHandler(this.CallBackRun);
            // 
            // ListOfFolderPairs
            // 
            this.ListOfFolderPairs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ListOfFolderPairs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(228)))), ((int)(((byte)(251)))));
            this.ListOfFolderPairs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ListOfFolderPairs.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ListOfFolderPairs.ForeColor = System.Drawing.Color.Lavender;
            this.ListOfFolderPairs.FormattingEnabled = true;
            this.ListOfFolderPairs.HorizontalScrollbar = true;
            this.ListOfFolderPairs.ItemHeight = 25;
            this.ListOfFolderPairs.Location = new System.Drawing.Point(0, 62);
            this.ListOfFolderPairs.Name = "ListOfFolderPairs";
            this.ListOfFolderPairs.Size = new System.Drawing.Size(155, 500);
            this.ListOfFolderPairs.TabIndex = 2;
            this.ListOfFolderPairs.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.CallBackDrawItemForListOfFolderPairs);
            this.ListOfFolderPairs.SelectedIndexChanged += new System.EventHandler(this.CallBackFolderPairSelection);
            // 
            // MainMenuDefault
            // 
            this.MainMenuDefault.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.MenuItemFile,
            this.menuItem5});
            // 
            // MenuItemFile
            // 
            this.MenuItemFile.Index = 0;
            this.MenuItemFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.MenuItemViewLog,
            this.menuItem3,
            this.MenuItemExit});
            this.MenuItemFile.Text = "File";
            // 
            // MenuItemViewLog
            // 
            this.MenuItemViewLog.Index = 0;
            this.MenuItemViewLog.Text = "View Log";
            this.MenuItemViewLog.Click += new System.EventHandler(this.CallBackViewLog);
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 1;
            this.menuItem3.Text = "-";
            // 
            // MenuItemExit
            // 
            this.MenuItemExit.Index = 2;
            this.MenuItemExit.Shortcut = System.Windows.Forms.Shortcut.CtrlX;
            this.MenuItemExit.Text = "Exit";
            this.MenuItemExit.Click += new System.EventHandler(this.CallBackExit);
            // 
            // menuItem5
            // 
            this.menuItem5.Index = 1;
            this.menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem6,
            this.menuItem7,
            this.menuItem8,
            this.menuItem9,
            this.menuItem10});
            this.menuItem5.Text = "Help";
            // 
            // menuItem6
            // 
            this.menuItem6.Index = 0;
            this.menuItem6.Shortcut = System.Windows.Forms.Shortcut.F1;
            this.menuItem6.Text = "CRSyncFiles Help...";
            this.menuItem6.Click += new System.EventHandler(this.CallBackSyncToyHelp);
            // 
            // menuItem7
            // 
            this.menuItem7.Index = 1;
            this.menuItem7.Text = "Learn How to Schedule CRSyncFiles...";
            this.menuItem7.Click += new System.EventHandler(this.CallBackScheduleSyncToy);
            // 
            // menuItem8
            // 
            this.menuItem8.Index = 2;
            this.menuItem8.Text = "CRSyncFiles Forum";
            this.menuItem8.Click += new System.EventHandler(this.CallBackForum);
            // 
            // menuItem9
            // 
            this.menuItem9.Index = 3;
            this.menuItem9.Text = "Customer Feedback Options";
            this.menuItem9.Click += new System.EventHandler(this.CallBackCustomerFeedbackOptions);
            // 
            // menuItem10
            // 
            this.menuItem10.Index = 4;
            this.menuItem10.Text = "About CRSyncFiles...";
            this.menuItem10.Click += new System.EventHandler(this.CallBackAbout);
            // 
            // defaultItemFile
            // 
            this.defaultItemFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.defaultItemFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.defaultItemFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileItemViewLog,
            this.toolStripSeparator1,
            this.fileItemExit});
            this.defaultItemFile.Name = "defaultItemFile";
            this.defaultItemFile.Size = new System.Drawing.Size(35, 20);
            this.defaultItemFile.Text = "File";
            // 
            // fileItemViewLog
            // 
            this.fileItemViewLog.Name = "fileItemViewLog";
            this.fileItemViewLog.Size = new System.Drawing.Size(133, 22);
            this.fileItemViewLog.Text = "View log";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(130, 6);
            // 
            // fileItemExit
            // 
            this.fileItemExit.Name = "fileItemExit";
            this.fileItemExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.fileItemExit.Size = new System.Drawing.Size(133, 22);
            this.fileItemExit.Text = "Exit";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewHelpToolStripMenuItem,
            this.learnHowToScheduleSyncToyToolStripMenuItem,
            this.syncToyForumToolStripMenuItem,
            this.customerFeedbackOptionsToolStripMenuItem,
            this.aboutSyncToyToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // viewHelpToolStripMenuItem
            // 
            this.viewHelpToolStripMenuItem.Name = "viewHelpToolStripMenuItem";
            this.viewHelpToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.viewHelpToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.viewHelpToolStripMenuItem.Text = "SyncToy Help...";
            // 
            // learnHowToScheduleSyncToyToolStripMenuItem
            // 
            this.learnHowToScheduleSyncToyToolStripMenuItem.Name = "learnHowToScheduleSyncToyToolStripMenuItem";
            this.learnHowToScheduleSyncToyToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.learnHowToScheduleSyncToyToolStripMenuItem.Text = "Learn How to Schedule SyncToy...";
            // 
            // syncToyForumToolStripMenuItem
            // 
            this.syncToyForumToolStripMenuItem.Name = "syncToyForumToolStripMenuItem";
            this.syncToyForumToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.syncToyForumToolStripMenuItem.Text = "SyncToy Forum";
            // 
            // customerFeedbackOptionsToolStripMenuItem
            // 
            this.customerFeedbackOptionsToolStripMenuItem.Name = "customerFeedbackOptionsToolStripMenuItem";
            this.customerFeedbackOptionsToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.customerFeedbackOptionsToolStripMenuItem.Text = "Customer Feedback Options";
            // 
            // aboutSyncToyToolStripMenuItem
            // 
            this.aboutSyncToyToolStripMenuItem.Name = "aboutSyncToyToolStripMenuItem";
            this.aboutSyncToyToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.aboutSyncToyToolStripMenuItem.Text = "About SyncToy...";
            // 
            // PanelHeaderImage
            // 
            this.PanelHeaderImage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelHeaderImage.BackColor = System.Drawing.Color.Transparent;
            this.PanelHeaderImage.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.CRSyncFiles_Logo_Text;
            this.PanelHeaderImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelHeaderImage.Location = new System.Drawing.Point(481, 8);
            this.PanelHeaderImage.Name = "PanelHeaderImage";
            this.PanelHeaderImage.Size = new System.Drawing.Size(284, 46);
            this.PanelHeaderImage.TabIndex = 0;
            // 
            // PanelSyntoyHeader
            // 
            this.PanelSyntoyHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelSyntoyHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(156)))), ((int)(((byte)(198)))));
            this.PanelSyntoyHeader.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.syncToyGradientBar;
            this.PanelSyntoyHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PanelSyntoyHeader.Controls.Add(this.PanelHeaderImage);
            this.PanelSyntoyHeader.Location = new System.Drawing.Point(-9, 0);
            this.PanelSyntoyHeader.Name = "PanelSyntoyHeader";
            this.PanelSyntoyHeader.Size = new System.Drawing.Size(781, 64);
            this.PanelSyntoyHeader.TabIndex = 0;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(228)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(771, 614);
            this.Controls.Add(this.PanelSyntoyHeader);
            this.Controls.Add(this.ListOfFolderPairs);
            this.Controls.Add(this.ButtonRun);
            this.Controls.Add(this.ButtonPreview);
            this.Controls.Add(this.ButtonCreateNewFolderPair);
            this.Controls.Add(this.ButtonDeleteFolderPair);
            this.Controls.Add(this.ButtonRenameFolderPair);
            this.Controls.Add(this.PanelDefault);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Menu = this.MainMenuDefault;
            this.MinimumSize = new System.Drawing.Size(766, 570);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SyncToyKellner";
            this.Load += new System.EventHandler(this.MainLoad);
            this.Resize += new System.EventHandler(this.MainWindowResized);
            this.PanelDefault.ResumeLayout(false);
            this.PagesDefault.ResumeLayout(false);
            this.TabPageDefault.ResumeLayout(false);
            this.TabPageDefault.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureLaunchBackground)).EndInit();
            this.TabPageFolderPairSettings.ResumeLayout(false);
            this.TabPageFolderPairSettings.PerformLayout();
            this.PanelOptions.ResumeLayout(false);
            this.PanelOptions.PerformLayout();
            this.TabPageAllFolderPairs.ResumeLayout(false);
            this.TabPageAllFolderPairs.PerformLayout();
            this.PanelSyntoyHeader.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem defaultItemFile;
        private System.Windows.Forms.ToolStripMenuItem fileItemViewLog;
        private System.Windows.Forms.ToolStripMenuItem fileItemExit;
        private System.Windows.Forms.Panel PanelDefault;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem learnHowToScheduleSyncToyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem syncToyForumToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerFeedbackOptionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutSyncToyToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Button ButtonRenameFolderPair;
        private System.Windows.Forms.Button ButtonDeleteFolderPair;
        private System.Windows.Forms.Button ButtonCreateNewFolderPair;
        private System.Windows.Forms.Button ButtonRun;
        private System.Windows.Forms.Button ButtonPreview;
        private System.Windows.Forms.ListBox ListOfFolderPairs;
        private System.Windows.Forms.MainMenu MainMenuDefault;
        private System.Windows.Forms.MenuItem MenuItemFile;
        private System.Windows.Forms.MenuItem MenuItemViewLog;
        private System.Windows.Forms.MenuItem menuItem3;
        private System.Windows.Forms.MenuItem MenuItemExit;
        private System.Windows.Forms.MenuItem menuItem5;
        private System.Windows.Forms.MenuItem menuItem6;
        private System.Windows.Forms.MenuItem menuItem7;
        private System.Windows.Forms.MenuItem menuItem8;
        private System.Windows.Forms.MenuItem menuItem9;
        private System.Windows.Forms.MenuItem menuItem10;
        private System.Windows.Forms.TabControl PagesDefault;
        private System.Windows.Forms.TabPage TabPageDefault;
        private System.Windows.Forms.TabPage TabPageFolderPairSettings;
        private System.Windows.Forms.PictureBox PictureLaunchBackground;
        private System.Windows.Forms.Label LabelLaunchTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel LinkCreateNewFolderPair;
        private System.Windows.Forms.LinkLabel LinkSyncToyHelp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel PanelLeftFolderImage;
        private System.Windows.Forms.Label LabelFolderPairName;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label LabelSourcePath;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LabelDestinationPath;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label LabelSyncType;
        private System.Windows.Forms.TabPage TabPageAllFolderPairs;
        private System.Windows.Forms.Label label4;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private System.Windows.Forms.Label LabelLastRun;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ListView ListViewAllFolderPairs;
        private System.Windows.Forms.ColumnHeader ColumnHeaderActive;
        private System.Windows.Forms.LinkLabel LinkChangeAction;
        private System.Windows.Forms.Panel PanelOptions;
        private System.Windows.Forms.Label label7;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer3;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape3;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape4;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape7;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape6;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape5;
        private System.Windows.Forms.LinkLabel LinkChangeOptions;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private System.Windows.Forms.Panel PanelHeaderImage;
        private System.Windows.Forms.Panel PanelSyntoyHeader;
    }
}

