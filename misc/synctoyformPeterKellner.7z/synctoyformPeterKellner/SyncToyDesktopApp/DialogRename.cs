﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SyncToyDesktopApp.Properties;
using Welemski.Utility;
using System.Text.RegularExpressions;

namespace SyncToyDesktopApp {
    public partial class DialogRename : Form {
        public DialogRename() {
            InitializeComponent();
        }

        public string FolderPairName{
            get {
                return TextBoxFolderPairName.Text;
            }

            set {
                TextBoxFolderPairName.Text = value;
            }
        }

        public string FolderDatabaseName { get; set; }

        private void CancelRename(object sender, EventArgs e) {
            DialogResult = DialogResult.Cancel;
        }

        private void RenameFolderPair(object sender, EventArgs e) {
            FileSyncPairManager pairManager = new FileSyncPairManager(FolderDatabaseName);
            string newFolderPairName = TextBoxFolderPairName.Text;
            if(Regex.Match(newFolderPairName,@"[a-zA-Z0-9].*\s*").Success){
                if (pairManager.HasFolderPairNamed(newFolderPairName)) {
                    MessageBox.Show(Resources.ERROR_FOLDER_PAIR_NAME, Resources.TEXT_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information);
                } else {
                    FolderPairName = newFolderPairName;
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }else{
                MessageBox.Show(Resources.ERROR_FOLDER_PAIR_NAME, Resources.TEXT_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
