﻿namespace SyncToyDesktopApp {
    partial class DialogChangeOption {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.PanelHeader = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LinkSelectSubFolder = new System.Windows.Forms.LinkLabel();
            this.CheckExcludeSystemFiles = new System.Windows.Forms.CheckBox();
            this.CheckExcludeHiddenFiles = new System.Windows.Forms.CheckBox();
            this.CheckExcludeReadOnlyFiles = new System.Windows.Forms.CheckBox();
            this.TextBoxExclusion = new System.Windows.Forms.TextBox();
            this.TextBoxInclusion = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CheckActiveForRunAll = new System.Windows.Forms.CheckBox();
            this.CheckSaveOverWrittenInRecyclebin = new System.Windows.Forms.CheckBox();
            this.CheckFileContents = new System.Windows.Forms.CheckBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ButtonOK = new System.Windows.Forms.Button();
            this.ButtonCancel = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelHeader
            // 
            this.PanelHeader.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.syncToyGradientBar;
            this.PanelHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PanelHeader.Location = new System.Drawing.Point(-7, -2);
            this.PanelHeader.Name = "PanelHeader";
            this.PanelHeader.Size = new System.Drawing.Size(535, 59);
            this.PanelHeader.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(15, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select the options you want:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.LinkSelectSubFolder);
            this.groupBox1.Controls.Add(this.CheckExcludeSystemFiles);
            this.groupBox1.Controls.Add(this.CheckExcludeHiddenFiles);
            this.groupBox1.Controls.Add(this.CheckExcludeReadOnlyFiles);
            this.groupBox1.Controls.Add(this.TextBoxExclusion);
            this.groupBox1.Controls.Add(this.TextBoxInclusion);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(18, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(411, 143);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Inclusion/Exclusion";
            // 
            // LinkSelectSubFolder
            // 
            this.LinkSelectSubFolder.AutoSize = true;
            this.LinkSelectSubFolder.LinkColor = System.Drawing.Color.DarkBlue;
            this.LinkSelectSubFolder.Location = new System.Drawing.Point(9, 124);
            this.LinkSelectSubFolder.Name = "LinkSelectSubFolder";
            this.LinkSelectSubFolder.Size = new System.Drawing.Size(83, 13);
            this.LinkSelectSubFolder.TabIndex = 7;
            this.LinkSelectSubFolder.TabStop = true;
            this.LinkSelectSubFolder.Text = "Select subfolder";
            this.LinkSelectSubFolder.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkSelectSubFolderLinkClicked);
            // 
            // CheckExcludeSystemFiles
            // 
            this.CheckExcludeSystemFiles.AutoSize = true;
            this.CheckExcludeSystemFiles.Location = new System.Drawing.Point(272, 79);
            this.CheckExcludeSystemFiles.Name = "CheckExcludeSystemFiles";
            this.CheckExcludeSystemFiles.Size = new System.Drawing.Size(120, 17);
            this.CheckExcludeSystemFiles.TabIndex = 6;
            this.CheckExcludeSystemFiles.Text = "Exclude system files";
            this.CheckExcludeSystemFiles.UseVisualStyleBackColor = true;
            // 
            // CheckExcludeHiddenFiles
            // 
            this.CheckExcludeHiddenFiles.AutoSize = true;
            this.CheckExcludeHiddenFiles.Location = new System.Drawing.Point(146, 79);
            this.CheckExcludeHiddenFiles.Name = "CheckExcludeHiddenFiles";
            this.CheckExcludeHiddenFiles.Size = new System.Drawing.Size(120, 17);
            this.CheckExcludeHiddenFiles.TabIndex = 5;
            this.CheckExcludeHiddenFiles.Text = "Exclude hidden files";
            this.CheckExcludeHiddenFiles.UseVisualStyleBackColor = true;
            // 
            // CheckExcludeReadOnlyFiles
            // 
            this.CheckExcludeReadOnlyFiles.AutoSize = true;
            this.CheckExcludeReadOnlyFiles.Location = new System.Drawing.Point(9, 79);
            this.CheckExcludeReadOnlyFiles.Name = "CheckExcludeReadOnlyFiles";
            this.CheckExcludeReadOnlyFiles.Size = new System.Drawing.Size(131, 17);
            this.CheckExcludeReadOnlyFiles.TabIndex = 4;
            this.CheckExcludeReadOnlyFiles.Text = "Exclude read-only files";
            this.CheckExcludeReadOnlyFiles.UseVisualStyleBackColor = true;
            // 
            // TextBoxExclusion
            // 
            this.TextBoxExclusion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxExclusion.Location = new System.Drawing.Point(167, 42);
            this.TextBoxExclusion.Name = "TextBoxExclusion";
            this.TextBoxExclusion.Size = new System.Drawing.Size(129, 22);
            this.TextBoxExclusion.TabIndex = 3;
            // 
            // TextBoxInclusion
            // 
            this.TextBoxInclusion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxInclusion.Location = new System.Drawing.Point(9, 42);
            this.TextBoxInclusion.Name = "TextBoxInclusion";
            this.TextBoxInclusion.Size = new System.Drawing.Size(129, 22);
            this.TextBoxInclusion.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(164, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Files to exclude:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Files to include:";
            // 
            // CheckActiveForRunAll
            // 
            this.CheckActiveForRunAll.AutoSize = true;
            this.CheckActiveForRunAll.Location = new System.Drawing.Point(18, 255);
            this.CheckActiveForRunAll.Name = "CheckActiveForRunAll";
            this.CheckActiveForRunAll.Size = new System.Drawing.Size(102, 17);
            this.CheckActiveForRunAll.TabIndex = 8;
            this.CheckActiveForRunAll.Text = "Active for run all";
            this.CheckActiveForRunAll.UseVisualStyleBackColor = true;
            // 
            // CheckSaveOverWrittenInRecyclebin
            // 
            this.CheckSaveOverWrittenInRecyclebin.AutoSize = true;
            this.CheckSaveOverWrittenInRecyclebin.Location = new System.Drawing.Point(164, 255);
            this.CheckSaveOverWrittenInRecyclebin.Name = "CheckSaveOverWrittenInRecyclebin";
            this.CheckSaveOverWrittenInRecyclebin.Size = new System.Drawing.Size(216, 17);
            this.CheckSaveOverWrittenInRecyclebin.TabIndex = 9;
            this.CheckSaveOverWrittenInRecyclebin.Text = "Save overwritten files in the Recycle Bin";
            this.CheckSaveOverWrittenInRecyclebin.UseVisualStyleBackColor = true;
            // 
            // CheckFileContents
            // 
            this.CheckFileContents.AutoSize = true;
            this.CheckFileContents.Location = new System.Drawing.Point(18, 278);
            this.CheckFileContents.Name = "CheckFileContents";
            this.CheckFileContents.Size = new System.Drawing.Size(117, 17);
            this.CheckFileContents.TabIndex = 10;
            this.CheckFileContents.Text = "Check file contents";
            this.CheckFileContents.UseVisualStyleBackColor = true;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(441, 381);
            this.shapeContainer1.TabIndex = 11;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(112)))), ((int)(((byte)(172)))));
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 18;
            this.lineShape1.X2 = 429;
            this.lineShape1.Y1 = 317;
            this.lineShape1.Y2 = 317;
            // 
            // ButtonOK
            // 
            this.ButtonOK.Location = new System.Drawing.Point(271, 346);
            this.ButtonOK.Name = "ButtonOK";
            this.ButtonOK.Size = new System.Drawing.Size(75, 23);
            this.ButtonOK.TabIndex = 12;
            this.ButtonOK.Text = "OK";
            this.ButtonOK.UseVisualStyleBackColor = true;
            this.ButtonOK.Click += new System.EventHandler(this.CallBackOk);
            // 
            // ButtonCancel
            // 
            this.ButtonCancel.Location = new System.Drawing.Point(352, 346);
            this.ButtonCancel.Name = "ButtonCancel";
            this.ButtonCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonCancel.TabIndex = 13;
            this.ButtonCancel.Text = "Cancel";
            this.ButtonCancel.UseVisualStyleBackColor = true;
            this.ButtonCancel.Click += new System.EventHandler(this.CallBackCancel);
            // 
            // DialogChangeOption
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 381);
            this.Controls.Add(this.ButtonCancel);
            this.Controls.Add(this.ButtonOK);
            this.Controls.Add(this.CheckFileContents);
            this.Controls.Add(this.CheckSaveOverWrittenInRecyclebin);
            this.Controls.Add(this.CheckActiveForRunAll);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PanelHeader);
            this.Controls.Add(this.shapeContainer1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(457, 419);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(457, 419);
            this.Name = "DialogChangeOption";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Change Options for <Name>";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PanelHeader;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TextBoxExclusion;
        private System.Windows.Forms.TextBox TextBoxInclusion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox CheckExcludeReadOnlyFiles;
        private System.Windows.Forms.CheckBox CheckExcludeHiddenFiles;
        private System.Windows.Forms.CheckBox CheckExcludeSystemFiles;
        private System.Windows.Forms.LinkLabel LinkSelectSubFolder;
        private System.Windows.Forms.CheckBox CheckActiveForRunAll;
        private System.Windows.Forms.CheckBox CheckSaveOverWrittenInRecyclebin;
        private System.Windows.Forms.CheckBox CheckFileContents;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Button ButtonOK;
        private System.Windows.Forms.Button ButtonCancel;
    }
}