﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using FileSyncUtility;
using SyncToyDesktopApp.Properties;
using Welemski.Utility;

namespace SyncToyDesktopApp {
    public partial class DialogChangeOption : Form {
        public DialogChangeOption() {
            InitializeComponent();
        }

        public DialogChangeOption(FileSyncPairInfo folderPair, FileSyncPairManager pairManager) {
            InitializeComponent();
            FolderPair = folderPair;
            PairManager = pairManager;
            Text = Resources.TEXT_CHANGE_OPTIONS_FOR + FolderPair.FolderPairName;
            Init();
        }

        public FileSyncPairInfo FolderPair { get; set; }
        public FileSyncPairManager PairManager { get; set; }


        private void Init() {
            TextBoxInclusion.Text = FolderPair.FileNamesToInclude;
            TextBoxExclusion.Text = FolderPair.FileNamesToExclude;

            CheckExcludeReadOnlyFiles.Checked = FolderPair.FileExcludeAttrReadOnly;
            CheckExcludeHiddenFiles.Checked = FolderPair.FileExcludeAttrHidden;
            CheckExcludeSystemFiles.Checked = FolderPair.FileExcludeAttrSystem;
            CheckActiveForRunAll.Checked = FolderPair.ActiveForRunAll;
            CheckSaveOverWrittenInRecyclebin.Checked = FolderPair.OptionsRecycleConflictLoserFiles;
            CheckFileContents.Checked = FolderPair.OptionsCompareFileStreams;

        }

        private void CallBackOk(object sender, EventArgs e) {

            FolderPair.FileNamesToInclude = TextBoxInclusion.Text;
            FolderPair.FileNamesToExclude = TextBoxExclusion.Text;

            FolderPair.FileExcludeAttrReadOnly = CheckExcludeReadOnlyFiles.Checked;
            FolderPair.FileExcludeAttrHidden = CheckExcludeHiddenFiles.Checked;
            FolderPair.FileExcludeAttrSystem = CheckExcludeSystemFiles.Checked ;
            FolderPair.ActiveForRunAll = CheckActiveForRunAll.Checked;
            FolderPair.OptionsRecycleConflictLoserFiles = CheckSaveOverWrittenInRecyclebin.Checked;
            FolderPair.OptionsCompareFileStreams = CheckFileContents.Checked;

            PairManager.UpdateFolderPairNamed(FolderPair.FolderPairName, FolderPair);

            DialogResult = DialogResult.OK;
            Close();
        }

        private void CallBackCancel(object sender, EventArgs e) {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void LinkSelectSubFolderLinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            DialogSubFolders subFolderTree = new DialogSubFolders(FolderPair,PairManager);
            subFolderTree.ShowDialog(this);
        }
    }
}
