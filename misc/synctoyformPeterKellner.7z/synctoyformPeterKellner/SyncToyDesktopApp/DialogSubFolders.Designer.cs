﻿namespace SyncToyDesktopApp {
    partial class DialogSubFolders {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.label1 = new System.Windows.Forms.Label();
            this.LeftFolderTree = new System.Windows.Forms.TreeView();
            this.RightFolderTree = new System.Windows.Forms.TreeView();
            this.label2 = new System.Windows.Forms.Label();
            this.LabelRightFolder = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.LabelPairName = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.LabelSourcePath = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.LabelDestinationPath = new System.Windows.Forms.ToolStripLabel();
            this.Button_OK = new System.Windows.Forms.Button();
            this.Button_Cancel = new System.Windows.Forms.Button();
            this.Button_SelectAll = new System.Windows.Forms.Button();
            this.Button_UnselectAll = new System.Windows.Forms.Button();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "To exclude subfolders, unselect them:";
            // 
            // LeftFolderTree
            // 
            this.LeftFolderTree.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.LeftFolderTree.Location = new System.Drawing.Point(15, 73);
            this.LeftFolderTree.Name = "LeftFolderTree";
            this.LeftFolderTree.Size = new System.Drawing.Size(256, 316);
            this.LeftFolderTree.TabIndex = 1;
            // 
            // RightFolderTree
            // 
            this.RightFolderTree.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.RightFolderTree.Location = new System.Drawing.Point(296, 73);
            this.RightFolderTree.Name = "RightFolderTree";
            this.RightFolderTree.Size = new System.Drawing.Size(256, 316);
            this.RightFolderTree.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(15, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Left Folder";
            // 
            // LabelRightFolder
            // 
            this.LabelRightFolder.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LabelRightFolder.AutoSize = true;
            this.LabelRightFolder.ForeColor = System.Drawing.Color.DarkBlue;
            this.LabelRightFolder.Location = new System.Drawing.Point(293, 54);
            this.LabelRightFolder.Name = "LabelRightFolder";
            this.LabelRightFolder.Size = new System.Drawing.Size(64, 13);
            this.LabelRightFolder.TabIndex = 4;
            this.LabelRightFolder.Text = "Right Folder";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(565, 485);
            this.shapeContainer1.TabIndex = 5;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lineShape1.BorderColor = System.Drawing.Color.DarkBlue;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 16;
            this.lineShape1.X2 = 550;
            this.lineShape1.Y1 = 410;
            this.lineShape1.Y2 = 410;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LabelPairName,
            this.toolStripSeparator1,
            this.LabelSourcePath,
            this.toolStripSeparator2,
            this.LabelDestinationPath});
            this.toolStrip1.Location = new System.Drawing.Point(0, 460);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(565, 25);
            this.toolStrip1.TabIndex = 7;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // LabelPairName
            // 
            this.LabelPairName.Name = "LabelPairName";
            this.LabelPairName.Size = new System.Drawing.Size(86, 22);
            this.LabelPairName.Text = "toolStripLabel1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // LabelSourcePath
            // 
            this.LabelSourcePath.Name = "LabelSourcePath";
            this.LabelSourcePath.Size = new System.Drawing.Size(86, 22);
            this.LabelSourcePath.Text = "toolStripLabel1";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // LabelDestinationPath
            // 
            this.LabelDestinationPath.Name = "LabelDestinationPath";
            this.LabelDestinationPath.Size = new System.Drawing.Size(86, 22);
            this.LabelDestinationPath.Text = "toolStripLabel1";
            // 
            // Button_OK
            // 
            this.Button_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_OK.Location = new System.Drawing.Point(396, 425);
            this.Button_OK.Name = "Button_OK";
            this.Button_OK.Size = new System.Drawing.Size(75, 23);
            this.Button_OK.TabIndex = 8;
            this.Button_OK.Text = "OK";
            this.Button_OK.UseVisualStyleBackColor = true;
            // 
            // Button_Cancel
            // 
            this.Button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Cancel.Location = new System.Drawing.Point(477, 425);
            this.Button_Cancel.Name = "Button_Cancel";
            this.Button_Cancel.Size = new System.Drawing.Size(75, 23);
            this.Button_Cancel.TabIndex = 9;
            this.Button_Cancel.Text = "Cancel";
            this.Button_Cancel.UseVisualStyleBackColor = true;
            this.Button_Cancel.Click += new System.EventHandler(this.ButtonCancelClick);
            // 
            // Button_SelectAll
            // 
            this.Button_SelectAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Button_SelectAll.Location = new System.Drawing.Point(18, 425);
            this.Button_SelectAll.Name = "Button_SelectAll";
            this.Button_SelectAll.Size = new System.Drawing.Size(75, 23);
            this.Button_SelectAll.TabIndex = 10;
            this.Button_SelectAll.Text = "Select All";
            this.Button_SelectAll.UseVisualStyleBackColor = true;
            // 
            // Button_UnselectAll
            // 
            this.Button_UnselectAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Button_UnselectAll.Location = new System.Drawing.Point(99, 425);
            this.Button_UnselectAll.Name = "Button_UnselectAll";
            this.Button_UnselectAll.Size = new System.Drawing.Size(75, 23);
            this.Button_UnselectAll.TabIndex = 11;
            this.Button_UnselectAll.Text = "UnselectAll";
            this.Button_UnselectAll.UseVisualStyleBackColor = true;
            // 
            // DialogSubFolders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(246)))), ((int)(((byte)(252)))));
            this.ClientSize = new System.Drawing.Size(565, 485);
            this.Controls.Add(this.Button_UnselectAll);
            this.Controls.Add(this.Button_SelectAll);
            this.Controls.Add(this.Button_Cancel);
            this.Controls.Add(this.Button_OK);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.LabelRightFolder);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.RightFolderTree);
            this.Controls.Add(this.LeftFolderTree);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.shapeContainer1);
            this.MinimumSize = new System.Drawing.Size(415, 350);
            this.Name = "DialogSubFolders";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DialogSubFolders";
            this.Load += new System.EventHandler(this.DialogSubFoldersLoad);
            this.Resize += new System.EventHandler(this.WindowResized);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView LeftFolderTree;
        private System.Windows.Forms.TreeView RightFolderTree;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LabelRightFolder;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel LabelPairName;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel LabelSourcePath;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripLabel LabelDestinationPath;
        private System.Windows.Forms.Button Button_OK;
        private System.Windows.Forms.Button Button_Cancel;
        private System.Windows.Forms.Button Button_SelectAll;
        private System.Windows.Forms.Button Button_UnselectAll;
    }
}