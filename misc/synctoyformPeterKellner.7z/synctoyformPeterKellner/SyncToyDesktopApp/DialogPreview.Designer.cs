﻿namespace SyncToyDesktopApp {
    partial class DialogPreview {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.PanelSyntoyHeader = new System.Windows.Forms.Panel();
            this.OperationFilter = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.PanelHeaderImage = new System.Windows.Forms.Panel();
            this.PanelMed = new System.Windows.Forms.Panel();
            this.LabelDestinationPath = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.LabelSourcePath = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.PanelLeftFolderImage = new System.Windows.Forms.Panel();
            this.LabelCopyMessage = new System.Windows.Forms.Label();
            this.LabelTotalBytesToCopy = new System.Windows.Forms.Label();
            this.LabelSkipMessage = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ListViewResults = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ButtonClose = new System.Windows.Forms.Button();
            this.ButtonStop = new System.Windows.Forms.Button();
            this.ButtonRun = new System.Windows.Forms.Button();
            this.PreviewWorker = new System.ComponentModel.BackgroundWorker();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.ListViewOperations = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LabelMessage = new System.Windows.Forms.Label();
            this.PanelSyntoyHeader.SuspendLayout();
            this.PanelMed.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelSyntoyHeader
            // 
            this.PanelSyntoyHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelSyntoyHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(156)))), ((int)(((byte)(198)))));
            this.PanelSyntoyHeader.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.syncToyGradientBar;
            this.PanelSyntoyHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PanelSyntoyHeader.Controls.Add(this.OperationFilter);
            this.PanelSyntoyHeader.Controls.Add(this.label1);
            this.PanelSyntoyHeader.Controls.Add(this.PanelHeaderImage);
            this.PanelSyntoyHeader.Location = new System.Drawing.Point(-7, -1);
            this.PanelSyntoyHeader.Name = "PanelSyntoyHeader";
            this.PanelSyntoyHeader.Size = new System.Drawing.Size(1005, 56);
            this.PanelSyntoyHeader.TabIndex = 1;
            // 
            // OperationFilter
            // 
            this.OperationFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OperationFilter.FormattingEnabled = true;
            this.OperationFilter.Items.AddRange(new object[] {
            "All Operations",
            "New"});
            this.OperationFilter.Location = new System.Drawing.Point(66, 22);
            this.OperationFilter.Name = "OperationFilter";
            this.OperationFilter.Size = new System.Drawing.Size(121, 21);
            this.OperationFilter.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(20, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Go To:";
            // 
            // PanelHeaderImage
            // 
            this.PanelHeaderImage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelHeaderImage.BackColor = System.Drawing.Color.Transparent;
            this.PanelHeaderImage.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.CRSyncFiles_Text;
            this.PanelHeaderImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelHeaderImage.Location = new System.Drawing.Point(706, 8);
            this.PanelHeaderImage.Name = "PanelHeaderImage";
            this.PanelHeaderImage.Size = new System.Drawing.Size(283, 46);
            this.PanelHeaderImage.TabIndex = 0;
            // 
            // PanelMed
            // 
            this.PanelMed.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelMed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(246)))), ((int)(((byte)(252)))));
            this.PanelMed.Controls.Add(this.LabelDestinationPath);
            this.PanelMed.Controls.Add(this.panel3);
            this.PanelMed.Controls.Add(this.panel2);
            this.PanelMed.Controls.Add(this.label5);
            this.PanelMed.Controls.Add(this.LabelSourcePath);
            this.PanelMed.Controls.Add(this.panel1);
            this.PanelMed.Controls.Add(this.label3);
            this.PanelMed.Controls.Add(this.PanelLeftFolderImage);
            this.PanelMed.Controls.Add(this.LabelCopyMessage);
            this.PanelMed.Controls.Add(this.LabelTotalBytesToCopy);
            this.PanelMed.Controls.Add(this.LabelSkipMessage);
            this.PanelMed.Controls.Add(this.label2);
            this.PanelMed.Controls.Add(this.ListViewResults);
            this.PanelMed.Location = new System.Drawing.Point(-6, 336);
            this.PanelMed.Name = "PanelMed";
            this.PanelMed.Size = new System.Drawing.Size(1004, 209);
            this.PanelMed.TabIndex = 4;
            // 
            // LabelDestinationPath
            // 
            this.LabelDestinationPath.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelDestinationPath.Location = new System.Drawing.Point(845, 120);
            this.LabelDestinationPath.Name = "LabelDestinationPath";
            this.LabelDestinationPath.Size = new System.Drawing.Size(121, 16);
            this.LabelDestinationPath.TabIndex = 16;
            this.LabelDestinationPath.Text = "label4";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_Rightgraphic1;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel3.Location = new System.Drawing.Point(820, 24);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(70, 72);
            this.panel3.TabIndex = 13;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_folder;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(820, 120);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(19, 16);
            this.panel2.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label5.Location = new System.Drawing.Point(817, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Right Folder:";
            // 
            // LabelSourcePath
            // 
            this.LabelSourcePath.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelSourcePath.Location = new System.Drawing.Point(658, 120);
            this.LabelSourcePath.Name = "LabelSourcePath";
            this.LabelSourcePath.Size = new System.Drawing.Size(131, 16);
            this.LabelSourcePath.TabIndex = 12;
            this.LabelSourcePath.Text = "label4";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_folder;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(633, 120);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(19, 16);
            this.panel1.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(37)))), ((int)(((byte)(126)))));
            this.label3.Location = new System.Drawing.Point(630, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Left Folder:";
            // 
            // PanelLeftFolderImage
            // 
            this.PanelLeftFolderImage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelLeftFolderImage.BackgroundImage = global::SyncToyDesktopApp.Properties.Resources.SyncToyUI_LeftGraphic1;
            this.PanelLeftFolderImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PanelLeftFolderImage.Location = new System.Drawing.Point(633, 24);
            this.PanelLeftFolderImage.Name = "PanelLeftFolderImage";
            this.PanelLeftFolderImage.Size = new System.Drawing.Size(70, 72);
            this.PanelLeftFolderImage.TabIndex = 9;
            // 
            // LabelCopyMessage
            // 
            this.LabelCopyMessage.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LabelCopyMessage.AutoEllipsis = true;
            this.LabelCopyMessage.AutoSize = true;
            this.LabelCopyMessage.ForeColor = System.Drawing.Color.DarkBlue;
            this.LabelCopyMessage.Location = new System.Drawing.Point(373, 99);
            this.LabelCopyMessage.Name = "LabelCopyMessage";
            this.LabelCopyMessage.Size = new System.Drawing.Size(212, 13);
            this.LabelCopyMessage.TabIndex = 4;
            this.LabelCopyMessage.Text = "Avoided copying 16,162,816 byes in 2 files.";
            // 
            // LabelTotalBytesToCopy
            // 
            this.LabelTotalBytesToCopy.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LabelTotalBytesToCopy.AutoEllipsis = true;
            this.LabelTotalBytesToCopy.AutoSize = true;
            this.LabelTotalBytesToCopy.ForeColor = System.Drawing.Color.DarkBlue;
            this.LabelTotalBytesToCopy.Location = new System.Drawing.Point(373, 77);
            this.LabelTotalBytesToCopy.Name = "LabelTotalBytesToCopy";
            this.LabelTotalBytesToCopy.Size = new System.Drawing.Size(157, 13);
            this.LabelTotalBytesToCopy.TabIndex = 7;
            this.LabelTotalBytesToCopy.Text = "Total bytes to copy: 23,348,644";
            // 
            // LabelSkipMessage
            // 
            this.LabelSkipMessage.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LabelSkipMessage.AutoEllipsis = true;
            this.LabelSkipMessage.AutoSize = true;
            this.LabelSkipMessage.ForeColor = System.Drawing.Color.DarkBlue;
            this.LabelSkipMessage.Location = new System.Drawing.Point(373, 24);
            this.LabelSkipMessage.Name = "LabelSkipMessage";
            this.LabelSkipMessage.Size = new System.Drawing.Size(196, 13);
            this.LabelSkipMessage.TabIndex = 6;
            this.LabelSkipMessage.Text = "Found 2 Files that did not require action.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(19, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Preview Results:";
            // 
            // ListViewResults
            // 
            this.ListViewResults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.ListViewResults.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2});
            this.ListViewResults.Location = new System.Drawing.Point(18, 24);
            this.ListViewResults.Name = "ListViewResults";
            this.ListViewResults.Size = new System.Drawing.Size(351, 172);
            this.ListViewResults.TabIndex = 2;
            this.ListViewResults.UseCompatibleStateImageBehavior = false;
            this.ListViewResults.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Operation";
            this.columnHeader2.Width = 74;
            // 
            // ButtonClose
            // 
            this.ButtonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonClose.Enabled = false;
            this.ButtonClose.Location = new System.Drawing.Point(900, 635);
            this.ButtonClose.Name = "ButtonClose";
            this.ButtonClose.Size = new System.Drawing.Size(75, 23);
            this.ButtonClose.TabIndex = 102;
            this.ButtonClose.Text = "Close";
            this.ButtonClose.UseVisualStyleBackColor = true;
            this.ButtonClose.Click += new System.EventHandler(this.CallBackClose);
            // 
            // ButtonStop
            // 
            this.ButtonStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonStop.Enabled = false;
            this.ButtonStop.Location = new System.Drawing.Point(819, 635);
            this.ButtonStop.Name = "ButtonStop";
            this.ButtonStop.Size = new System.Drawing.Size(75, 23);
            this.ButtonStop.TabIndex = 101;
            this.ButtonStop.Text = "Stop";
            this.ButtonStop.UseVisualStyleBackColor = true;
            this.ButtonStop.Click += new System.EventHandler(this.CallBackStop);
            // 
            // ButtonRun
            // 
            this.ButtonRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonRun.Enabled = false;
            this.ButtonRun.Location = new System.Drawing.Point(738, 635);
            this.ButtonRun.Name = "ButtonRun";
            this.ButtonRun.Size = new System.Drawing.Size(75, 23);
            this.ButtonRun.TabIndex = 100;
            this.ButtonRun.Text = "Run";
            this.ButtonRun.UseVisualStyleBackColor = true;
            this.ButtonRun.Click += new System.EventHandler(this.CallBackRun);
            // 
            // PreviewWorker
            // 
            this.PreviewWorker.WorkerReportsProgress = true;
            this.PreviewWorker.WorkerSupportsCancellation = true;
            this.PreviewWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.DoPreview);
            this.PreviewWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.PreviewProgressChanged);
            this.PreviewWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.PreviewCompleted);
            // 
            // ProgressBar
            // 
            this.ProgressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ProgressBar.Location = new System.Drawing.Point(14, 597);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(958, 15);
            this.ProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.ProgressBar.TabIndex = 8;
            // 
            // ListViewOperations
            // 
            this.ListViewOperations.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ListViewOperations.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.ListViewOperations.Location = new System.Drawing.Point(1, 56);
            this.ListViewOperations.Name = "ListViewOperations";
            this.ListViewOperations.Size = new System.Drawing.Size(983, 279);
            this.ListViewOperations.TabIndex = 2;
            this.ListViewOperations.UseCompatibleStateImageBehavior = false;
            this.ListViewOperations.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Active";
            // 
            // LabelMessage
            // 
            this.LabelMessage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelMessage.Location = new System.Drawing.Point(18, 578);
            this.LabelMessage.Name = "LabelMessage";
            this.LabelMessage.Size = new System.Drawing.Size(954, 16);
            this.LabelMessage.TabIndex = 103;
            this.LabelMessage.Text = "label4";
            // 
            // DialogPreview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(987, 677);
            this.Controls.Add(this.LabelMessage);
            this.Controls.Add(this.ListViewOperations);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.ButtonRun);
            this.Controls.Add(this.ButtonStop);
            this.Controls.Add(this.ButtonClose);
            this.Controls.Add(this.PanelMed);
            this.Controls.Add(this.PanelSyntoyHeader);
            this.MinimumSize = new System.Drawing.Size(995, 502);
            this.Name = "DialogPreview";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DialogPreview";
            this.Load += new System.EventHandler(this.DialogPreviewLoad);
            this.Resize += new System.EventHandler(this.DialogPreviewResized);
            this.PanelSyntoyHeader.ResumeLayout(false);
            this.PanelSyntoyHeader.PerformLayout();
            this.PanelMed.ResumeLayout(false);
            this.PanelMed.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelSyntoyHeader;
        private System.Windows.Forms.Panel PanelHeaderImage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel PanelMed;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView ListViewResults;
        private System.Windows.Forms.Label LabelSkipMessage;
        private System.Windows.Forms.Label LabelTotalBytesToCopy;
        private System.Windows.Forms.Label LabelCopyMessage;
        private System.Windows.Forms.Label LabelDestinationPath;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LabelSourcePath;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel PanelLeftFolderImage;
        private System.Windows.Forms.Button ButtonClose;
        private System.Windows.Forms.Button ButtonStop;
        private System.Windows.Forms.Button ButtonRun;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ComboBox OperationFilter;
        private System.ComponentModel.BackgroundWorker PreviewWorker;
        private System.Windows.Forms.ProgressBar ProgressBar;
        private System.Windows.Forms.ListView ListViewOperations;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Label LabelMessage;
    }
}