﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Synchronization;
using Microsoft.Synchronization.Files;
using System.IO;
using System.Threading;

using DataAccess.Enums;
using Timer = System.Timers.Timer;


namespace FileSyncUtility
{
    
    public class FileSynchronization
    {
        /// <summary>
        /// If this is a non-zero, then event fires every (this many) milliseconds. FileSynUpdateUIWithProgressIng.
        /// </summary>
        private int UpdateStatsInterval { get; set; }

        /// <summary>
        /// To be inserted in progress events to slow down the processing (debugging and demo only)
        /// </summary>
        private int PauseTimeMs { get; set; }

        public FileSynchronization()
        {
            UpdateStatsInterval = 0;
        }

        /// <summary>
        /// Instantiate FileSynchronization class with  default folder pair object.
        /// </summary>
        /// <param name="folderPair"></param>
        public FileSynchronization(FileSyncPairInfo folderPair){
            FolderPair = folderPair;
            ShouldProcessMultiplePairs = false;
            PreviewMode = false;
        }

        /// <summary>
        /// Instantiate FileSynchronization class with  default folder pair object.
        /// </summary>
        /// <param name="folderPair"></param>
        /// <param name="mode"></param>
        public FileSynchronization(FileSyncPairInfo folderPair,bool mode) {
            FolderPair = folderPair;
            ShouldProcessMultiplePairs = false;
            PreviewMode = mode;
        }

        /// <summary>
        /// Instantiate FileSynchronization class with  default folder pair objects.
        /// </summary>
        /// <param name="folderPairs"></param>
        public FileSynchronization(List<FileSyncPairInfo> folderPairs)
        {
            FolderPairs = folderPairs;
            ShouldProcessMultiplePairs = true;
            PreviewMode = false;
        }

        /// <summary>
        /// Instantiate FileSynchronization class with  default folder pair objects.
        /// </summary>
        /// <param name="folderPairs"></param>
        /// <param name="mode"></param>
        public FileSynchronization(List<FileSyncPairInfo> folderPairs,bool mode) {
            FolderPairs = folderPairs;
            ShouldProcessMultiplePairs = true;
            PreviewMode = mode;
        }

        private SyncOrchestrator SyncOrchestrator { get; set; }

        // Total number of files changed
        public static int FilesChanged { get; set; }

        // If set to true, will process multiple folder pairs at once
        private bool ShouldProcessMultiplePairs { get; set; }

        // Holds the total number of actions
        public static int TotalActionsTaken { get; set; }

        /// <summary>
        /// Holds the percentage done on the files that were being synchronized.
        /// Should only contain between 0 to 100.
        /// 
        /// 
        /// </summary>
        public int Progress {
            get {
                return _progressValue;
            }

        }

        // This might look redundant however this was designed so that Progress can only return if accessed outside this class
        private int _progressValue;

        // Need to make sure that only one thread can update _Progress at a time or we will have thread crash
        private int ProgressValue {
            get {
                lock (lockerCancel) {
                    return _progressValue;
                }
            }
            set {
                lock (lockerCancel) {
                    _progressValue = value;
                }
            }
        }



        //Preview flag
        public bool PreviewMode { get; set; }
        public bool Previewed { get; set; }

        //Verbosity flag
        public bool VerboseEnabled { get; set; }
        private string _logFileName;
        private bool _logEnabled;
        public void SetLog(string fileName)
        {
            _logEnabled = true;
            if (fileName != null) _logFileName = fileName;
        }

        private static readonly object FileLoggingLock = new object();

        public string Message { get; set; }

        public int TotalFilesFound { get; set; }
        public int TotalDirectoriesFound { get; set; }
        public long TotalFileSize { get; set; }
        public long TotalBytesToCopy { get; set; }
        public int TotalDeletedFolders { get; set; }
        public int TotalDeletedFiles { get; set; }
        public int TotalRenamedFiles { get; set; }
        public int TotalCreatedFolders { get; set; }
        public int TotalCreatedFiles { get; set; }
        public int TotalOverWrittenFiles { get; set; }
        public int TotalSkippedFiles { get; set; }

        private FileSyncProvider _sourceProvider;
        private FileSyncProvider _destinationProvider;
       

        public FileSyncPairInfo FolderPair { get; set; }
        public List<FileSyncPairInfo> FolderPairs { get; set; }


        
        private object lockerCancel = new object();

        // Need to make sure that only one thread can update CancelPending at a time or we will have thread crash
        private bool _cancelPending;
        public bool CancelPending {
            get {
                lock (lockerCancel) {
                    return _cancelPending;
                }
            }
            set {
                lock (lockerCancel) {
                    _cancelPending = value;
                }
            }
        }

        /// <summary>
        /// Deal with anything happending during the file syncing ( progress reporting );
        /// Also this only gets called during an actual Synchronization process or when preview mode is set to false
        /// </summary>
  
        public event FileSyncEventHandler FilesSyncing;

        // Deal with the file syncing completed
        public event FileSyncEventHandler FilesSyncingCompleted;

        //Deal with the the files being changed on the destination path
        public event FileSyncApplyingChangesEventHandler DestinationFileApplyingChanges;

        //Deal with the files that are about to be changed.
        public event FileSyncDetectedChangesEventHandler DestinationDetectChanges;

        // Deal with the start event
        public event FileSyncStartedEventHandler SynchronizationStarted;

        // Deal with messages
        public event FileSyncMessageEventHandler SynchronizationMessages;

        // Raises the Files Syncing event.
        protected virtual void OnFilesSyncing(FileSyncEventArgs e) {
            if (FilesSyncing != null) {
                FilesSyncing(this, e);
            }
        }

        // Raises the Files Syncing event when completed
        protected virtual void OnFilesSyncingCompleted(FileSyncEventArgs e) {
            if (FilesSyncingCompleted != null) {
                FilesSyncingCompleted(this, e);
            }
        }

        // Raises the destination applying changes event
        protected virtual void OnDestinationApplyingChanges(FileSyncApplyingChangesEventArgs e) {
            if (DestinationFileApplyingChanges != null) {
                DestinationFileApplyingChanges(this, e);
            }
        }

        // Raises the destination detected changes event
        protected virtual void OnDestinationDetectChanges(FileSyncDetectedChangesEventArgs e) {
            if (DestinationDetectChanges != null) {
                DestinationDetectChanges(this, e);
            }
        }

        // Raises the start event 
        protected virtual void OnSynchronizationStarted(FileSyncStartedEventArgs e)
        {
            if(SynchronizationStarted != null)
            {
                SynchronizationStarted(this, e);
            }
        }

        // Raises the message event
        protected virtual  void OnSynchronizationMessage(FileSyncMessageEventArgs e)
        {
            if(SynchronizationMessages != null)
            {
                SynchronizationMessages(this, e);
            }
        }

        /// <summary>
        /// Helper method for console output
        /// </summary>
        /// <param name="message"></param>
        /// <exception cref="ApplicationException"></exception>
        protected void VerboseOut(string message) {
            if (VerboseEnabled) {
                Console.WriteLine(message);
            }

            if (_logEnabled) {

                try
                {
                    lock (FileLoggingLock)
                    {

                        if (!String.IsNullOrEmpty(_logFileName))
                        {
                            using (var streamWriter = !File.Exists(_logFileName)
                                                          ? new StreamWriter(_logFileName)
                                                          : File.AppendText(_logFileName))
                            {
                                streamWriter.WriteLine(message);
                                streamWriter.Close();
                            }
                        }

                    }

                } catch (Exception excp)
                {
                    //throw new ApplicationException(excp.Message,excp)
                }
            }
        }

        /// <summary>
        /// Log helper method
        /// </summary>
        /// <param name="message"></param>
        /// <param name="useAsMessage">If set to true, all current log messages can be accessed using the Message property</param>
        protected void VerboseOut(string message, bool useAsMessage) {
            VerboseOut(message);
            if(useAsMessage){
                Message = message;
            }
        }


        /// <summary>
        /// Process one Pair
        /// </summary>
        /// <param name="fileSyncPairInfo">The folders to synchronize</param>
        public string ProcessFileSyncPairInfo(FileSyncPairInfo fileSyncPairInfo)
        {
            return ProcessFileSyncPairInfos(new List<FileSyncPairInfo> {fileSyncPairInfo});
        }

        /// <summary>
        /// Process a list of folder pairs at once.
        /// </summary>
        /// <param name="folderPairs"></param>
        /// <returns></returns>
        public string ProcessFileSyncPairInfos(List<FileSyncPairInfo> folderPairs)
        {
            string message;

            try
            {
                FilesChanged = 0;
                VerboseOut("-----------------------------------");
                VerboseOut(string.Format("Synchronizing {0} folder pairs...",folderPairs.Count));

                // Inform callback the the synchronization process has started
                FileSyncStartedEventArgs startEvent = new FileSyncStartedEventArgs(PreviewMode);
                OnSynchronizationStarted(startEvent);

                // Raise message event
                FileSyncMessageEventArgs messageEventArgs = new FileSyncMessageEventArgs(string.Format("Synchronizing {0} folder pair(s)...", folderPairs.Count),PreviewMode);
                OnSynchronizationMessage(messageEventArgs);

                foreach (var folderPair in folderPairs)
                {
                    FileSyncPairInfo fileSyncPairInfo = folderPair;
                    string replica1RootPath = fileSyncPairInfo.LeftFolder;
                    string replica2RootPath = fileSyncPairInfo.RightFolder;

                    // Set options for the sync operation                   
                    var fileSyncOptions = GetFileSyncOptions(fileSyncPairInfo);

                    var filter = new FileSyncScopeFilter();
                    foreach (var fileNameExclude in fileSyncPairInfo.FileNameExludes)
                    {
                        filter.FileNameExcludes.Add(fileNameExclude);
                    }

                    
                    VerboseOut("about to do DetectChanges...", true);
                    
                    // Raise event message
                    FileSyncMessageEventArgs messageEventArgs2 = new FileSyncMessageEventArgs("Detecting changes for " + folderPair.FolderPairName + "...", PreviewMode);
                    OnSynchronizationMessage(messageEventArgs2);

                    // Explicitly detect changes on both replicas upfront, to avoid two change 
                    // detection passes for the two-way sync
                    DetectChangesOnFileSystemReplica(replica1RootPath, filter, fileSyncOptions);
                    DetectChangesOnFileSystemReplica(replica2RootPath, filter, fileSyncOptions);

                    VerboseOut("Starting synchronization process...", true);
                    VerboseOut("Depending on the number of files this could take a while...", true);
                    VerboseOut("Please wait...", true);

                    // Sync in both directions
                    SyncFileSystemReplicasOneWay(replica1RootPath, replica2RootPath, null, fileSyncOptions, PreviewMode);
                    VerboseOut("SyncFileSystemReplicasOneWay 1->2 done", true);

                    SyncFileSystemReplicasOneWay(replica2RootPath, replica1RootPath, null, fileSyncOptions, PreviewMode);
                    VerboseOut("SyncFileSystemReplicasOneWay 2->1 done", true);
                }

                //Triggers our callback that we are done if any
                FileSyncEventArgs synchronizationCompleted = new FileSyncEventArgs(100,PreviewMode);
                ProgressValue = 100;

                if (UpdateStatsInterval != 0)
                {
                    _timer.Stop();
                }

                OnFilesSyncingCompleted(synchronizationCompleted);
                VerboseOut(string.Format("Actions Taken {0}", TotalActionsTaken));
                VerboseOut("Synchronization process ended.", true);
                VerboseOut("-----------------------------------");

                // Raise event message
                FileSyncMessageEventArgs messageEventArgs3 = new FileSyncMessageEventArgs("Completed", PreviewMode);
                OnSynchronizationMessage(messageEventArgs3);

                //Flag current process as Previwed if it went through preview mode
                if (PreviewMode) {
                    Previewed = true;
                }
            }
            catch(SyncException e)
            {
                //TODO
                //throw new ApplicationException(e.Message,e);
            }


            message = string.Format("Completed.  Files Changed {0}", FilesChanged);
            VerboseOut(message, true);
            return message;
        }

        public void Synchronize()
        {
            Synchronize(0,0);
        }


        // PGK - All Put togehter to avoid updating other files.  Lem, please spread these out to correct files
        public delegate void FileSynUpdateUIWithProgressEventHandler(object sender, FileSynUpdateUIWithProgressEventHandlerArgs args);
      
        public class FileSynUpdateUIWithProgressEventHandlerArgs : EventArgs
        {
            public int TotalFilesFound { get; set; }
            public int TotalDirectoriesFound { get; set; }
            public long TotalFileSize { get; set; }
            public long TotalBytesToCopy { get; set; }
            public int TotalDeletedFolders { get; set; }
            public int TotalDeletedFiles { get; set; }
            public int TotalRenamedFiles { get; set; }
            public int TotalCreatedFolders { get; set; }
            public int TotalCreatedFiles { get; set; }
            public int TotalOverWrittenFiles { get; set; }
            public int TotalSkippedFiles { get; set; }
        }


        
        public event FileSynUpdateUIWithProgressEventHandler FileSynUpdateUIWithProgressIng;

        // Raises the Update UI event
        protected virtual void OnFileSynUpdateUIWithProgress(FileSynUpdateUIWithProgressEventHandlerArgs e)
        {
            if (FileSynUpdateUIWithProgressIng != null)
            {
                FileSynUpdateUIWithProgressIng(this, e);
            }
        }

        void FileSynchronizer_FileSynUpdateUIWithProgressIng(object sender, FileSynchronization.FileSynUpdateUIWithProgressEventHandlerArgs args)
        {
            // all these parameters hsould be wrapped in a class with a nice constructor instead of 2 separate assignments
            args.TotalCreatedFiles = TotalCreatedFiles;
            args.TotalDeletedFiles = TotalDeletedFiles;
            args.TotalBytesToCopy = TotalBytesToCopy;
            args.TotalCreatedFolders = TotalCreatedFiles;
            args.TotalDeletedFiles = TotalDeletedFolders;
            args.TotalDeletedFolders = TotalDeletedFolders;
            args.TotalDirectoriesFound = TotalDirectoriesFound;
            args.TotalFilesFound = TotalFilesFound;
            args.TotalFileSize = TotalFileSize;
            args.TotalOverWrittenFiles = TotalOverWrittenFiles;
            args.TotalRenamedFiles = TotalRenamedFiles;
            args.TotalSkippedFiles = TotalSkippedFiles;
        }



        // PGK - End of new delegate stuff

        private Timer _timer;

        void TimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            OnFileSynUpdateUIWithProgress(new FileSynUpdateUIWithProgressEventHandlerArgs()
                                              {
                                                  TotalCreatedFiles = TotalCreatedFiles,
                                                  TotalDeletedFiles = TotalDeletedFiles,
                                                  TotalBytesToCopy = TotalBytesToCopy,
                                                  TotalCreatedFolders = TotalCreatedFolders,
                                                  TotalDeletedFolders = TotalDeletedFolders,
                                                  TotalDirectoriesFound = TotalDirectoriesFound,
                                                  TotalFilesFound = TotalFilesFound,
                                                  TotalFileSize = TotalFileSize,
                                                  TotalOverWrittenFiles = TotalOverWrittenFiles,
                                                  TotalRenamedFiles = TotalRenamedFiles,
                                                  TotalSkippedFiles = TotalSkippedFiles
                                              });
        }


        /// <summary>
        /// Start the Synchronization Process
        /// </summary>
        /// <param name="updateStatsInterval">number of milliseconds to trigger delegate to report stats</param>
        /// <param name="pauseTimeMs">The number of milliseconds to pause on progress events.  for demo and debugging purposes</param>
        public void Synchronize(int updateStatsInterval,int pauseTimeMs)
       {
           UpdateStatsInterval = updateStatsInterval;

           if (UpdateStatsInterval != 0)
           {
               _timer = new Timer {Interval = UpdateStatsInterval};
               _timer.Elapsed += TimerElapsed;
               _timer.Start();
           }


           //Uncomment below this line if you want this class to have its own thread
           //this._MainThreadStart = new ThreadStart(this._Start);
           //this._MainThread = new Thread(this._MainThreadStart);
           //this._MainThread.Start();
           if (ShouldProcessMultiplePairs)
           {
               ProcessFileSyncPairInfos(FolderPairs);
           }
           else
           {

               //Let's perform preview first then perform run
               ProcessFileSyncPairInfo(FolderPair);
           }
       }



        public void DetectChangesOnFileSystemReplica(string replicaRootPath,FileSyncScopeFilter filter, FileSyncOptions options)
        {
            FileSyncProvider provider = null;

            VerboseOut("Detecting changes on file system replica...");

            try
            {
                //TEST : Below variable is just a test will do something about it in the future.
                Guid guid = Guid.NewGuid();
                provider = new FileSyncProvider(guid,replicaRootPath);


                // Lem, it looks like we can lots of events out of the deteccting changes and propogate. that includes e.TotalFileSize on the DetectedChangesEventArgs
                // which seems to represent the size of all files.  please explore other events and make sure we capture relevant info here
                provider.DetectedChanges += new EventHandler<DetectedChangesEventArgs>(provider_DetectedChanges);

                provider.DetectChanges();
            }
            finally
            {
                // Release resources
                if (provider != null)
                {
                    provider.Dispose();
                }
            }
        }

        void provider_DetectedChanges(object sender, DetectedChangesEventArgs e)
        {
            
        }


        /// <summary>
        /// Actual synchronization process. This synchronize the source and the destination path.
        /// </summary>
        /// <param name="sourceReplicaRootPath">The source to synchronize from ( All changes will be reflected to the destination ).</param>
        /// <param name="destinationReplicaRootPath">All changes from the source will be reflected here.</param>
        /// <param name="filter"></param>
        /// <param name="options"></param>
        /// <param name="previewMode"></param>
        public void SyncFileSystemReplicasOneWay(string sourceReplicaRootPath, 
                                                        string destinationReplicaRootPath,
                                                        FileSyncScopeFilter filter, 
                                                        FileSyncOptions options, 
                                                        bool previewMode)
        {
            _sourceProvider = null;
            _destinationProvider = null;

            try
            {
                //TEST : Below variables are just a test will do something about it in the future.
                Guid sourceGuid = Guid.NewGuid();
                Guid destinationGuid = Guid.NewGuid();

                _sourceProvider = new FileSyncProvider(sourceGuid,sourceReplicaRootPath, filter, options);
                _destinationProvider = new FileSyncProvider(destinationGuid,destinationReplicaRootPath, filter, options);

                _destinationProvider.DetectedChanges += DestinationProviderDetectedChanges;
                _destinationProvider.DetectingChanges += DestinationProviderDetectingChanges;
                _destinationProvider.AppliedChange += OnAppliedChange;
                _destinationProvider.SkippedChange += OnSkippedChange;
                _destinationProvider.ApplyingChange += DestinationProviderApplyingChange;
                _destinationProvider.CopyingFile += DestinationProviderCopyingFile;
                _destinationProvider.SkippedFileDetect += DestinationProviderSkippedFileDetect;
                _destinationProvider.SkippedChange += DestinationProviderSkippedChange;
                _destinationProvider.PreviewMode = previewMode;

                _sourceProvider.PreviewMode = previewMode;

                SyncOrchestrator = new SyncOrchestrator
                                {
                                    LocalProvider = _sourceProvider,
                                    RemoteProvider = _destinationProvider,
                                    Direction = SyncDirectionOrder.Upload
                                };

                Console.WriteLine("Synchronizing changes to replica: " + _destinationProvider.RootDirectoryPath);
                SyncOrchestrator.Synchronize();
                
            }
            finally
            {
                // Release resources
                if (_sourceProvider != null) _sourceProvider.Dispose();
                if (_destinationProvider != null) _destinationProvider.Dispose();
            }
        }

        public void DestinationProviderSkippedChange(object sender, SkippedChangeEventArgs e)
        {
            VerboseOut(string.Format("[DEST] Skipping changes to {0}",e.CurrentFilePath),true);
            VerboseOut(string.Format("[DEST] because {0}", e.SkipReason), true);
            VerboseOut(string.Format("[DEST] Change type = {0}", e.ChangeType), true);
            
            // Raise event message
            FileSyncMessageEventArgs syncMessageEventArgs = new FileSyncMessageEventArgs(string.Format("Skipping changes to {0}",e.CurrentFilePath),PreviewMode);
            OnSynchronizationMessage(syncMessageEventArgs);
        }

        public void DestinationProviderDetectingChanges(object sender, DetectingChangesEventArgs e)
        {
            VerboseOut(string.Format("[DEST] Detecting changes to {0}", e.DirectoryPath), true);
        }

        public void DestinationProviderDetectedChanges(object sender, DetectedChangesEventArgs e)
        {
            TotalFilesFound = int.Parse(e.TotalFilesFound.ToString());
            TotalDirectoriesFound = int.Parse(e.TotalDirectoriesFound.ToString());
            TotalFileSize = e.TotalFileSize;
            VerboseOut("[DEST] Detected changes to destination...");
            VerboseOut(string.Format("[DEST] File(s) = {0}", e.TotalFilesFound));
            VerboseOut(string.Format("[DEST] Directory(s) = {0}", e.TotalDirectoriesFound));
            VerboseOut(string.Format("[DEST] File size = {0}", e.TotalFileSize));


            FileSyncDetectedChangesEventArgs eventArgs = new FileSyncDetectedChangesEventArgs(e);
            OnDestinationDetectChanges(eventArgs);
        }


        public void DestinationProviderSkippedFileDetect(object sender, SkippedFileDetectEventArgs e)
        {
            VerboseOut(string.Format("[DEST] Skipping file {0}", e.FilePath), true);
            VerboseOut(string.Format("[DEST] because {0}", e.SkipReason), true);
        }

        public void DestinationProviderCopyingFile(object sender, CopyingFileEventArgs e)
        {
            VerboseOut(string.Format("[DEST] Copying file {0}", e.FilePath), true);
            VerboseOut(string.Format("[DEST] Percent copied {0}", e.PercentCopied), true);
            
            // Raise event message
            FileSyncMessageEventArgs syncMessageEventArgs = new FileSyncMessageEventArgs(string.Format("Copying {0} {1}%",e.FilePath,e.PercentCopied), PreviewMode);
            OnSynchronizationMessage(syncMessageEventArgs);
        }

        public void DestinationProviderApplyingChange(object sender, ApplyingChangeEventArgs e)
        {
            Thread.Sleep(PauseTimeMs);

            VerboseOut("[DEST] Applying changes to destination path...",true);
            VerboseOut(string.Format("TYPE = {0}, FILE = {1}, SOURCE = {2}",e.ChangeType,e.NewFileData.RelativePath,_sourceProvider.RootDirectoryPath));

            
            string changeType = e.ChangeType.ToString();
            if (!Previewed) {
                if (e.ChangeType == ChangeType.Create) {
                    changeType = "New";
                    if (e.NewFileData.IsDirectory) {
                        TotalCreatedFolders++;
                    } else {
                        TotalCreatedFiles++;
                    }
                } else if (e.ChangeType == ChangeType.Delete) {
                    if (e.NewFileData.IsDirectory) {
                        TotalDeletedFolders++;
                    } else {
                        TotalDeletedFiles++;
                    }
                } else if (e.ChangeType == ChangeType.Rename) {
                    TotalRenamedFiles++;
                } else if (e.ChangeType == ChangeType.Update) {
                    TotalOverWrittenFiles++;
                }
            } 
            


            if(e.SkipChange){
                TotalSkippedFiles++;
            }

            //Count the number of changes that takes place
            if (PreviewMode) {
                TotalActionsTaken++;
            }

            // Raise event message
            // FileSyncMessageEventArgs syncMessageEventArgs = new FileSyncMessageEventArgs("Applying changes to destination...", PreviewMode);
            // OnSynchronizationMessage(syncMessageEventArgs);

            // Triggers ApplyingChangesEventHandler
            FileSyncApplyingChangesEventArgs eventArgs = new FileSyncApplyingChangesEventArgs(e,_sourceProvider.RootDirectoryPath,_destinationProvider.RootDirectoryPath,PreviewMode);
            OnDestinationApplyingChanges(eventArgs);

            TotalBytesToCopy += e.NewFileData.Size;


        }

        public void OnSkippedChange(object sender, SkippedChangeEventArgs args)
        {

            Thread.Sleep(PauseTimeMs);


            VerboseOut("-- Skipped applying " + args.ChangeType.ToString().ToUpper()
                  + " for " + (!string.IsNullOrEmpty(args.CurrentFilePath) ?
                                args.CurrentFilePath : args.NewFilePath) + " due to error",true);
            if (args.Exception != null)
                Console.WriteLine("   [" + args.Exception.Message + "]");
        }


        /// <summary>
        /// Callback method for actual file/folder modification.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void OnAppliedChange(object sender, AppliedChangeEventArgs args)
        {
            Thread.Sleep(PauseTimeMs);

            FilesChanged++;
            
            if(Previewed){
                double fraction = FilesChanged / (double)TotalActionsTaken;
                ProgressValue = Convert.ToInt32(fraction * 100);
                //Console.WriteLine("PERCENTAGE {0}", percentage);
                //Console.WriteLine(string.Format("ACTIONS: {0} of {1} Processed, PERCENT={2}", FilesChanged, TotalActionsTaken,ProgressValue));
            }

            VerboseOut(string.Format("Applying changes to {0}",args.OldFilePath));

            //Perform trigger updates
            FileSyncEventArgs synchronizationUpdate = new FileSyncEventArgs(ProgressValue);
            OnFilesSyncing(synchronizationUpdate);

            //Check for cancellation
            if(CancelPending){
                SyncOrchestrator.Cancel();
            }

            // I'm wondering why no counters in the entries below? I'm kind of confused about total counters

            switch (args.ChangeType)
            {
                case ChangeType.Create:
                    VerboseOut("-- Applied CREATE for file " + args.NewFilePath,true);
                    break;
                case ChangeType.Delete:
                    VerboseOut("-- Applied DELETE for file " + args.OldFilePath,true);
                    break;
                case ChangeType.Update:
                    VerboseOut("-- Applied OVERWRITE for file " + args.OldFilePath,true);
                    break;
                case ChangeType.Rename:
                    VerboseOut("-- Applied RENAME for file " + args.OldFilePath +
                                      " as " + args.NewFilePath,true);
                    break;
            }

            // Raise event message
            FileSyncMessageEventArgs syncMessageEventArgs = new FileSyncMessageEventArgs(string.Format("{0} {1}",args.ChangeType,args.OldFilePath), PreviewMode);
            OnSynchronizationMessage(syncMessageEventArgs);


        }

        /// <summary>
        /// Take incoming options and pile into returned FileSyncOptions var
        /// </summary>
        /// <param name="fileSyncPairInfo"></param>
        /// <returns></returns>
        private static FileSyncOptions GetFileSyncOptions(FileSyncPairInfo fileSyncPairInfo)
        {
            var fileSyncOptions = new FileSyncOptions();

            // I'm guessing there is a nicer way to do this but for now, it works.
            if (fileSyncPairInfo.OptionsCompareFileStreams)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.CompareFileStreams;
            }
            if (fileSyncPairInfo.OptionsCompareFileStreams)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.CompareFileStreams;
            }
            if (fileSyncPairInfo.OptionsRecycleConflictLoserFiles)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.RecycleConflictLoserFiles;
            }
            if (fileSyncPairInfo.OptionsRecycleDeletedFiles)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.RecycleDeletedFiles;
            }
            if (fileSyncPairInfo.OptionsRecyclePreviousFileOnUpdates)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.RecyclePreviousFileOnUpdates;
            }
            return fileSyncOptions;
        }


       
    }

   
}
