﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FileSyncUtility {
    public class FileSyncStartedEventArgs : EventArgs {

        public FileSyncStartedEventArgs(bool previewMode)
        {
            PreviewMode = previewMode;
        }

        public bool PreviewMode { get; private set; }
    }
}
