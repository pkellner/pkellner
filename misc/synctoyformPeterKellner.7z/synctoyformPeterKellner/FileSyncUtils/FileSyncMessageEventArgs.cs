﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FileSyncUtility
{
    public class FileSyncMessageEventArgs : EventArgs
    {

        public FileSyncMessageEventArgs(string message, bool previewMode = false)
        {
            Message = message;
            PreviewMode = previewMode;
        }

        public string Message { get; private set; }
        public bool PreviewMode { get; private set; }
    }

    
}
