﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;

using DataAccess.Enums;


namespace FileSyncUtility {
    /// <summary>
    /// This has all the information necessary to process one file pair
    /// </summary>
    /// 
    /// 
    [Serializable]
    public class FileSyncPairInfo {

        public FileSyncPairInfo() {
            ActiveForRunAll = true;
            FileExcludeAttrArchive = false;
            FileExcludeAttrCompressed = false;
            FileExcludeAttrDirectory = false;
            FileExcludeAttrEncrypted = false;
            FileExcludeAttrHidden = false;
            FileExcludeAttrNoContentIndexed = false;
            FileExcludeAttrOffline = false;
            FileExcludeAttrReadOnly = false;
            FileExcludeAttrReParsePoint = false;
            FileExcludeAttrSparseFile = false;
            FileExcludeAttrSystem = false;
            FileExcludeAttrTemporary = false;
            OptionsCompareFileStreams = false;
            OptionsExplicitDetectChanges = false;
            OptionsRecycleConflictLoserFiles = true;
            OptionsRecycleDeletedFiles = false;
            OptionsRecyclePreviousFileOnUpdates = false;

            FolderPairActionTypeId = (int)FolderPairActionTypeEnum.Synchronize;
            UsersId = 0;
            FolderPairName = string.Empty;
            FileNameIncludes = new List<string>();
            FileNameExludes = new List<string>();
            SubDirectoryExcludes = new List<string>();

            LeftFolder = string.Empty;
            RightFolder = string.Empty;
            LastRun = string.Empty;

            FileNameIncludes.Add("*");
            FileNameExludes.Add("filesync.metadata");
        }

        public int UsersId { get; set; }
        public int FolderPairActionTypeId { get; set; }
        public string FolderPairName { get; set; }
        public string LeftFolder { get; set; }
        public string RightFolder { get; set; }
        public string LastRun { get; set; }
        public bool FileExcludeAttrReadOnly { get; set; }
        public bool FileExcludeAttrHidden { get; set; }
        public bool FileExcludeAttrSystem { get; set; }
        public bool FileExcludeAttrDirectory { get; set; }
        public bool FileExcludeAttrArchive { get; set; }
        public bool FileExcludeAttrTemporary { get; set; }
        public bool FileExcludeAttrSparseFile { get; set; }
        public bool FileExcludeAttrReParsePoint { get; set; }
        public bool FileExcludeAttrCompressed { get; set; }
        public bool FileExcludeAttrOffline { get; set; }
        public bool FileExcludeAttrNoContentIndexed { get; set; }
        public bool FileExcludeAttrEncrypted { get; set; }
        public bool OptionsCompareFileStreams { get; set; }
        public bool OptionsExplicitDetectChanges { get; set; }
        public bool OptionsRecycleConflictLoserFiles { get; set; }
        public bool OptionsRecyclePreviousFileOnUpdates { get; set; }
        public bool OptionsRecycleDeletedFiles { get; set; }
        public bool ActiveForRunAll { get; set; }


        public List<string> FileNameExludes { get; set; }
        public List<string> FileNameIncludes { get; set; }
        public List<string> SubDirectoryExcludes { get; set; }


        
        public string FileNamesToInclude {
            get
            {
                if (FileNameIncludes.Count >= 1)
                {
                    string inclusion = string.Join(",", FileNameIncludes.ToArray());
                    return inclusion;
                }
                return "*";
            }

            set {
                string[] inclusions = value.Split(',');
                FileNameIncludes = inclusions.ToList();
            }
        }

        
        public string FileNamesToExclude {
            get
            {
                if (FileNameExludes.Count >= 1)
                {
                    string exclusions = string.Join(",", FileNameExludes.ToArray());
                    return exclusions;
                }
                return "";
            }

            set {
                string[] exclusions = value.Split(',');
                FileNameExludes = exclusions.ToList();
            }
        }

    }



}
