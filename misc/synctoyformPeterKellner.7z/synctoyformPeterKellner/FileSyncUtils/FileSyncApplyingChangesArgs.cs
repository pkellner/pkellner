﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Synchronization.Files;

namespace FileSyncUtility {
    public class FileSyncApplyingChangesEventArgs: EventArgs{

        public FileSyncApplyingChangesEventArgs(ApplyingChangeEventArgs args,string sourcePath = "",string destinationPath="")
        {
            SourceArguments = args;
            SourcePath = sourcePath;
            DestinationPath = destinationPath;
            PreviewMode = false;
        }

        public FileSyncApplyingChangesEventArgs(ApplyingChangeEventArgs args, string sourcePath = "", string destinationPath = "",bool mode = false) {
            SourceArguments = args;
            SourcePath = sourcePath;
            DestinationPath = destinationPath;
            PreviewMode = mode;
        }

        public bool PreviewMode { get; private set; }
        public ApplyingChangeEventArgs SourceArguments { get; private set; }
        public string SourcePath { get; private set; }
        public string DestinationPath { get; private set; }
        public ChangeType ChangeType
        {
            get { return SourceArguments.ChangeType; }
        }
        public string ChangeTypeDisplayString
        {
            get
            {
                 Microsoft.Synchronization.Files.ChangeType currentChangeType = SourceArguments.ChangeType;
                 if(currentChangeType == ChangeType.Create)
                 {
                     return "New";
                 }else
                 {
                     return currentChangeType.ToString();
                 }
            }
        }
        public FileData CurrentFileData { get { return SourceArguments.CurrentFileData; } }
        public FileData NewFileData { get { return SourceArguments.NewFileData; } }
        public bool SkipChange { get { return SourceArguments.SkipChange; } }
        public long TotalBytesToCopy { get { return SourceArguments.NewFileData.Size; } }
        public string LastModified
        { 
            get { return string.Format("{0:MM/dd/yyyy}", SourceArguments.NewFileData.LastWriteTime); } 
        }
    }

}
