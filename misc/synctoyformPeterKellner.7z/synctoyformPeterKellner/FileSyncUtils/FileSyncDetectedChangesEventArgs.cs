﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Synchronization.Files;

namespace FileSyncUtility {
    public class FileSyncDetectedChangesEventArgs : EventArgs {

        public FileSyncDetectedChangesEventArgs(DetectedChangesEventArgs args)
        {
            _sourceArguments = args;
        }

        private DetectedChangesEventArgs _sourceArguments;
        
        public DetectedChangesEventArgs SourceArguments { get { return _sourceArguments;  } }
        public long TotalFilesFound { get { return _sourceArguments.TotalFilesFound; } }
        public long TotalDirectoriesFound { get { return _sourceArguments.TotalDirectoriesFound; } }
        public long TotalFileSize { get { return _sourceArguments.TotalFileSize; } }
    }
}
