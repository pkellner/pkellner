﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FileSyncUtility {
    public class FileSyncEventArgs : EventArgs {
        private int filesMoved;
        private bool previewMode;
        
        public FileSyncEventArgs(int filesMovedIn) {
            filesMoved = filesMovedIn;
            previewMode = false;
        }

        public FileSyncEventArgs(int filesMovedIn, bool mode)
        {
            filesMoved = filesMovedIn;
            previewMode = mode;
        }

        public int FilesMoved {
            get { return filesMoved; }
        }

        public bool PreviewModed
        {
            get { return previewMode; }
        }

        

    }
}
