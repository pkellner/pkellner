﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Synchronization;
using Microsoft.Synchronization.Files;


namespace FileSyncUtility {
    public delegate void FileSyncEventHandler(object sender, FileSyncEventArgs e);

    public delegate void FileSyncStartedEventHandler(object sender, FileSyncStartedEventArgs e);

    public delegate void FileSyncApplyingChangesEventHandler(object sender,FileSyncApplyingChangesEventArgs args);

    public delegate void FileSyncDetectedChangesEventHandler(object sender, FileSyncDetectedChangesEventArgs args);

    public delegate void FileSyncMessageEventHandler(object sender, FileSyncMessageEventArgs args);
}
