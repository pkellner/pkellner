﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.Enums;
using Microsoft.Synchronization;
using Microsoft.Synchronization.Files;

namespace Utils
{
    /// <summary>
    /// This has all the information necessary to process one file pair
    /// </summary>
    /// 
    /// 
    [Serializable()]
    public class FileSyncPairInfo
    {
        public FileSyncPairInfo()
        {
            ActiveForRunAll = false;
            FileExcludeAttrArchive = false;
            FileExcludeAttrCompressed = false;
            FileExcludeAttrDirectory = false;
            FileExcludeAttrEncrypted = false;
            FileExcludeAttrHidden = false;
            FileExcludeAttrNoContentIndexed = false;
            FileExcludeAttrOffline = false;
            FileExcludeAttrReadOnly = false;
            FileExcludeAttrReParsePoint = false;
            FileExcludeAttrSparseFile = false;
            FileExcludeAttrSystem = false;
            FileExcludeAttrTemporary = false;
            OptionsCompareFileStreams = false;
            OptionsExplicitDetectChanges = false;
            OptionsRecycleConflictLoserFiles = false;
            OptionsRecycleDeletedFiles = false;
            OptionsRecyclePreviousFileOnUpdates = false;

            FolderPairActionTypeId = (int) FolderPairActionTypeEnum.Synchronize;
            UsersId = 0;
            FolderPairName = string.Empty;
            FileNameIncludes = new List<string>();
            FileNameExludes = new List<string>();
            SubDirectoryExcludes = new List<string>();

            LeftFolder = string.Empty;
            RightFolder = string.Empty;
                
        }

        public int UsersId { get; set; }
        public int FolderPairActionTypeId { get; set; }
        public string FolderPairName { get; set; }
        public string LeftFolder { get; set; }
        public string RightFolder { get; set; }
        public bool FileExcludeAttrReadOnly { get; set; }
        public bool FileExcludeAttrHidden { get; set; }
        public bool FileExcludeAttrSystem { get; set; }
        public bool FileExcludeAttrDirectory { get; set; }
        public bool FileExcludeAttrArchive { get; set; }
        public bool FileExcludeAttrTemporary { get; set; }
        public bool FileExcludeAttrSparseFile { get; set; }
        public bool FileExcludeAttrReParsePoint { get; set; }
        public bool FileExcludeAttrCompressed { get; set; }
        public bool FileExcludeAttrOffline { get; set; }
        public bool FileExcludeAttrNoContentIndexed { get; set; }
        public bool FileExcludeAttrEncrypted { get; set; }
        public bool OptionsCompareFileStreams { get; set; }
        public bool OptionsExplicitDetectChanges { get; set; }
        public bool OptionsRecycleConflictLoserFiles { get; set; }
        public bool OptionsRecyclePreviousFileOnUpdates { get; set; }
        public bool OptionsRecycleDeletedFiles { get; set; }
        public bool ActiveForRunAll { get; set; }

        public List<string> FileNameExludes { get; set; }
        public List<string> FileNameIncludes { get; set; }
        public List<string> SubDirectoryExcludes { get; set; }
    }

    public class FileSyncUtils
    {

        public bool PreviewMode { get; set; }
        public static int FilesChanged { get; set; }

        /// <summary>
        /// Process one Pair
        /// </summary>
        /// <param name="fileSyncPairInfo"></param>
        public string ProcessFileSyncPairInfo(FileSyncPairInfo fileSyncPairInfo)
        {
            try
            {
                FilesChanged = 0;

                string replica1RootPath = fileSyncPairInfo.LeftFolder;
                string replica2RootPath = fileSyncPairInfo.RightFolder;

                // Set options for the sync operation                   
                var fileSyncOptions = GetFileSyncOptions(fileSyncPairInfo);

                var filter = new FileSyncScopeFilter();
                foreach (var fileNameExclude in fileSyncPairInfo.FileNameExludes)
                {
                    filter.FileNameExcludes.Add(fileNameExclude);
                }

                Console.WriteLine("about to do DetectChanges");
                // Explicitly detect changes on both replicas upfront, to avoid two change 
                // detection passes for the two-way sync
                DetectChangesOnFileSystemReplica(
                    replica1RootPath, filter, fileSyncOptions);
                DetectChangesOnFileSystemReplica(
                    replica2RootPath, filter, fileSyncOptions);

                // Sync in both directions
                SyncFileSystemReplicasOneWay(replica1RootPath, replica2RootPath, null, fileSyncOptions, PreviewMode);
                Console.WriteLine("SyncFileSystemReplicasOneWay 1->2 done");

                SyncFileSystemReplicasOneWay(replica2RootPath, replica1RootPath, null, fileSyncOptions, PreviewMode);
                Console.WriteLine("SyncFileSystemReplicasOneWay 2->1 done");

                
            }
            catch (Exception e)
            {
                throw new ApplicationException(e.ToString());
            }
            return string.Format("Completed.  Files Changed {0}", FilesChanged);
        }

        public static void DetectChangesOnFileSystemReplica(
          string replicaRootPath,
          FileSyncScopeFilter filter, FileSyncOptions options)
        {
            FileSyncProvider provider = null;

            try
            {
                provider = new FileSyncProvider(replicaRootPath, filter, options);
                //provider = new FileSyncProvider(replicaRootPath, filter);
                provider.DetectChanges();
            }
            finally
            {
                // Release resources
                if (provider != null)
                {
                    provider.Dispose();
                }
            }
        }

        public static void SyncFileSystemReplicasOneWay(
        string sourceReplicaRootPath, string destinationReplicaRootPath,
        FileSyncScopeFilter filter, FileSyncOptions options, bool previewMode)
        {
            FileSyncProvider sourceProvider = null;
            FileSyncProvider destinationProvider = null;

            try
            {
                sourceProvider = new FileSyncProvider(
                    sourceReplicaRootPath, filter, options);
                destinationProvider = new FileSyncProvider(
                    destinationReplicaRootPath, filter, options);

                destinationProvider.AppliedChange += OnAppliedChange;
                destinationProvider.SkippedChange += OnSkippedChange;

                destinationProvider.ApplyingChange += DestinationProviderApplyingChange;
                destinationProvider.CopyingFile += DestinationProviderCopyingFile;
                destinationProvider.SkippedFileDetect += DestinationProviderSkippedFileDetect;
                destinationProvider.DetectedChanges += DestinationProviderDetectedChanges;
                destinationProvider.DetectingChanges += DestinationProviderDetectingChanges;
                destinationProvider.SkippedChange += DestinationProviderSkippedChange;


                destinationProvider.PreviewMode = previewMode;


                var agent = new SyncOrchestrator
                                {
                                    LocalProvider = sourceProvider,
                                    RemoteProvider = destinationProvider,
                                    Direction = SyncDirectionOrder.Upload
                                };

                Console.WriteLine("Synchronizing changes to replica: " +
                    destinationProvider.RootDirectoryPath);
                agent.Synchronize();
            }
            finally
            {
                // Release resources
                if (sourceProvider != null) sourceProvider.Dispose();
                if (destinationProvider != null) destinationProvider.Dispose();
            }
        }

        static void DestinationProviderSkippedChange(object sender, SkippedChangeEventArgs e)
        {

        }

        static void DestinationProviderDetectingChanges(object sender, DetectingChangesEventArgs e)
        {

        }

        static void DestinationProviderDetectedChanges(object sender, DetectedChangesEventArgs e)
        {

        }

        static void DestinationProviderSkippedFileDetect(object sender, SkippedFileDetectEventArgs e)
        {

        }

        static void DestinationProviderCopyingFile(object sender, CopyingFileEventArgs e)
        {

        }

        static void DestinationProviderApplyingChange(object sender, ApplyingChangeEventArgs e)
        {

        }

        public static void OnSkippedChange(object sender, SkippedChangeEventArgs args)
        {
            Console.WriteLine("-- Skipped applying " + args.ChangeType.ToString().ToUpper()
                  + " for " + (!string.IsNullOrEmpty(args.CurrentFilePath) ?
                                args.CurrentFilePath : args.NewFilePath) + " due to error");

            if (args.Exception != null)
                Console.WriteLine("   [" + args.Exception.Message + "]");
        }

        public static void OnAppliedChange(object sender, AppliedChangeEventArgs args)
        {
            FilesChanged++;

            switch (args.ChangeType)
            {
                case ChangeType.Create:
                    Console.WriteLine("-- Applied CREATE for file " + args.NewFilePath);
                    break;
                case ChangeType.Delete:
                    Console.WriteLine("-- Applied DELETE for file " + args.OldFilePath);
                    break;
                case ChangeType.Update:
                    Console.WriteLine("-- Applied OVERWRITE for file " + args.OldFilePath);
                    break;
                case ChangeType.Rename:
                    Console.WriteLine("-- Applied RENAME for file " + args.OldFilePath +
                                      " as " + args.NewFilePath);
                    break;
            }
        }

        /// <summary>
        /// Take incoming options and pile into returned FileSyncOptions var
        /// </summary>
        /// <param name="fileSyncPairInfo"></param>
        /// <returns></returns>
        private static FileSyncOptions GetFileSyncOptions(FileSyncPairInfo fileSyncPairInfo)
        {
            var fileSyncOptions = new FileSyncOptions();

            // I'm guessing there is a nicer way to do this but for now, it works.
            if (fileSyncPairInfo.OptionsCompareFileStreams)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.CompareFileStreams;
            }
            if (fileSyncPairInfo.OptionsCompareFileStreams)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.CompareFileStreams;
            }
            if (fileSyncPairInfo.OptionsRecycleConflictLoserFiles)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.RecycleConflictLoserFiles;
            }
            if (fileSyncPairInfo.OptionsRecycleDeletedFiles)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.RecycleDeletedFiles;
            }
            if (fileSyncPairInfo.OptionsRecyclePreviousFileOnUpdates)
            {
                fileSyncOptions = fileSyncOptions | FileSyncOptions.RecyclePreviousFileOnUpdates;
            }
            return fileSyncOptions;
        }



       
    }
}
