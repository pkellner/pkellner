﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.Enums
{
    public enum FolderPairActionTypeEnum
    {
        Echo = 1,
        Contribute = 2,
        Synchronize = 3
    }
}
