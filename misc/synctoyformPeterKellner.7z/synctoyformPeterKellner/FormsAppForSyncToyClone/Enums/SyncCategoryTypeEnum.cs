﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.Enums
{
    public enum SyncCategoryTypeEnum
    {
        FilePairUNC = 1,
        DbConnectionStringPair = 2
    }
}
