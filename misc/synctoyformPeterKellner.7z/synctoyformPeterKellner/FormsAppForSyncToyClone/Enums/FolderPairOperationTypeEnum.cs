﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.Enums
{
    public enum FolderPairOperationTypeEnum
    {
        DeleteFolder = 1,
        Delete = 2,
        Overwrite = 3,
        Rename = 4,
        New = 5
    }
}
