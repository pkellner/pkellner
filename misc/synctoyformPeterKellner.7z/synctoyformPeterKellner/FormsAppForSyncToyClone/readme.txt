the SyncSDK-v2.0-x64-ENU.msi file should be installed.  It is the synchronization 2.0 api.

then, in vs2010, open the solution in FormSyncFileSoltution.  That should build and run.

Add a sync file pair in the format c:\\dir1  and c:\\dir2  with some name.  save it with button below.

select it, then press perform sync