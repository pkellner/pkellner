using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            GenList();
            GenListForDelete();
        }

        if (Context.User.Identity.IsAuthenticated)
        {
            ButtonUpload.Enabled = true;
            Login1.Visible = false;
            LoginStatus1.Visible = true;
            ButtonShowFiles.Visible = true;
            ListBox1.Visible = true;
            DropDownList1.Visible = true;
            ButtonDeleteFile.Visible = true;

            


        }
        else
        {
            ButtonUpload.Enabled = false;
            Login1.Visible = true;
            LoginStatus1.Visible = false;
            ButtonShowFiles.Enabled = false;
            ListBox1.Visible = false;

            DropDownList1.Visible = false;
            ButtonDeleteFile.Visible = false;


        }


    }
    protected void ButtonUpload_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            Label1.Text = "Received " + FileUpload1.FileName + " Content Type " + FileUpload1.PostedFile.ContentType + " Length " + FileUpload1.PostedFile.ContentLength;
            FileUpload1.SaveAs(MapPath("~") + "\\" + FileUpload1.FileName);
            GenList();
            GenListForDelete();
        }
    }
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        if (FormsAuthentication.Authenticate(Login1.UserName, Login1.Password))
        {
            e.Authenticated = true;
        }
        else
        {
            e.Authenticated = false;
            //FormsAuthentication.SetAuthCookie(Login1.UserName, true);
        }


    }
    protected void ButtonShowFiles_Click(object sender, EventArgs e)
    {
        
        
        GenList();
        GenListForDelete();

    }

    private void GenList()
    {
        ListBox1.Items.Clear();
        foreach (string s in Directory.GetFiles(MapPath("~")))
        {
            if (!s.EndsWith("Default.aspx") && !s.EndsWith("Default.aspx.cs") && !s.EndsWith("Web.config"))
            {
                ListBox1.Items.Add(Path.GetFileName(s));
            }
        }
    }

    private void GenListForDelete()
    {
        DropDownList1.Items.Clear();
        foreach (string s in Directory.GetFiles(MapPath("~")))
        {
            if (!s.EndsWith("Default.aspx") && !s.EndsWith("Default.aspx.cs") && !s.EndsWith("Web.config"))
            {
                DropDownList1.Items.Add(s);
            }
        }
    }
   
    protected void ButtonDeleteFile_Click1(object sender, EventArgs e)
    {
        string str = DropDownList1.SelectedValue;

        File.Delete(str);

      GenList();
        GenListForDelete();

    }
}
