// <copyright file="SyncMain.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//  Sample code for using the MSF File Sync Provider
//
//</summary>

using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Synchronization;
using Microsoft.Synchronization.Files;

public class FileSyncProviderSample
{

    /// <summary>
    /// The codes demonstrate how the framework is not able to handle "Cut and Paste" scenario.
    /// 
    /// Steps:
    ///     1. Create two directories named "FolderA" and "FolderB" ( in my example I used C:\tmp\FolderA and C:\tmp\FolderB  for all my folder pairs )
    ///     2. Add two (2) subfolders and name it "subfolder1" and "subfolder2" inside "FolderA" with files on it.
    ///     3. Comment the lines 66 and 67 below this file.
    ///     4. Do a sync by compiling and running ( FolderA and FolderB should have the same content )
    ///     5. Open the folder "FolderA", select and cut subfolder1 then paste it inside subfolder2
    ///     6  Uncomment the lines 66 and 67 below this file.
    ///     5. Do a sync ( You should see errors in the console )
    /// 
    /// Normally the last sync should delete the folder "FolderB\subfolder1" because "FolderB\subfolder1" is no where to be found.
    /// No where to be found because "FolderA\subfolder1" has been transfered inside "FolderA\subfolder2\".
    /// 
    /// The error comes up because it tries to delete "FolderB\subfolder1" since "FolderB\subfolder1" no longer exists.
    /// However, as soon as it tries to delete "FolderB\subfolder1" the system prevents it from doing so because the folder in question is not yet empty.
    /// 
    /// Sample console output:
    /// 
    /// Synchronizing changes to replica : "C:\tmp\FolderB"
    /// 
    ///     Exclude subfolder2\subfolder1
    ///         -- Skipped applying CREATE for subfolder2\subfolder1 due to error
    ///         -- Skipped applying RENAME for subfolder1\1.jp due to error
    ///             [The system cannot find the path specified. (Exception from HRESULT : 0x80070003)]
    ///         -- Skipped applying DELETE for subfolder1 due to error
    ///             [The directory is not empty. (Exception from HRESULT: 0x80070091)]
    ///     Synchronizing changes to replica : C:\tmp\FolderA
    /// 
    /// </summary>

    public static List<string> ExcludedSubFolders;

    public static void Main(string[] args)
    {

        ExcludedSubFolders = new List<string>();

        string replica1RootPath;
        string replica2RootPath;


        replica1RootPath = @"c:\tmp\FolderA";
        replica2RootPath = @"c:\tmp\FolderB";

        // Comment below the code for your first sync.
        //ExcludedSubFolders.Add(@"subfolder2\subfolder1");
        //ExcludedSubFolders.Add("subfolder2");

        try
        {
            // Set options for the sync operation
            FileSyncOptions options = FileSyncOptions.ExplicitDetectChanges |
                                      FileSyncOptions.RecycleDeletedFiles | FileSyncOptions.RecyclePreviousFileOnUpdates |
                                      FileSyncOptions.RecycleConflictLoserFiles;

            var filter = new FileSyncScopeFilter();
            filter.FileNameExcludes.Add("*.lnk"); // Exclude all *.lnk files
            filter.FileNameExcludes.Add("*.dat");

            // Explicitly detect changes on both replicas upfront, to avoid two change 
            // detection passes for the two-way sync
            DetectChangesOnFileSystemReplica(
                replica1RootPath, filter, options);
            DetectChangesOnFileSystemReplica(
                replica2RootPath, filter, options);

            // Sync in both directions
            SyncFileSystemReplicasOneWay(replica1RootPath, replica2RootPath, null, options);
            SyncFileSystemReplicasOneWay(replica2RootPath, replica1RootPath, null, options);

            Console.ReadLine();
        }
        catch (Exception e)
        {
            Console.WriteLine("\nException from File Sync Provider:\n" + e.ToString());
        }
    }

    public static void DetectChangesOnFileSystemReplica(
            string replicaRootPath,
            FileSyncScopeFilter filter, FileSyncOptions options)
    {
        FileSyncProvider provider = null;

        try
        {
            provider = new FileSyncProvider(replicaRootPath, filter, options);
            provider.DetectChanges();
        }
        finally
        {
            // Release resources
            if (provider != null)
                provider.Dispose(); 
        }
    }

    public static void SyncFileSystemReplicasOneWay(
            string sourceReplicaRootPath, string destinationReplicaRootPath,
            FileSyncScopeFilter filter, FileSyncOptions options)
    {
        FileSyncProvider sourceProvider = null;
        FileSyncProvider destinationProvider = null;

        try
        {
            sourceProvider = new FileSyncProvider(
                sourceReplicaRootPath, filter, options);
            destinationProvider = new FileSyncProvider(
                destinationReplicaRootPath, filter, options);

            destinationProvider.AppliedChange +=  new EventHandler<AppliedChangeEventArgs>(OnAppliedChange);
            destinationProvider.SkippedChange +=  new EventHandler<SkippedChangeEventArgs>(OnSkippedChange);
            destinationProvider.ApplyingChange += CallBackApplyingChanged;

            SyncOrchestrator agent = new SyncOrchestrator();
            agent.LocalProvider = sourceProvider;
            agent.RemoteProvider = destinationProvider;
            agent.Direction = SyncDirectionOrder.Upload; // Sync source to destination

            Console.WriteLine("Synchronizing changes to replica: " + 
                destinationProvider.RootDirectoryPath);
            agent.Synchronize();
        }
        finally
        {
            // Release resources
            if (sourceProvider != null) sourceProvider.Dispose(); 
            if (destinationProvider != null) destinationProvider.Dispose();
        }
    }

    private static void CallBackApplyingChanged(object sender, ApplyingChangeEventArgs e)
    {
        if (e.NewFileData != null)
        {
            var relativePath = e.NewFileData.RelativePath;
            if (ExcludedSubFolders.Contains(relativePath))
            {
                Console.WriteLine("Exlcude " + relativePath);
                e.SkipChange = true;
            }
        }
    }

    public static void OnAppliedChange(object sender, AppliedChangeEventArgs args)
    {
        switch(args.ChangeType)
        {
            case ChangeType.Create: 
               Console.WriteLine("-- Applied CREATE for file " + args.NewFilePath); 
               break;
            case ChangeType.Delete:
               Console.WriteLine("-- Applied DELETE for file " + args.OldFilePath); 
               break;
            case ChangeType.Update:
               Console.WriteLine("-- Applied OVERWRITE for file " + args.OldFilePath); 
               break;
            case ChangeType.Rename:
               Console.WriteLine("-- Applied RENAME for file " + args.OldFilePath + 
                                 " as " + args.NewFilePath); 
               break;
        }
    }

    public static void OnSkippedChange(object sender, SkippedChangeEventArgs args)
    {
        Console.WriteLine("-- Skipped applying " + args.ChangeType.ToString().ToUpper() 
              + " for " + (!string.IsNullOrEmpty(args.CurrentFilePath) ? 
                            args.CurrentFilePath : args.NewFilePath) + " due to error");
              
        if (args.Exception != null)
            Console.WriteLine("   [" + args.Exception.Message + "]");
    }
}
