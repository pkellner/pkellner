﻿Ext.BLANK_IMAGE_URL = '../ExtJS/resources/images/default/s.gif';
Ext.onReady(function() {

			var simpleForm = new Ext.FormPanel({
						region : 'north',
						height : 80,
						labelWidth : 75, // label settings here cascade
						frame : true,
						title : 'Simple Form',
						width : 350,
						defaults : {
							width : 230
						},
						defaultType : 'textfield',
						items : [{
									fieldLabel : 'First Name',
									name : 'first'
								}]
					});

			var myContentIdWidth = 700;
			var panel = new Ext.Panel({

						title : '',
						layout : 'border',
						width : myContentIdWidth,
						height : 500,
						items : [simpleForm, {
									title : 'Main Content',
									height : 300,
									region : 'center',
									margins : '5 5 0 0'
								}]

					});
			panel.render('mydiv');

		});