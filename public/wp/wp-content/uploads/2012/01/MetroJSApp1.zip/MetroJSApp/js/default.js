﻿// convenience functions
// poor man's array to string
function bin2String(array) {
    var result = "";
    for (var i = 0; i < array.length; i++) {
        // only printable characters (include spaces because could be part of names)
        // http://www.csgnetwork.com/asciiset.html
        if (array[i] >= 32 && array[i] <= 126) {
            var c = String.fromCharCode(array[i]);
            result += c;
        }
    }
    return result;
}

// read the file you want
function ReadAllDataFile(fileNameInLocalTree) {
    
    var package = Windows.ApplicationModel.Package.current;
    var installedLocation = package.installedLocation;

    installedLocation.createFileAsync(fileNameInLocalTree, Windows.Storage.CreationCollisionOption.openIfExists).then(function (dataFile) {
        dataFile.openAsync(Windows.Storage.FileAccessMode.read).then(function (stream) {
            var size = stream.size;
            if (size == 0) {
                // Data not found
            }
            else {
                var inputStream = stream.getInputStreamAt(0);
                var reader = new Windows.Storage.Streams.DataReader(inputStream);

                reader.loadAsync(size).then(function () {

                    //var contents = reader.readString(size); // fails with multibyte error if bad data (see legislators.getList.json)

                    // allocate the full array so readBytes can insert it in full
                    var array = new Array(size);
                    reader.readBytes(array);
                    
                    var newString = "";
                    for (var i = 0; i < array.length; i++) {
                        // only printable characters (include spaces because could be part of names) (very rough here)
                        // http://www.csgnetwork.com/asciiset.html
                        if (array[i] >= 32 && array[i] <= 126) {
                            var c = String.fromCharCode(array[i]);
                            newString += c;
                        }
                    }

                    
                    var result = JSON.parse(newString);
                    var newYorkPopulation = result.NY.P001001;

                    // output to the screen
                    document.getElementById('outputhere').innerHTML = "New York Population: " + newYorkPopulation;
                    
                });
            }
        })
    });
}

(function () {
    'use strict';
    // Uncomment the following line to enable first chance exceptions.
    Debug.enableFirstChanceException(true);

    WinJS.Application.onmainwindowactivated = function (e) {
        if (e.detail.kind === Windows.ApplicationModel.Activation.ActivationKind.launch) {
            
            // start of my insert code            
            ReadAllDataFile("\data\\states_data.json");
            // end of my insert code
        }
    }

    WinJS.Application.start();
})();