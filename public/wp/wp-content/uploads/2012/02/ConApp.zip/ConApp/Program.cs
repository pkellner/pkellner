﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace ConApp
{
    internal class Program
    {
        private static void Main()
        {
            Database.SetInitializer<SiteDB>(new SiteDBInitialize());
            using (var myContext = new SiteDB())
            {
                var x = myContext.Presidents.ToList();
            }
        }
    }

    public class SiteDB : DbContext
    {
        public DbSet<Presidents> Presidents { get; set; }
    }

    public class Presidents
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public string LastName { get; set; }

        // New Columns for first migration
        public int YearElected { get; set; }
        public bool CurrentPresident { get; set; }

        // New Column for second migration
        public string Party { get; set; }
    }

    public class SiteDBInitialize :
        CreateDatabaseIfNotExists<SiteDB>
    {
        protected override void Seed(SiteDB context)
        {
            context.Presidents.Add(new Presidents
                                       {
                                           LastName = "Reagan",
                                           CurrentPresident = false,
                                           YearElected = 1980
                                       });
            context.Presidents.Add(new Presidents
                                       {
                                           LastName = "Bush",
                                           CurrentPresident = false,
                                           YearElected = 1992
                                       });
            context.Presidents.Add(new Presidents
                                       {
                                           LastName = "Obama",
                                           CurrentPresident = true,
                                           YearElected = 2008
                                       });
            context.SaveChanges();
        }
    }

}
