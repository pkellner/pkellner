﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace proj
{
    public partial class Page : Canvas
    {
        Canvas _button;
        Storyboard _storyboard;
        Storyboard _xamlStoryboard;

        public void Page_Loaded(object o, EventArgs e)
        {
            // Required to initialize variables
            InitializeComponent();

            _button = (Canvas)this.FindName("ButtonDoit");
            _button.MouseLeftButtonUp += 
                new MouseEventHandler(_button_MouseLeftButtonUp);

            _storyboard = (Storyboard)this.FindName("Timeline2");
        }

        void _button_MouseLeftButtonUp(object sender, MouseEventArgs e)
        {
         
            String xamlStringTemplate = @"
                        
            		    <Storyboard>
            			<DoubleAnimationUsingKeyFrames BeginTime='00:00:00' Storyboard.TargetName='textBlock' Storyboard.TargetProperty='(Canvas.Top)'>
            				<SplineDoubleKeyFrame KeyTime='00:00:01' Value='{0}'/>
            			</DoubleAnimationUsingKeyFrames>
                		</Storyboard>";

            String xamlString = String.Format(xamlStringTemplate, "100");


            _xamlStoryboard = (Storyboard)XamlReader.Load(xamlString);
            _xamlStoryboard.AutoReverse = true;
            _xamlStoryboard.SetValue(Storyboard.NameProperty, "timeline2");
            
            Resources.Add(_xamlStoryboard);

            _xamlStoryboard.Begin();

            _xamlStoryboard.Completed += new EventHandler(_xamlStoryboard_Completed);

        }

        void _xamlStoryboard_Completed(object sender, EventArgs e)
        {
            Resources.Remove(_xamlStoryboard);
        }
    }
}
