﻿using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : Page
{
    /// <summary>
    /// make sure you have auto events enabled or this will not get called
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        // Grab up items selected in checkbox list (use StringBuilder, much more efficient)
        var sb = new StringBuilder();
        foreach (ListItem li in CheckBoxList1.Items)
        {
            // if the checkbox is selected, add it to the string
            if (li.Selected)
            {
                sb.Append(li.Value);
                sb.Append(";");
            }
        }
        // Get rid of final pesky semicolon so as not to trip up the businessobject
        Label1.Text = sb.ToString().TrimEnd(new[] {';'});
    }

    /// <summary>
    /// cause a page refresh and the gridview to reread it's objectdatasource bus object
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ButtonSearch_Click(object sender, EventArgs e)
    {
        GridView1.DataBind();
    }
}