using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace BO
{

    /// <summary>
    /// Summary description for ODS
    /// </summary>
    /// 
    [DataObject(true)] // This attribute allows the ObjectDataSource wizard to see this class
    public class BusinessObject
    {

        public BusinessObject()
        {
        }

        public List<Person> GetPeopleByCityList(List<int> cityList)
        {
            List<Person> personList = new List<Person>
                                          {
                                              new Person("Peter_SanJose", 1),
                                              new Person("Tom_Hartsdale", 2),
                                              new Person("Eric_Chicago", 3),
                                              new Person("Ron_SanJose", 1),
                                              new Person("John_Chicago", 3),
                                              new Person("Charly_Scarsdale", 4)
                                          };

            var personResult = from p in personList
                               where cityList.Contains(p.id)
                               orderby p.name
                               select p;

            return personResult.ToList();
        }

        public List<Person> GetPeopleByCityListString(string cityListString)
        {
            if (!String.IsNullOrEmpty(cityListString))
            {
                var values = cityListString.Split(';');
                var cityList = new List<int>();
                foreach (string s in values)
                {
                    cityList.Add(Convert.ToInt32(s));
                }

                return GetPeopleByCityList(cityList);
            }
            return null;
        }

    }

    public class Person
    {
        public Person()
        {
        }

        public Person(string _name, int _id)
        {
            this._name = _name;
            this._id = _id;
        }

        private string _name;
        private int _id;

        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
    }

}
    