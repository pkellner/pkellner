﻿Ext.onReady(function() {

	Ext.BLANK_IMAGE_URL = 'Images/s.gif';

	Ext.QuickTips.init();

	var colorArray = new Array('red', 'green', 'blue', 'orange');

	var colorObject = [{
				id : 'pink',
				html : 'pink-HTML',
				tag : 'a',
				href : 'http://www.mycolor.com/pink'
			}];

	var myColor = new Object;
	myColor.id = 'purple';
	myColor.html = 'purple-HTML';
	myColor.tag = 'a';
	myColor.href = 'http://www.mycolor.com/purple'
	colorObject.push(myColor);

	for (i = 0; i < colorArray.length; i++) {
		var colorToAdd = new Object;
		colorToAdd.id = colorArray[i];
		colorToAdd.html = colorArray[i] + '-HTML';
		colorToAdd.tag = 'a';
		colorToAdd.href = 'http://www.mycolor.com/' + colorArray[i];
		colorObject.push(colorToAdd);
	}

	var colorsDivId = Ext.DomHelper.append(document.body, [{
						id : 'colors'
					}]);

	Ext.DomHelper.append(colorsDivId, colorObject);
});

/*
 * Ext.DomHelper.append(document.body, { id : 'colors', children : [{ id :
 * 'red', html : 'red' }, { id : 'blue', html : 'blue' }, { id : 'green', html :
 * 'green' }] });
 */

// Ext.fly('colors').on('click', function(e, t) {
// if (t.id === 'red') {
// Ext.MessageBox.alert('red picked');
// } else {
// alert('cl')
// };
// });
