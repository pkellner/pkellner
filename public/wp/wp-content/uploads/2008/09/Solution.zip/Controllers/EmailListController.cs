﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Solution.Controllers
{
    public class EmailListController : Controller
    {
        public ActionResult Index()
        {
            var businessObject = new BusinessObject();
            List<BusinessObjectItem> members = 
                businessObject.GetMembers();
            return View("Index", members);
        }
    }
}