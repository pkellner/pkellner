using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Web;
using System.Xml.Serialization;

/// <summary>
/// Summary description for ODS
/// </summary>
/// 
[DataObject(true)] // This attribute allows the ObjectDataSource wizard to see this class
public class BusinessObject //: ISerializable
{
    private readonly string fileNameToSerializeTo;
    private readonly List<BusinessObjectItem> listBusinessObject;

    public BusinessObject()
    {
        // If fails to open, create some records.  It will be written out on save.
        try
        {
            fileNameToSerializeTo = HttpContext.Current.Server.MapPath("~/DataFileForPersistance.txt");
            var xmls = new XmlSerializer(new List<BusinessObjectItem>().GetType());
            var sr = new StreamReader(fileNameToSerializeTo);
            listBusinessObject = (List<BusinessObjectItem>) xmls.Deserialize(sr);
            sr.Close();
        }
        catch (Exception)
        {
            listBusinessObject = new List<BusinessObjectItem>
                                     {
                                         new BusinessObjectItem(1001, "George Washington", "washington@whitehouse.gov",
                                                                true,
                                                                DateTime.Now),
                                         new BusinessObjectItem(1002, "John Adams", "Jimmy@@whitehouse.gov", false,
                                                                DateTime.Now),
                                         new BusinessObjectItem(1003, "Thomas Jefferson", "TJefferson@whitehouse.gov",
                                                                false,
                                                                DateTime.Now),
                                         new BusinessObjectItem(1003, "James Madison", "JamesMadison@whitehouse.gov",
                                                                false,
                                                                DateTime.Now),
                                         new BusinessObjectItem(1003, "James Monroe", "JamesMonroe@whitehouse.gov",
                                                                false,
                                                                DateTime.Now)
                                     };
        }
    }


    [DataObjectMethod(DataObjectMethodType.Select, true)]
    public List<BusinessObjectItem> GetMembers()
    {
        listBusinessObject.Sort(
            new Comparison<BusinessObjectItem>(
                (lhs, rhs) => lhs.Name.CompareTo(rhs.Name)));
        return listBusinessObject;
    }

    [DataObjectMethod(DataObjectMethodType.Select, false)]
    public List<BusinessObjectItem> GetMembers(int Id)
    {
        var listBusinessObjectFiltered = new List<BusinessObjectItem>();
        foreach (BusinessObjectItem currentBusinessObject in listBusinessObject)
        {
            if (currentBusinessObject.Id == Id)
            {
                listBusinessObjectFiltered.Add(currentBusinessObject);
            }
        }
        return listBusinessObjectFiltered;
    }


    [DataObjectMethod(DataObjectMethodType.Insert, true)]
    public void Insert(int Id, string Name, string Email, bool Approved, DateTime CreateDate)
    {
        bool foundDuplicate = false;
        int currentMax = 0;
        foreach (BusinessObjectItem currentBusinessObject in listBusinessObject)
        {
            if (currentMax < currentBusinessObject.Id)
            {
                currentMax = currentBusinessObject.Id;
            }

            if (currentBusinessObject.Id == Id)
            {
                foundDuplicate = true;
            }
        }
        if (foundDuplicate || Id < 0)
        {
            listBusinessObject.Add(new BusinessObjectItem(currentMax + 1, Name, Email, Approved, CreateDate));
        }
        else
        {
            listBusinessObject.Add(new BusinessObjectItem(Id, Name, Email, Approved, CreateDate));
        }
        SerializeList(fileNameToSerializeTo);
    }

    [DataObjectMethod(DataObjectMethodType.Delete, true)]
    public void Delete(int Id)
    {
        BusinessObjectItem foundBusinessObject = null;
        foreach (BusinessObjectItem currentBusinessObject in listBusinessObject)
        {
            if (currentBusinessObject.Id == Id)
            {
                foundBusinessObject = currentBusinessObject;
                break;
            }
        }
        if (foundBusinessObject != null)
        {
            listBusinessObject.Remove(foundBusinessObject);
        }
        SerializeList(fileNameToSerializeTo);
    }

    [DataObjectMethod(DataObjectMethodType.Update, false)]
    public void Update(BusinessObjectItem businessObject)
    {
        BusinessObjectItem foundBusinessObject = null;
        foreach (BusinessObjectItem currentBusinessObject in listBusinessObject)
        {
            if (currentBusinessObject.Id == businessObject.Id)
            {
                foundBusinessObject = currentBusinessObject;
                break;
            }
        }
        if (foundBusinessObject != null)
        {
            listBusinessObject.Remove(foundBusinessObject);
            listBusinessObject.Add(new BusinessObjectItem(foundBusinessObject));
        }
        SerializeList(fileNameToSerializeTo);
    }


    [DataObjectMethod(DataObjectMethodType.Update, true)]
    public void Update(int Id, string Name, string Email, bool Approved, DateTime CreateDate)
    {
        BusinessObjectItem foundBusinessObject = null;
        foreach (BusinessObjectItem currentBusinessObject in listBusinessObject)
        {
            if (currentBusinessObject.Id == Id)
            {
                foundBusinessObject = currentBusinessObject;
                break;
            }
        }
        if (foundBusinessObject != null)
        {
            listBusinessObject.Remove(foundBusinessObject);
            listBusinessObject.Add(new BusinessObjectItem(Id, Name, Email, Approved, CreateDate));
        }
        SerializeList(fileNameToSerializeTo);
    }

    private void SerializeList(string fileName)
    {
        var xmls = new XmlSerializer(new List<BusinessObjectItem>().GetType());
        var sw = new StreamWriter(fileName);
        xmls.Serialize(sw, listBusinessObject);
        sw.Close();
    }
}

/// <summary>
/// This is the DataItem that is used in the methods of the class above
/// </summary>
public class BusinessObjectItem
{
    private bool approved;
    private DateTime createDate;
    private string email;
    private int id;
    private string name;

    public BusinessObjectItem()
    {
    }

    public BusinessObjectItem(BusinessObjectItem bo)
    {
        id = bo.id;
        name = bo.name;
        email = bo.email;
        approved = bo.approved;
        createDate = bo.createDate;
        return;
    }

    public BusinessObjectItem(int id, string name, string email, bool approved, DateTime createDate)
    {
        this.id = id;
        this.name = name;
        this.email = email;
        this.approved = approved;
        this.createDate = createDate;
        return;
    }

    [DataObjectField(true)]
    public int Id
    {
        get { return id; }
        set { id = value; }
    }

    [DataObjectField(false)]
    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    [DataObjectField(false)]
    public string Email
    {
        get { return email; }
        set { email = value; }
    }

    [DataObjectField(false)]
    public bool Approved
    {
        get { return approved; }
        set { approved = value; }
    }

    [DataObjectField(false)]
    public DateTime CreateDate
    {
        get { return createDate; }
        set { createDate = value; }
    }
}