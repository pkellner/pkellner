﻿
/// <summary>
/// This is the DataItem that is used in the methods of the class above
/// </summary>
using System;
using System.ComponentModel;
public class BusinessObjectItem
{
    private bool approved;
    private DateTime createDate;
    private string email;
    private int id;
    private string name;

    public BusinessObjectItem()
    {
    }

    public BusinessObjectItem(BusinessObjectItem bo)
    {
        id = bo.id;
        name = bo.name;
        email = bo.email;
        approved = bo.approved;
        createDate = bo.createDate;
        return;
    }

    public BusinessObjectItem(int id, string name, string email, bool approved, DateTime createDate)
    {
        this.id = id;
        this.name = name;
        this.email = email;
        this.approved = approved;
        this.createDate = createDate;
        return;
    }

    [DataObjectField(true)]
    public int Id
    {
        get { return id; }
        set { id = value; }
    }

    [DataObjectField(false)]
    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    [DataObjectField(false)]
    public string Email
    {
        get { return email; }
        set { email = value; }
    }

    [DataObjectField(false)]
    public bool Approved
    {
        get { return approved; }
        set { approved = value; }
    }

    [DataObjectField(false)]
    public DateTime CreateDate
    {
        get { return createDate; }
        set { createDate = value; }
    }
}