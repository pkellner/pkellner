﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Threading;
using System.Web;

[DataObject(true)] // This attribute allows the ObjectDataSource wizard to see this class
public class BusinessObjectGeneral3
{
    private const string lockval = "lock";

    public List<BusinessObjectItem> GetData3(int numberRecordsToReturn, int delayMilliSeconds)
    {
        var listBusinessObjectItemsGeneral = new List<BusinessObjectItem>(numberRecordsToReturn);
        for (int i = 0; i < numberRecordsToReturn; i++)
        {
            var boi = new BusinessObjectItem
                          {
                              Name = RandomString(30, false),
                              CreateDate = DateTime.Now,
                              Email =
                                  string.Format("{0}@{1}.com", RandomString(5, true), RandomString(10, true)),
                              Approved = false,
                              Id = (i + 1)
                          };
            listBusinessObjectItemsGeneral.Add(boi);
        }
        Thread.Sleep(delayMilliSeconds);
        return listBusinessObjectItemsGeneral;
    }


    [DataObjectMethod(DataObjectMethodType.Select, true)]
    public List<BusinessObjectItem> GetDataCached3(int numberRecordsToReturn,
                                                   int delayMilliSeconds)
    {
        const string cacheName = "CACHE-LIST-BUSINESS";
        var listBusinessObjectItemsGeneral =
            (List<BusinessObjectItem>) HttpContext.Current.Cache[cacheName];
        if (listBusinessObjectItemsGeneral == null)
        {
            Monitor.Enter(lockval);
            try
            {
                // check it again in case someone else loaded the cache and we 
                // hit the null condition before the cache was fully loaded.
                listBusinessObjectItemsGeneral =
                    (List<BusinessObjectItem>) HttpContext.Current.Cache[cacheName];
                if (listBusinessObjectItemsGeneral == null)
                {
                    listBusinessObjectItemsGeneral =
                        GetData3(numberRecordsToReturn, delayMilliSeconds);
                    HttpContext.Current.Cache.Insert(cacheName,
                                                     listBusinessObjectItemsGeneral,
                                                     null,
                                                     DateTime.Now.Add(new TimeSpan(0, 0, 5)), TimeSpan.Zero);
                }
            }
            finally
            {
                Monitor.Exit(lockval);
            }
        }
        return listBusinessObjectItemsGeneral;
    }


    /// <summary>
    /// Generates a random string with the given length
    /// </summary>
    /// <param name="size">Size of the string</param>
    /// <param name="lowerCase">If true, generate lowercase string</param>
    /// <returns>Random string</returns>
    private static string RandomString(int size, bool lowerCase)
    {
        var builder = new StringBuilder();
        var random = new Random();
        for (int i = 0; i < size; i++)
        {
            char ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26*random.NextDouble() + 65)));
            builder.Append(ch);
        }
        return lowerCase ? builder.ToString().ToLower() : builder.ToString();
    }

    private void LogStatus(CacheStatus cacheStatus)
    {
    }

    #region Nested type: CacheStatus

    private enum CacheStatus
    {
        CachedOnFirstTry = 0,
        CachedOnSecondTry = 1,
        NotCached = 2
    }

    #endregion
}