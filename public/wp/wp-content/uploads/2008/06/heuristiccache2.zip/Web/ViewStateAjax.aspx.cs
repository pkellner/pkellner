﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Threading;

public partial class ViewStateAjax : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // for some reason, the Alert is not coming through, but viewstate is reloaded.
       
    }
    protected void ButtonWait_Click(object sender, EventArgs e)
    {
        Thread.Sleep(1000);
    }
}
