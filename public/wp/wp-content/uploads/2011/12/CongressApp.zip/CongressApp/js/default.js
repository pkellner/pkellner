﻿
convertGovTrackIdToImgTag = WinJS.Binding.converter(function (govTrackId) {
    var retUrl = 'http://www.govtrack.us/data/photos/' + govTrackId + '-50px.jpeg';
    return retUrl;
});


var itemDataSource = {};

(function () {
    'use strict';
    // Uncomment the following line to enable first chance exceptions.
    Debug.enableFirstChanceException(true);

    //allLegislatorsCreateFile();


    WinJS.Application.onmainwindowactivated = function (e) {
        if (e.detail.kind === Windows.ApplicationModel.Activation.ActivationKind.launch) {

            var items = [];
            var itemsFresh = [{
                firstname: "Barack",
                lastname: "Obama",
                govtrack_id: "400629"
            },
            {
                firstname: "Adam",
                lastname: "Smith",
                govtrack_id: "400379"
            },
            {
                firstname: "Adrian",
                lastname: "Smith",
                govtrack_id: "412217"
            }];
            items.push(itemsFresh[0]);
            items.push(itemsFresh[1]);
            items.push(itemsFresh[2]);

            itemDataSource = new WinJS.UI.ArrayDataSource(items);
            WinJS.UI.processAll();
        }
    }
    WinJS.Application.start();
})();

