﻿CREATE TABLE [dbo].[LinqTest] (
  [Id] int IDENTITY(1, 1) NOT NULL,
  [FileName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [FileSize] nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [UploadDate] datetime NULL,
  [DownloadDate] datetime NULL,
  [ProcessDate] datetime NULL,
  CONSTRAINT [LinqTest_PK] PRIMARY KEY CLUSTERED ([Id])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [LinqTest_FileName_IX] ON [dbo].[LinqTest]
  ([FileName])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO