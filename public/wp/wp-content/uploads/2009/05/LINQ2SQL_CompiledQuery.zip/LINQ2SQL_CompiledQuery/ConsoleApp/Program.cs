﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Linq;

namespace ConsoleApp
{
    /// <summary>
    /// The SQL code this program runs against is at the bottom of the file.
    /// </summary>
    internal class Program
    {
        private static void Main()
        {
            const int iterations = 5000;
            new Program();

            double milliSecondsSqlOnly = TestDataAccessSqlOnly(iterations);
            Console.WriteLine("SqlOnly: " + milliSecondsSqlOnly);

            double milliSecondsL2SNotCompiled = TestDataAccessSpeedLinq2SqlNotCompiled(iterations);
            Console.WriteLine("L2SNotCompiled: " + milliSecondsL2SNotCompiled);

            double milliSecondsL2SCompiled = TestDataAccessSpeedLinq2SqlCompiled(iterations);
            Console.WriteLine("L2SCompiled: " + milliSecondsL2SCompiled);
        }

        /// <summary>
        /// This method compiles the LINQ to SQL query and 
        /// then executes it the number of iterations passed
        /// in.  
        /// </summary>
        /// <param name="iterations">Number of iterations</param>
        /// <returns>time in seconds of execution</returns>
        private static double 
            TestDataAccessSpeedLinq2SqlCompiled(int iterations)
        {
            Func<DataClassesDataContext, string, IQueryable<LinqTest>> compiledQuery =
                CompiledQuery.Compile((DataClassesDataContext meta,string fileNameForSearch) =>
                                      (from myData in meta.LinqTests
                                       orderby myData.Id
                                       where myData.FileName.Equals(fileNameForSearch)
                                       select myData));

            var metaNew = new DataClassesDataContext();
            DateTime startTime = DateTime.Now;
            for (int i = 0; i < iterations; i++)
            {
                IOrderedQueryable<LinqTest> query = 
                    (IOrderedQueryable<LinqTest>) 
                    compiledQuery(metaNew,string.Format("abcde{0}", i));
                List<LinqTest> newList = query.ToList();
            }
            return 
                DateTime.Now.Subtract(startTime).Duration().TotalSeconds;
        }

        private static double TestDataAccessSpeedLinq2SqlNotCompiled(int iterations)
        {
            var meta = new DataClassesDataContext();
            DateTime startTime = DateTime.Now;
            for (int i = 0; i < iterations; i++)
            {
                string searchVal = "abcde" + i;
                IOrderedQueryable<LinqTest> query = from myData in meta.LinqTests
                                                    where myData.FileName.Equals(searchVal)
                                                    orderby myData.Id
                                                    select myData;
                List<LinqTest> newList = query.ToList();
            }
            return DateTime.Now.Subtract(startTime).Duration().TotalSeconds;
        }

        private static double TestDataAccessSqlOnly(int iterations)
        {
            const string query =
                @"
                SELECT 
                  dbo.LinqTest.Id,
                  dbo.LinqTest.FileName,
                  dbo.LinqTest.FileSize,
                  dbo.LinqTest.UploadDate,
                  dbo.LinqTest.DownloadDate,
                  dbo.LinqTest.ProcessDate
                FROM
                  dbo.LinqTest
                WHERE dbo.LinqTest.FileName = @FileName
                ";

            double timeSeconds;
            const string connectionStringName = "ConsoleApp.Properties.Settings.LinqPerfConnectionString";
            string str =
                ConfigurationManager.ConnectionStrings[connectionStringName].ConnectionString;
            using (var conn = new SqlConnection(str))
            {
                conn.Open();
                using (var command = new SqlCommand(query, conn))
                {
                    SqlParameter paramFileName = command.Parameters.Add("@FileName", SqlDbType.NVarChar);
                    DateTime startTime = DateTime.Now;
                    for (int i = 0; i < iterations; i++)
                    {
                        paramFileName.Value = "abcde" + i;
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var retString = reader.GetValue(0) as string;
                            }
                        }
                    }
                    timeSeconds = DateTime.Now.Subtract(startTime).Duration().TotalSeconds;
                }
            }
            return timeSeconds;
        }
    }
}

/*
 
 CREATE TABLE [dbo].[LinqTest] (
  [Id] int IDENTITY(1, 1) NOT NULL,
  [FileName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [FileSize] nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [UploadDate] datetime NULL,
  [DownloadDate] datetime NULL,
  [ProcessDate] datetime NULL,
  CONSTRAINT [LinqTest_PK] PRIMARY KEY CLUSTERED ([Id])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [LinqTest_FileName_IX] ON [dbo].[LinqTest]
  ([FileName])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

*/