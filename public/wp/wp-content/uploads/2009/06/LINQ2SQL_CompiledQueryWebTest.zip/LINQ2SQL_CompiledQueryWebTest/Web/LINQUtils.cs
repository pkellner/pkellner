﻿// C Peter Kellner 2009      http://peterkellner.net


using System;
using System.Data.Linq;
using System.Diagnostics;
using System.Linq;


namespace Web
{
    
    public class LINQUtils
    {
        private const int iterations = 7;

        public static Func<DataClassesDataContext, int, IQueryable<Company>> _compiledQuery;

        [ThreadStatic]
        private static DataClassesDataContext meta;
        
        public string ProcessLinqQueryCompiled()
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();

            int retCnt = 0;
            for (int i = 0; i < iterations; i++)
            {
                const int companyTypeIdToFind = 1;

                if (meta == null)
                {
                    meta = new DataClassesDataContext();
                }

                if (_compiledQuery == null)
                {
                    _compiledQuery =
                        CompiledQuery.Compile((DataClassesDataContext metax, int myQuery) =>
                                              (from dataCo in metax.Companies
                                               where (from dataCt in metax.CompanyCompanyTypes
                                                      where dataCt.CompanyTypeId == companyTypeIdToFind
                                                      select dataCt.CompanyId).Contains(dataCo.Id)
                                               select dataCo)
                            );
                }

                
                var query =
                    (IOrderedQueryable<Company>)
                    _compiledQuery(meta, 1);
                var newList = query.ToList();
                retCnt = newList.Count;
            }
            stopWatch.Stop();
            double milliSecondsPerIteration = Convert.ToDouble(stopWatch.ElapsedMilliseconds) / Convert.ToDouble(iterations);
            return string.Format("Return Cnt: {0} LINQ Executions: {1}      Milliseconds Per Iteration: {2}", retCnt, iterations,
                                 String.Format("{0:0.00}", milliSecondsPerIteration));

        }

        public string ProcessLinqQueryNotCompiled()
        {
            if (meta == null)
            {
                meta = new DataClassesDataContext();
            }

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

            int retCnt = 0;
            for (int i = 0; i < iterations; i++)
            {
                const int companyTypeIdToFind = 1;
                var q3 = from dataCo in meta.Companies
                         where (from dataCt in meta.CompanyCompanyTypes
                                where dataCt.CompanyTypeId == companyTypeIdToFind
                                select dataCt.CompanyId).Contains(dataCo.Id)
                         select dataCo;

                var newList = q3.ToList();
                retCnt = newList.Count;
            }
            stopWatch.Stop();
            double milliSecondsPerIteration = Convert.ToDouble(stopWatch.ElapsedMilliseconds)/Convert.ToDouble(iterations);
            return string.Format("Return Cnt: {0} LINQ Executions: {1}      Milliseconds Per Iteration: {2}", retCnt, iterations,
                                 String.Format("{0:0.00}", milliSecondsPerIteration));
        }
    }
}
