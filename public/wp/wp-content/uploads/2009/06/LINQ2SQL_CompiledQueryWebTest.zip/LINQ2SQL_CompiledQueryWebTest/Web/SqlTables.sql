﻿-- SQL Manager for SQL Server 3.3.0.3
-- ---------------------------------------
-- Host      : w500dev
-- Database  : LinqPerf
-- Version   : Microsoft SQL Server  10.0.1600.22


SET NOCOUNT ON
GO

--
-- Definition for table Company : 
--

CREATE TABLE [dbo].[Company] (
  [Id] int IDENTITY(1, 1) NOT NULL,
  [ParentId] int NOT NULL,
  [CompanyStatusId] int NOT NULL,
  [Name] nvarchar(512) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [CompanyLogoURL] nvarchar(512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [CompanyURL] nvarchar(512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [CompanyNotes] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [CreateDate] datetime NOT NULL,
  [ActiveFlag] int NOT NULL
)
ON [PRIMARY]
GO

--
-- Definition for table CompanyCompanyType : 
--

CREATE TABLE [dbo].[CompanyCompanyType] (
  [Id] int IDENTITY(1, 1) NOT NULL,
  [CompanyTypeId] int NOT NULL,
  [CompanyId] int NOT NULL
)
ON [PRIMARY]
GO

--
-- Definition for table CompanyType : 
--

CREATE TABLE [dbo].[CompanyType] (
  [Id] int NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [ActiveFlag] int NOT NULL
)
ON [PRIMARY]
GO

EXEC sp_addextendedproperty 'MS_Description', N'type of company, 
Shipper
Carrier
Broker
OwnerOperator
Customer
service provider', 'schema', 'dbo', 'table', 'CompanyType'
GO

--
-- Definition for table LinqTest : 
--

CREATE TABLE [dbo].[LinqTest] (
  [Id] int IDENTITY(1, 1) NOT NULL,
  [FileName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [FileSize] int NULL,
  [UploadDate] datetime NULL,
  [DownloadDate] datetime NULL,
  [ProcessDate] datetime NULL
)
ON [PRIMARY]
GO

--
-- Definition for indices : 
--

ALTER TABLE [dbo].[Company]
ADD CONSTRAINT [Company_pk] 
PRIMARY KEY CLUSTERED ([Id])
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

ALTER TABLE [dbo].[CompanyCompanyType]
ADD CONSTRAINT [CompanyCompanyType_pk] 
PRIMARY KEY CLUSTERED ([Id])
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX [CompanyCompanyType_uq] ON [dbo].[CompanyCompanyType]
  ([CompanyTypeId], [CompanyId])
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

ALTER TABLE [dbo].[CompanyType]
ADD CONSTRAINT [CompanyType_PK] 
PRIMARY KEY CLUSTERED ([Id])
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [LinqTest_idx] ON [dbo].[LinqTest]
  ([FileSize])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [LinqTest_idx2] ON [dbo].[LinqTest]
  ([UploadDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [LinqTest_idx3] ON [dbo].[LinqTest]
  ([FileName])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [LinqTest_idx4] ON [dbo].[LinqTest]
  ([DownloadDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

ALTER TABLE [dbo].[LinqTest]
ADD CONSTRAINT [LinqTest_PK] 
PRIMARY KEY CLUSTERED ([Id])
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for foreign keys : 
--

ALTER TABLE [dbo].[CompanyCompanyType]
ADD CONSTRAINT [CompanyCompanyType_fk] FOREIGN KEY ([CompanyTypeId]) 
  REFERENCES [dbo].[CompanyType] ([Id]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE [dbo].[CompanyCompanyType]
ADD CONSTRAINT [CompanyCompanyType_fk2] FOREIGN KEY ([CompanyId]) 
  REFERENCES [dbo].[Company] ([Id]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

