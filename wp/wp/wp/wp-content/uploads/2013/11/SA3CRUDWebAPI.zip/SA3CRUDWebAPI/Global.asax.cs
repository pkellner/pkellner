﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net.Http.Formatting;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using SA3CRUDWebAPI.Models;

namespace SA3CRUDWebAPI
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            ConfigureApi(GlobalConfiguration.Configuration);

            Database.SetInitializer<MyContext>(new MyDataContextDbInitializer());

            //using (var db = new MyContext())
            //{
            //    int cnt = db.AttendeePrices.Count();
            //}
        }

        private void ConfigureApi(HttpConfiguration config)
        {
            GlobalConfiguration.Configuration.Formatters.XmlFormatter.SupportedMediaTypes.Clear();
            var index = config.Formatters.IndexOf(config.Formatters.JsonFormatter);
            config.Formatters[index] =
                new JsonMediaTypeFormatter
                {
                    SerializerSettings =
                        new JsonSerializerSettings
                        {
                            ContractResolver =
                                new CamelCasePropertyNamesContractResolver
                                    (),
                            DateTimeZoneHandling = DateTimeZoneHandling.Local,
                            Formatting = Formatting.Indented,
                            NullValueHandling = NullValueHandling.Ignore
                        }
                };
        }
    }

    public class MyDataContextDbInitializer : DropCreateDatabaseIfModelChanges<MyContext>
    {
        protected override void Seed(MyContext context)
        {
            context.AttendeePrices.Add(new AttendeePrice()
            {
                Id = 101,
                FirstName = "Joe",
                LastName = "ThePlumber",
                ChargedAmount = (decimal?) 350.00,
                PaidAmount = (decimal?) 300.00
            });
            context.AttendeePrices.Add(new AttendeePrice()
            {
                Id = 101,
                FirstName = "Tom",
                LastName = "Hulk",
                ChargedAmount = (decimal?)420.00,
                PaidAmount = (decimal?)420.00
            });
            context.AttendeePrices.Add(new AttendeePrice()
            {
                Id = 101,
                FirstName = "Ron",
                LastName = "Reagan",
                ChargedAmount = (decimal?)0.00,
                PaidAmount = (decimal?)0.00
            });
        }
    }

   
}
