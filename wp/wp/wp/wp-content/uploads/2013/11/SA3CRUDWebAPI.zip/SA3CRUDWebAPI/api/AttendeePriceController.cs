﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SA3CRUDWebAPI.Models;

namespace SA3CRUDWebAPI.api
{
    public class AttendeePriceController : ApiController
    {
        // GET api/<controller> amd GET api/<controller>/5  READ
        public async Task<ReturnDataAttendeePrice> Get(int? id=null)
        {
            List<AttendeePrice> attendeesPriceList;
            using (var db = new MyContext())
            {
                attendeesPriceList = id.HasValue
                    ? await db.AttendeePrices.
                    Where(a => a.Id == id.Value).AsNoTracking().ToListAsync()
                    : await db.AttendeePrices.AsNoTracking().
                    ToListAsync();
            }
            return new ReturnDataAttendeePrice()
            {
                Data = attendeesPriceList,
                Message = "",
                Total = attendeesPriceList.Count,
                Success = true
            };
        }

        // POST api/<controller>   INSERT
        public async Task<ReturnDataAttendeePrice> 
            Post(AttendeePrice value)
        {
            using (var db = new MyContext())
            {
                db.AttendeePrices.Add(value);
                await db.SaveChangesAsync();
            }
            return
                new ReturnDataAttendeePrice()
                {
                    Data = new List<AttendeePrice> {value},
                    Message = "",
                    Total = 1,
                    Success = true
                };
        }

        // PUT api/<controller> UPDATE
        public async Task<ReturnDataAttendeePrice> Put(AttendeePrice value)
        {
            using (var db = new MyContext())
            {
                var rec = db.AttendeePrices.
                    FirstOrDefault(a => a.Id == value.Id);
                if (rec != null)
                {
                    rec.FirstName = value.FirstName;
                    rec.LastName = value.LastName;
                    rec.ChargedAmount = value.ChargedAmount;
                    rec.PaidAmount = value.PaidAmount;
                    await db.SaveChangesAsync();
                }
                
            }
            return
                new ReturnDataAttendeePrice
                {
                    Data = new List<AttendeePrice> { value },
                    Message = "",
                    Total = 1,
                    Success = true
                };
        }

        // DELETE api/<controller> DELETE (of course)
        public async Task<ReturnDataAttendeePrice> Delete(AttendeePrice value)
        {
            using (var db = new MyContext())
            {
                var rec = db.AttendeePrices.FirstOrDefault(a => a.Id == value.Id);
                if (rec != null)
                {
                    db.AttendeePrices.Remove(rec);
                    await db.SaveChangesAsync();
                }

            }
            return
                new ReturnDataAttendeePrice
                {
                    Data = new List<AttendeePrice> { value },
                    Message = "",
                    Total = 1,
                    Success = true
                };
        }
    }

    public class ReturnDataAttendeePrice
    {
        public List<AttendeePrice> Data { get; set; }
        public string Message { get; set; }
        public int Total { get; set; }
        public bool Success { get; set; }
    }
}