Ext.define('app.controller.Main', {
    extend: 'Ext.app.Controller'
});
