﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SA3CRUDWebAPI.Models
{
    public class AttendeePrice
    {
        public AttendeePrice() { }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal? ChargedAmount { get; set; }
        public decimal? PaidAmount { get; set; }
    }
}