﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WebApp.WebApiController
{
    public class DateTestRecord
    {

        public string MessageString { get; set; }
        public DateTime DateTimeRightNow { get; set; }
        public DateTime DateTime1PmOctober5Th2013 { get; set; }
    }



    public class DateTestController : ApiController
    {

        public class LogEntry
        {
            public string Details { get; set; }
            public DateTime LogDate { get; set; }
        }

        // POST api/<controller>
        public HttpResponseMessage Get()
        {
            return Request.CreateResponse(HttpStatusCode.OK, new
                {
                    data = new List<DateTestRecord>()
                        {
                            new DateTestRecord
                                {
                                    MessageString = "First Line",
                                    DateTime1PmOctober5Th2013 = new DateTime(2013, 10, 5, 13, 0, 0,DateTimeKind.Local),
                                    DateTimeRightNow = DateTime.Now
                                },
                            new DateTestRecord
                                {
                                    MessageString = "Second Line",
                                    DateTime1PmOctober5Th2013 = new DateTime(2013, 10, 5, 13, 0, 0,DateTimeKind.Utc),
                                    DateTimeRightNow = DateTime.Now
                                },
                            new DateTestRecord
                                {
                                    MessageString = "Third Line",
                                    DateTime1PmOctober5Th2013 = new DateTime(2013, 10, 5, 13, 0, 0,DateTimeKind.Unspecified),
                                    DateTimeRightNow = DateTime.Now
                                },
                                 new DateTestRecord
                                {
                                    MessageString = "Third Line",
                                    DateTime1PmOctober5Th2013 = new DateTime(2013, 10, 5, 13, 0, 0),
                                    DateTimeRightNow = DateTime.Now
                                }
                        },
                    success = true,
                    message = "All Good"
                });
        }
    }
}