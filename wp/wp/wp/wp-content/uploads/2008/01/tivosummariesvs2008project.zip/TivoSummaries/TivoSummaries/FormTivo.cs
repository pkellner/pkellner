﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Net.Security;
using ZedGraph;
using System.Reflection;

namespace TivoSummaries
{
    /// <summary>
    /// Forms Application used for plotting TiVo Data.
    /// </summary>
    public partial class FormTivo : Form
    {
        private const int INT_Constant_Billion = 1000000000;
        private const int INT_Constant_Million = 1000000;
        private ZedGraph.ZedGraphControl zedGraphContentPie;
        private ZedGraph.ZedGraphControl zedGraphHighDefBar;
        
        public FormTivo()
        {
            InitializeComponent();
        }

        private void FormTivo_LoadExtracted()
        {
            zedGraphContentPie = new ZedGraphControl();
            zedGraphHighDefBar = new ZedGraphControl();
            try
            {
                textBoxTivoServiceNumber.Text = Properties.Settings1.Default.TivoService;
                textBoxTivoMediaKey.Text = Properties.Settings1.Default.TivoMediaKey;
            }
            catch (Exception eee)
            {
                throw new ApplicationException(eee.ToString());
            }

            string urlName =
                string.Format(@"https://{0}/TiVoConnect?Command=QueryContainer&Container=%2FNowPlaying&Recurse=Yes",
                    Properties.Settings1.Default.TivoService);

            ServicePointManager.ServerCertificateValidationCallback = TrustAllCertificatePolicy.TrustAllCertificateCallback;
            WebClient webClient = new WebClient();
            webClient.Credentials = new System.Net.NetworkCredential("tivo",
                Properties.Settings1.Default.TivoMediaKey);

            try
            {
                webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(client_OpenReadCompleted);
                webClient.OpenReadAsync(new Uri(urlName));
            }
            catch (Exception ee)
            {
                throw new ApplicationException(ee.ToString());
            }
        }
        private void FormTivo_Load(object sender, EventArgs e)
        {
            FormTivo_LoadExtracted();
        }

      /// <summary>
      /// When XML is ready from TIVO, this is called
      /// </summary>
      /// <param name="sender"></param>
      /// <param name="e"></param>
        private void client_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            if ((e.Error != null) || (e.Cancelled))
            {
                return;
            }

            string xmlString = string.Empty;

            List<KeyValuePair<string, Int64>> spaceList = null;
            using (StreamReader reader = new StreamReader(e.Result))
            {
                xmlString = reader.ReadToEnd();
            };
            spaceList = TivoUtils.GetSpaceByCategory(xmlString);
            GraphContentPie(spaceList);
            GraphBarByHighDef(xmlString);

            ShowTivoListings(xmlString);

            pictureBox1.Visible = false;
        }

        /// <summary>
        /// Generate a simple listing of all shows with space
        /// </summary>
        private void ShowTivoListings(string xmlString)
        {
            List<TivoShowInfo> listTivoShowInfo = TivoUtils.GetTivoShowList(xmlString);
            var query = from tivoList in listTivoShowInfo
                        orderby tivoList.Title
                        select tivoList;

            foreach (var item in query)
            {
                double gigabytes = Convert.ToDouble(Convert.ToDouble(item.NumberBytes / Convert.ToDouble(INT_Constant_Billion)));

                string displayString = String.Format("Size: {0:n} Status: {1} Title: {2}",
                    gigabytes,
                    ShortenContentType(item.ShowType),
                    item.Title);

                listBoxTivoListings.Items.Add(displayString);
            }
            SetSize();
        }

        /// <summary>
        /// do the graph of high def verses standard def
        /// </summary>
        /// <param name="xmlString"></param>
        private void GraphBarByHighDef(string xmlString)
        {
            List<TivoShowInfo> listTivoShowInfo = TivoUtils.GetTivoShowList(xmlString);
            // http://zedgraph.org/wiki/index.php?title=Stacked_Bar_With_Labels_Demo
           
            GraphPane myPane = zedGraphHighDefBar.GraphPane;
            tabPage2.Controls.Add(zedGraphHighDefBar);

            var query = (from tivoList in listTivoShowInfo
                         select new
                         {
                             tivoList.ShowType
                         }).Distinct();

            List<string> showTypeStringList = new List<string>();
            foreach (var val in query)
            {
                //string str = ShortenContentType(val.ShowType);
                showTypeStringList.Add(val.ShowType);
            }

            string[] contentTypeList = new string[showTypeStringList.Count];
            double[] hdSize = new double[showTypeStringList.Count];
            double[] sdSize = new double[showTypeStringList.Count];

            int cnt = 0;
            foreach (string s in showTypeStringList)
            {
                contentTypeList[cnt] = ShortenContentType(s);
                var totalHDList = from tivoList in listTivoShowInfo
                                  where tivoList.ShowType.Equals(s) && tivoList.HighDefinition
                                  select new
                                  {
                                      Bytes = tivoList.NumberBytes
                                  };

                hdSize[cnt] = Convert.ToInt32(Convert.ToInt64(totalHDList.Sum(p => p.Bytes)) / INT_Constant_Billion);
                var totalSDList = from tivoList in listTivoShowInfo
                                  where tivoList.ShowType.Equals(s) && !tivoList.HighDefinition
                                  select new
                                  {
                                      Bytes = tivoList.NumberBytes
                                  };

                sdSize[cnt] = Convert.ToInt32(Convert.ToInt64(totalSDList.Sum(p => p.Bytes)) / INT_Constant_Billion);
                cnt++;
            }

            // Set the pane title
            myPane.Title.Text = "High Def Verses Standard Def Disk Space Usage";
            // Position the legend and fill the background
            myPane.Legend.Position = LegendPos.TopCenter;
            myPane.Legend.Fill.Color = Color.LightCyan;
            // Fill the pane background with a solid color
            myPane.Fill.Color = Color.Cornsilk;
            // Fill the axis background with a solid color
            myPane.Chart.Fill.Type = FillType.Solid;
            myPane.Chart.Fill.Color = Color.LightCyan;
            // Set the bar type to percent stack, which makes the bars sum up to 100%
            myPane.BarSettings.Type = BarType.Stack;

            // Set the X axis title
            myPane.XAxis.Title.Text = "Recorded Content Type";
            myPane.XAxis.Type = AxisType.Text;
            myPane.XAxis.Scale.TextLabels = contentTypeList;
            myPane.XAxis.Scale.FontSpec.Size = 10;
            
            // Set the Y axis properties
            myPane.YAxis.Title.IsVisible = true;
            //myPane.YAxis.Scale.Max = 120;
            myPane.YAxis.MinorTic.IsOpposite = false;
            myPane.YAxis.MajorTic.IsOpposite = false;
            myPane.YAxis.Title.Text = "Gigabytes";

            // Add a gradient blue bar
            BarItem bar = myPane.AddBar("High Definition", null, hdSize, Color.RoyalBlue);
            bar.Bar.Fill = new Fill(Color.RoyalBlue, Color.White, Color.RoyalBlue);

            // Add a gradient yellow bar
            bar = myPane.AddBar("Standard Definition", null, sdSize, Color.Yellow);
            bar.Bar.Fill = new Fill(Color.Yellow, Color.White, Color.Yellow);

            // Calculate the Axis Scale Ranges
            zedGraphHighDefBar.AxisChange();
            SetSize();
        }

        private void GraphContentPie(List<KeyValuePair<string, Int64>> spaceList)
        {
            Color[] colors = {Color.Navy,Color.Purple,Color.LimeGreen,Color.SandyBrown,
                                 Color.Red,Color.Blue,Color.Green,Color.Yellow};
            

            GraphPane myPane = zedGraphContentPie.GraphPane;
            tabPage1.Controls.Add(zedGraphContentPie);


            myPane.Title.Text = "Tivo Space by Content Type";
            myPane.Title.FontSpec.IsItalic = true;
            myPane.Title.FontSpec.Size = 24f;
            myPane.Title.FontSpec.Family = "Times New Roman";

            // Fill the pane background with a color gradient
            myPane.Fill = new Fill(Color.White, Color.Goldenrod, 45.0f);
            // No fill for the chart background
            myPane.Chart.Fill.Type = FillType.None;

            // Set the legend to an arbitrary location
            myPane.Legend.Position = LegendPos.Float;
            myPane.Legend.Location = new Location(0.95f, 0.15f, CoordType.PaneFraction,
                           AlignH.Right, AlignV.Top);
            myPane.Legend.FontSpec.Size = 10f;
            myPane.Legend.IsHStack = false;

            Int64 total = 0;
            foreach (KeyValuePair<string, Int64> kvp in spaceList)
            {
                total += kvp.Value;
            }

            int cnt = 0;
            foreach (KeyValuePair<string, Int64> kvp in spaceList)
            {
                Int64 Mbs = kvp.Value / INT_Constant_Million;
                string contentType = kvp.Key;
                string labelName = ShortenContentType(contentType);
                PieItem segment1 = myPane.AddPieSlice(Mbs, colors[cnt], Color.White, 45f, 0,
                    string.Format("{0} {1}%", labelName, (Mbs * 100000000) / total));
                cnt++;
            }

            // Sum up the pie values                                                               
            CurveList curves = myPane.CurveList;
            
            // Make a text label to highlight the total value
            TextObj text = new TextObj(String.Format("{0} Gigabytes Recorded.",total/INT_Constant_Billion),
                           0.18F, 0.40F, CoordType.PaneFraction);
            text.Location.AlignH = AlignH.Center;
            text.Location.AlignV = AlignV.Top;
            text.FontSpec.Border.IsVisible = false;
            text.FontSpec.Fill = new Fill(Color.White, Color.FromArgb(255, 100, 100), 45F);
            text.FontSpec.StringAlignment = StringAlignment.Center;
            myPane.GraphObjList.Add(text);

            // Create a drop shadow for the total value text item
            TextObj text2 = new TextObj(text);
            text2.FontSpec.Fill = new Fill(Color.Black);
            text2.Location.X += 0.008f;
            text2.Location.Y += 0.01f;
            myPane.GraphObjList.Add(text2);

            // Calculate the Axis Scale Ranges
            zedGraphContentPie.AxisChange();
            SetSize();
        }

        /// <summary>
        /// make the content type more readable
        /// </summary>
        /// <param name="contentType"></param>
        /// <returns></returns>
        private string ShortenContentType(string contentType)
        {
            string str = contentType.Substring(15).Replace("-recording", string.Empty).Replace("-", " ");
            
            // Uppercase each word 
            StringBuilder sb = new StringBuilder();
            if (str.Length > 1)
            {
                sb.Append(str.Substring(0, 1).ToUpper());
                for (int i = 1; i < str.Length; i++)
                {
                    if (str.Substring(i - 1, 1).Equals(" "))
                    {
                        sb.Append(str.Substring(i, 1).ToUpper());
                    }
                    else
                    {
                        sb.Append(str.Substring(i, 1));
                    }
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// change the size of all tabs
        /// </summary>
        private void SetSize()
        {
            tabControl1.Width = this.Width;
            tabControl1.Top = 25;
            tabControl1.Height = this.Height - 25;

            zedGraphContentPie.Width = tabPage1.Width - 35;
            zedGraphContentPie.Height = tabPage1.Height - 50;
            zedGraphContentPie.Top = 10;
            zedGraphContentPie.Left = 10;

            zedGraphHighDefBar.Width = tabPage2.Width - 35;
            zedGraphHighDefBar.Height = tabPage2.Height - 50;
            zedGraphHighDefBar.Top = 10;
            zedGraphHighDefBar.Left = 10;

            listBoxTivoListings.Width = tabPage3.Width - 35;
            listBoxTivoListings.Height = tabPage3.Height - 50;
            listBoxTivoListings.Top = 10;
            listBoxTivoListings.Left = 10;
        }

        /// <summary>
        /// call setsize for tab pages when form changes size
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormTivo_Resize(object sender, EventArgs e)
        {
            SetSize();
        }

        /// <summary>
        /// Save Settings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            Properties.Settings1.Default.TivoService = textBoxTivoServiceNumber.Text;
            Properties.Settings1.Default.TivoMediaKey = textBoxTivoMediaKey.Text;
            Properties.Settings1.Default.Save();
            this.Controls.Remove(zedGraphContentPie);
            pictureBox1.Visible = true;
            FormTivo_LoadExtracted();
        }

        /// <summary>
        /// When person switches between tabs, change size of all internal tabs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetSize();
        }
    }

    /// <summary>
    /// always trust my Tivo
    /// </summary>
    public class TrustAllCertificatePolicy : System.Net.ICertificatePolicy
    {
        public static bool TrustAllCertificateCallback(object sender,
            X509Certificate cert, X509Chain chain, SslPolicyErrors errors)
        {
            return true;
        }

        public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem)
        {
            return true;
        }
    }


}
