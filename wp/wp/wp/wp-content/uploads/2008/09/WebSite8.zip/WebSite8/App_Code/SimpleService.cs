﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;

[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class SimpleService
{
    // Add [WebGet] attribute to use HTTP GET
    [OperationContract]
    public List<CityState> RetrieveAll()
    {
        var listData = new List<CityState>();
        listData.Add(new CityState {city = "Hartsdale", state = "NY"});
        listData.Add(new CityState {city = "San Jose", state = "CA"});
        listData.Add(new CityState {city = "Chicago", state = "IL"});
        return listData;
    }
}


[DataContract]
public class CityState
{
    [DataMember]
    public string city { get; set; }

    [DataMember]
    public string state { get; set; }
}