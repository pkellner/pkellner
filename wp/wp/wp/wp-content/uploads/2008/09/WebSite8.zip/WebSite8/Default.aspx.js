﻿function pageLoad() {
    SimpleService.RetrieveAll(OnRetrieveLoadData);
}

function OnRetrieveLoadData(dataList) {

    // javascript kindly donated from x-format on this thread:
    // http://forums.asp.net/p/1319775/2620025.aspx#2620025
    var divObj = document.getElementById('myTable');

    var city = 'The City';
    var state = 'The State';

    var tableStart = 
       '<table cellspacing="5" cellpadding="0" border="1">' + 
       '<tbody><tr><th>City</th><th>State</th></tr>';
    var tableContent = '';
    var tableEnd = '</tbody></table>';
    for (var i = 0; i < dataList.length; i++) {
        tableContent += '<tr><td>' + dataList[i].city 
        + '</td><td>' + dataList[i].state + '</td></tr>';
    }
    divObj.innerHTML = tableStart + tableContent + tableEnd;
}





