﻿(function() {
    "use strict";

    WinJS.Namespace.define("svcc.Functions", {
        loadData: function (nav, searchString) {
            var searchStringLower = "";
            if (searchString && searchString.length > 0) {
                searchStringLower = searchString.toLowerCase();
            }
                    
            var sampleGroups = [];
            var sampleItems = [];

            var imageParams =
                "?width=160&height=160&mode=pad&scale=both&anchor=middlecenter&format=png";
            var urlString = svcc.Constants.baseUrl +
                "GeneralHandlers/Tracks.ashx?codecampyear=6";
            var xhrOptions = { url: urlString };
            var that = this;
            WinJS.xhr(xhrOptions).done(function(myXhr) {
                var result = JSON.parse(myXhr.response);
                for (var i = 0; i < result.rows.length; i++) {
                    var trackId = result.rows[i].TrackId;
                    var trackName = result.rows[i].TrackName;
                    //var trackDescription = result.rows[i].TrackDescription; 
                    var sessions = result.rows[i].Sessions;
                    sampleGroups.push({
                        key: trackId,
                        title: trackName,
                        subtitle: '',
                        backgroundImage: svcc.Constants.baseUrl +
                            "trackimage/" + trackId + ".jpg" + imageParams,
                        sessions: sessions
                    });
                }

                for (var j = 0; j < sampleGroups.length; j++) {
                    var sessionsForTrack = sampleGroups[j].sessions;
                    for (var k = 0; k < sessionsForTrack.length; k++) {

                        // if no searchString present, then foundMatch is true
                        var foundMatch = false;
                        if (searchString && searchString.length > 0) {
                            var titleLower = sessionsForTrack[k].Title.toLowerCase();
                            if (titleLower.indexOf(searchStringLower) != -1) {
                                foundMatch = true;
                            } else {
                                var presenterNameLower = sessionsForTrack[k].PresenterName.toLowerCase();
                                if (presenterNameLower.indexOf(searchStringLower) != -1) {
                                    foundMatch = true;
                                }
                            }
                        } else {
                            foundMatch = true;
                        }
                        if (foundMatch) {
                            sampleItems.push({
                                group: sampleGroups[j],
                                title: sessionsForTrack[k].Title,
                                subtitle: sessionsForTrack[k].PresenterName,
                                description: sessionsForTrack[k].Description,
                                content: sessionsForTrack[k].Description,
                                backgroundImage: svcc.Constants.baseUrl + "attendeeimage/" + sessionsForTrack[k].Attendeesid + ".jpg" + imageParams
                            });
                        }
                    }
                }


                var list = new WinJS.Binding.List();
                var groupedItems = list.createGrouped(
                    function groupKeySelector(item) { return item.group.key; },
                    function groupDataSelector(item) { return item.group; }
                );

                for (var ii = 0; ii < sampleItems.length; ii++) {
                    list.push(sampleItems[ii]);
                }

                WinJS.Namespace.define("Data", {
                    items: groupedItems,
                    groups: groupedItems.groups,
                    getItemReference: getItemReference,
                    getItemsFromGroup: getItemsFromGroup,
                    resolveGroupReference: resolveGroupReference,
                    resolveItemReference: resolveItemReference
                });

                // Get a reference for an item, using the group key and item title as a
                // unique reference to the item that can be easily serialized.

                function getItemReference(item) {
                    return [item.group.key, item.title];
                }

                // This function returns a WinJS.Binding.List containing only the items
                // that belong to the provided group.

                function getItemsFromGroup(group) {
                    return list.createFiltered(function(item) { return item.group.key === group.key; });
                }

                // Get the unique group corresponding to the provided group key.

                function resolveGroupReference(key) {
                    for (var i = 0; i < groupedItems.groups.length; i++) {
                        if (groupedItems.groups.getAt(i).key === key) {
                            return groupedItems.groups.getAt(i);
                        }
                    }
                }

                // Get a unique item from the provided string array, which should contain a
                // group key and an item title.

                function resolveItemReference(reference) {
                    for (var i = 0; i < groupedItems.length; i++) {
                        var item = groupedItems.getAt(i);
                        if (item.group.key === reference[0] && item.title === reference[1]) {
                            return item;
                        }
                    }
                }
                
                if (nav.location) {
                    nav.history.current.initialPlaceholder = true;
                    return nav.navigate(nav.location, nav.state);
                } else {
                    return nav.navigate(Application.navigator.home);
                }
            });
                    
        }
        // end loadData() function
            

    });




})();
