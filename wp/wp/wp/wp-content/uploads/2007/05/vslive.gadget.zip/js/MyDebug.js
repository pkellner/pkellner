﻿    // Debug Stuff
    // to add debugging, create a file called debug.txt
    // in the directory of the gadget, then
    // call:
    // debug("whatever you want output");
    //
    var oShell = new ActiveXObject("WScript.Shell");
    var oFSO = new ActiveXObject("Scripting.FileSystemObject");
    var gadgetPath = System.Gadget.path;

    var bDebug;
    try{
        bDebug = oFSO.FileExists(gadgetPath+"\\debug.txt");
	    if (bDebug)
		    var debugLogFile = oFSO.OpenTextFile(gadgetPath+"\\debug.txt", 2);
    } catch(err) {bDebug = false; 
    debugLog("Open debug.txt error"+err.name+" - "+err.message)}
    
    //log a debug entry
    function debugLog(str) {
	    try{
    	   
		    System.Debug.outputString(str);
		    if (bDebug)
		    {
		        now = new Date();
			    debugLogFile.WriteLine(str + ": Log Date: " + now);
		    }
	    } catch(err) {}
    }
    // end of debug stuff

