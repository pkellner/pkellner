﻿Type.registerNamespace('InterfaceTraining');
InterfaceTraining.AlbumService=function() {
InterfaceTraining.AlbumService.initializeBase(this);
this._timeout = 0;
this._userContext = null;
this._succeeded = null;
this._failed = null;
}
InterfaceTraining.AlbumService.prototype={
AlbumSearch:function(artistText,page,succeededCallback, failedCallback, userContext) {
return this._invoke(InterfaceTraining.AlbumService.get_path(), 'AlbumSearch',false,{artistText:artistText,page:page},succeededCallback,failedCallback,userContext); },
GetCodeCampDateByYear:function(year,succeededCallback, failedCallback, userContext) {
return this._invoke(InterfaceTraining.AlbumService.get_path(), 'GetCodeCampDateByYear',false,{year:year},succeededCallback,failedCallback,userContext); },
GetGadgetTitle:function(year,succeededCallback, failedCallback, userContext) {
return this._invoke(InterfaceTraining.AlbumService.get_path(), 'GetGadgetTitle',false,{year:year},succeededCallback,failedCallback,userContext); },
GetlistItemsHTMLFromRSS:function(numberToShow,succeededCallback, failedCallback, userContext) {
return this._invoke(InterfaceTraining.AlbumService.get_path(), 'GetlistItemsHTMLFromRSS',false,{numberToShow:numberToShow},succeededCallback,failedCallback,userContext); }}
InterfaceTraining.AlbumService.registerClass('InterfaceTraining.AlbumService',Sys.Net.WebServiceProxy);
InterfaceTraining.AlbumService._staticInstance = new InterfaceTraining.AlbumService();
InterfaceTraining.AlbumService.set_path = function(value) { InterfaceTraining.AlbumService._staticInstance.set_path(value); }
InterfaceTraining.AlbumService.get_path = function() { return InterfaceTraining.AlbumService._staticInstance.get_path(); }
InterfaceTraining.AlbumService.set_timeout = function(value) { InterfaceTraining.AlbumService._staticInstance.set_timeout(value); }
InterfaceTraining.AlbumService.get_timeout = function() { return InterfaceTraining.AlbumService._staticInstance.get_timeout(); }
InterfaceTraining.AlbumService.set_defaultUserContext = function(value) { InterfaceTraining.AlbumService._staticInstance.set_defaultUserContext(value); }
InterfaceTraining.AlbumService.get_defaultUserContext = function() { return InterfaceTraining.AlbumService._staticInstance.get_defaultUserContext(); }
InterfaceTraining.AlbumService.set_defaultSucceededCallback = function(value) { InterfaceTraining.AlbumService._staticInstance.set_defaultSucceededCallback(value); }
InterfaceTraining.AlbumService.get_defaultSucceededCallback = function() { return InterfaceTraining.AlbumService._staticInstance.get_defaultSucceededCallback(); }
InterfaceTraining.AlbumService.set_defaultFailedCallback = function(value) { InterfaceTraining.AlbumService._staticInstance.set_defaultFailedCallback(value); }
InterfaceTraining.AlbumService.get_defaultFailedCallback = function() { return InterfaceTraining.AlbumService._staticInstance.get_defaultFailedCallback(); }
InterfaceTraining.AlbumService.set_path("http://localhost/CodeCampSVFall/WebServices/AlbumService.asmx");
InterfaceTraining.AlbumService.AlbumSearch= function(artistText,page,onSuccess,onFailed,userContext) {InterfaceTraining.AlbumService._staticInstance.AlbumSearch(artistText,page,onSuccess,onFailed,userContext); }
InterfaceTraining.AlbumService.GetCodeCampDateByYear= function(year,onSuccess,onFailed,userContext) {InterfaceTraining.AlbumService._staticInstance.GetCodeCampDateByYear(year,onSuccess,onFailed,userContext); }
InterfaceTraining.AlbumService.GetGadgetTitle= function(year,onSuccess,onFailed,userContext) {InterfaceTraining.AlbumService._staticInstance.GetGadgetTitle(year,onSuccess,onFailed,userContext); }
InterfaceTraining.AlbumService.GetlistItemsHTMLFromRSS= function(numberToShow,onSuccess,onFailed,userContext) {InterfaceTraining.AlbumService._staticInstance.GetlistItemsHTMLFromRSS(numberToShow,onSuccess,onFailed,userContext); }
var gtc = Sys.Net.WebServiceProxy._generateTypedConstructor;
Type.registerNamespace('Model');
if (typeof(Model.SearchResult) === 'undefined') {
Model.SearchResult=gtc("Model.SearchResult");
Model.SearchResult.registerClass('Model.SearchResult');
}



