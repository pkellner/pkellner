using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using System.IO;


/// <summary>
/// Summary description for ODS
/// </summary>
/// 
[DataObject(true)]  // This attribute allows the ObjectDataSource wizard to see this class
public class ODS //: ISerializable
{

    private List<BusinessObject> listBusinessObject = new List<BusinessObject>();
    private string fileNameToSerializeTo;

    public ODS()
    {
        fileNameToSerializeTo = "c:\\temp\\ODS1.txt";
        System.Xml.Serialization.XmlSerializer xmls = new System.Xml.Serialization.XmlSerializer(new List<BusinessObject>().GetType());
        StreamReader sr = new StreamReader(fileNameToSerializeTo);
        listBusinessObject = (List<BusinessObject>)xmls.Deserialize(sr);
        sr.Close();
    }


    [DataObjectMethod(DataObjectMethodType.Select, true)]
    public List<BusinessObject> GetMembers()
    {

        listBusinessObject.Sort(
            new Comparison<BusinessObject>(
                delegate(BusinessObject lhs, BusinessObject rhs)
                {
                    return lhs.Name.CompareTo(rhs.Name);
                }));
        return listBusinessObject;

        


        //List<BusinessObject> lbo = new List<BusinessObject>();
        //lbo.Add(new BusinessObject(1001,"Peter Kellner","peter@peterkellner.net"));
        //lbo.Add(new BusinessObject(1002,"John Smith","John@Microsoft.com"));
        //lbo.Add(new BusinessObject(1003,"David Nadler","David@IBM.com"));
        //return lbo;

    }

    [DataObjectMethod(DataObjectMethodType.Select, false)]
    public List<BusinessObject> GetMembers(int Id)
    {

        List<BusinessObject> listBusinessObjectFiltered = new List<BusinessObject>();
        foreach (BusinessObject currentBusinessObject in listBusinessObject)
        {
            if (currentBusinessObject.Id == Id)
            {
                listBusinessObjectFiltered.Add(currentBusinessObject);
            }
        }
        return listBusinessObjectFiltered;
    }


    [DataObjectMethod(DataObjectMethodType.Insert, true)]
    public void Insert(int Id, string Name, string Email)
    {
        bool foundDuplicate = false;
        int currentMax = 0;
        foreach (BusinessObject currentBusinessObject in listBusinessObject)
        {
            if (currentMax < currentBusinessObject.Id)
            {
                currentMax = currentBusinessObject.Id;
            }

            if (currentBusinessObject.Id == Id)
            {
                foundDuplicate = true;
            }
        }
        if (foundDuplicate == true || Id < 0)
        {
            listBusinessObject.Add(new BusinessObject(currentMax + 1, Name, Email));
        }
        else
        {
            listBusinessObject.Add(new BusinessObject(Id, Name, Email));
        }
        SerializeList(fileNameToSerializeTo);

    }

    [DataObjectMethod(DataObjectMethodType.Delete, true)]
    public void Delete(int Id)
    {
        BusinessObject foundBusinessObject = null;
        foreach (BusinessObject currentBusinessObject in listBusinessObject)
        {
            if (currentBusinessObject.Id == Id)
            {
                foundBusinessObject = currentBusinessObject;
            }
        }
        if (foundBusinessObject != null)
        {
            listBusinessObject.Remove(foundBusinessObject);
        }
        SerializeList(fileNameToSerializeTo);
    }


    [DataObjectMethod(DataObjectMethodType.Update, true)]
    public void Update(int Id, string Name, string Email)
    {
        BusinessObject foundBusinessObject = null;
        foreach (BusinessObject currentBusinessObject in listBusinessObject)
        {
            if (currentBusinessObject.Id == Id)
            {
                foundBusinessObject = currentBusinessObject;
            }
        }
        if (foundBusinessObject != null)
        {
            listBusinessObject.Remove(foundBusinessObject);
            listBusinessObject.Add(new BusinessObject(Id, Name, Email));
        }
        SerializeList(fileNameToSerializeTo);
    }

    private void SerializeList(string fileName)
    {
        System.Xml.Serialization.XmlSerializer xmls = new System.Xml.Serialization.XmlSerializer(new List<BusinessObject>().GetType());
        StreamWriter sw = new StreamWriter(fileName);
        xmls.Serialize(sw, listBusinessObject);
        sw.Close();
    }

}



