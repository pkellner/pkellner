using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using PeterKellner.Utils;

public partial class DefaultCustomTemplate : System.Web.UI.Page
{

    private string captchaConfirmed = string.Empty;

    private void Page_PreRenderComplete(object sender, EventArgs e)
    {
        LabelVerified.Text = this.captchaConfirmed;
    }

    protected void CaptchaUltimateControl1_Verified(object sender, EventArgs e)
    {
        CaptchaUltimateControl captchaUltimateControl = (CaptchaUltimateControl)sender;
        TextBox textBoxAuthor = (TextBox)captchaUltimateControl.FindControl("TextBoxAuthor");
        this.captchaConfirmed = "CAPTCHA Confirmed Event Called with Author " +
            textBoxAuthor.Text + ".";

    }
    protected void CaptchaUltimateControl1_Verifying(object sender, VerifyingEventArgs e)
    {
        e.ForceVerify = true;
        this.captchaConfirmed = string.Empty;
    }
}
