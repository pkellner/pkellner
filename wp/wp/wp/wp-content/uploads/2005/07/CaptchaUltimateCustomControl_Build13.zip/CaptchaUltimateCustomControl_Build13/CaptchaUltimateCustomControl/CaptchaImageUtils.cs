/*
Copyright � 2006, Peter Kellner
All rights reserved.
http://peterkellner.net

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

- Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

- Neither Peter Kellner, nor the names of its
contributors may be used to endorse or promote products
derived from this software without specific prior written 
permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Web;

namespace PeterKellner.Utils
{
    /// <summary>
    /// Utility class used for passing parameters between HttpHandler and Custom
    /// server control
    /// </summary>
    public class CaptchaParams
    {
        public CaptchaParams()
        {
        }

        public CaptchaParams(
            string plainValue,
            string encryptedValue,
            int heightCaptchaPixels,
            int widthCaptchaPixels,
            int captchaType,
            string fontFamilyString)
        {
            this.plainValue = plainValue;
            this.encryptedValue = encryptedValue;
            this.heightCaptchaPixels = heightCaptchaPixels;
            this.widthCaptchaPixels = widthCaptchaPixels;
            this.captchaType = captchaType;
            this.fontFamilyString = fontFamilyString;
        }

        private string plainValue;

        public string PlainValue
        {
            get { return plainValue; }
            set { plainValue = value; }
        }

        private string encryptedValue;

        public string EncryptedValue
        {
            get { return encryptedValue; }
            set { encryptedValue = value; }
        }

        private int heightCaptchaPixels;

        public int HeightCaptchaPixels
        {
            get { return heightCaptchaPixels; }
            set { heightCaptchaPixels = value; }
        }

        private int widthCaptchaPixels;

        public int WidthCaptchaPixels
        {
            get { return widthCaptchaPixels; }
            set { widthCaptchaPixels = value; }
        }

        private int captchaType;

        public int CaptchaType
        {
            get { return captchaType; }
            set { captchaType = value; }
        }

        private string fontFamilyString;

        public string FontFamilyString
        {
            get { return fontFamilyString; }
            set { fontFamilyString = value; }
        }
    }

    /// <summary>
    /// Utility Functions for Captcha Custom Control
    /// </summary>
    public class CaptchaImageUtils
    {
        /// <summary>
        /// Get an array representing the Captcha as a bitmap
        /// Currently only supports two types of Captcha
        /// </summary>
        /// <param name="cp"></param>
        /// <returns></returns>
        public static byte[] GetImageCaptcha(CaptchaParams cp)
        {
            byte[] bitMapArray = null;
            if (cp.CaptchaType == 1)
            {
                bitMapArray = GenerateImageType1(cp);
            }
            else if (cp.CaptchaType == 2)
            {
                bitMapArray = GenerateImageType2(cp);
            }
            else
            {
                throw new ApplicationException("CaptchaType Must Be 1 or 2");
            }
            return bitMapArray;
        }

        /// <summary>
        /// Inspired and copied from an article on CodeProject at
        /// http://www.codeproject.com/aspnet/CaptchaImage.asp
        /// Written by BrainJar. (Mike Hall I think)
        /// Later, this code was modified by wumpus1 (Jeff Atwood)
        /// and can be found at this location:
        /// http://www.codeproject.com/aspnet/CaptchaControl.asp
        /// </summary>
        /// <param name="cp"></param>
        /// <returns></returns>
        private static byte[] GenerateImageType1(CaptchaParams cp)
        {
            float _noise = 30F;
            float _skewing = 4.5F;
            Random random = new Random();

            // Create a new 32-bit bitmap image.
            Bitmap bitmap = new Bitmap(cp.WidthCaptchaPixels, cp.HeightCaptchaPixels, PixelFormat.Format32bppArgb);
            // Create a graphics object for drawing.
            Graphics g = Graphics.FromImage(bitmap);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = new Rectangle(0, 0, cp.WidthCaptchaPixels, cp.HeightCaptchaPixels);
            // Fill in the background.
            HatchBrush hatchBrush = new HatchBrush(HatchStyle.SmallConfetti, Color.LightGray, Color.White);
            g.FillRectangle(hatchBrush, rect);
            // Set up the text font.
            SizeF size;
            float fontSize = rect.Height - 4;
            Font font = null;
            // Adjust the font size until the text fits within the image.
            do
            {
                fontSize--;
                font = new Font(cp.FontFamilyString, fontSize, FontStyle.Bold);
                size = g.MeasureString(cp.PlainValue, font);
            } while (size.Width > rect.Width);
            // Set up the text format.
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center;
            // Create a path using the text and warp it randomly.
            GraphicsPath path = new GraphicsPath();
            path.AddString(cp.PlainValue, font.FontFamily, (int)font.Style, font.Size, rect, format);
            float v = _skewing;
            PointF[] points = {
                                  new PointF(random.Next(rect.Width)/v, random.Next(rect.Height)/v),
                                  new PointF(rect.Width - random.Next(rect.Width)/v, random.Next(rect.Height)/v),
                                  new PointF(random.Next(rect.Width)/v, rect.Height - random.Next(rect.Height)/v),
                                  new PointF(rect.Width - random.Next(rect.Width)/v,
                                             rect.Height - random.Next(rect.Height)/v)
                              };
            Matrix matrix = new Matrix();
            matrix.Translate(0F, 0F);
            path.Warp(points, rect, matrix, WarpMode.Perspective, 0F);
            // Draw the text.
            hatchBrush = new HatchBrush(HatchStyle.LargeConfetti, Color.LightGray, Color.DarkGray);
            g.FillPath(hatchBrush, path);
            // Add some random noise.
            int m = Math.Max(rect.Width, rect.Height);
            for (int i = 0; i < (int)(rect.Width * rect.Height / _noise); i++)
            {
                int x = random.Next(rect.Width);
                int y = random.Next(rect.Height);
                int w = random.Next(m / 50);
                int h = random.Next(m / 50);
                g.FillEllipse(hatchBrush, x, y, w, h);
            }
            // Clean up.
            font.Dispose();
            hatchBrush.Dispose();
            g.Dispose();
            // Set the image.

            MemoryStream stream = new MemoryStream();
            bitmap.Save(stream, ImageFormat.Bmp);
            bitmap.Dispose();
            return stream.GetBuffer();
        }

        /// <summary>
        /// This image type was borrowed from the Blog Starter Kit
        /// Provided by Shanku Niyogi, Product Unit Manger of the UI
        /// Framework at Microsoft
        /// at this URL:  http://www.shankun.com/Post.aspx?postID=13
        /// </summary>
        /// <param name="cp"></param>
        /// <returns></returns>
        private static byte[] GenerateImageType2(CaptchaParams cp)
        {
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            Byte[] rand = new Byte[200];
            rng.GetBytes(rand);
            int i = 0;

            Bitmap bmp = new Bitmap(cp.WidthCaptchaPixels, cp.HeightCaptchaPixels, PixelFormat.Format24bppRgb);
            Bitmap cloneBmp = null;
            Graphics g = null;
            LinearGradientBrush backgroundBrush = null;
            LinearGradientBrush textBrush = null;
            SolidBrush[] circleBrush = new SolidBrush[3];
            Font font = null;
            GraphicsPath path = null;

            try
            {
                g = Graphics.FromImage(bmp);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                Rectangle r = new Rectangle(0, 0, cp.WidthCaptchaPixels, cp.HeightCaptchaPixels);
                backgroundBrush = new LinearGradientBrush(
                    new RectangleF(0, 0, cp.WidthCaptchaPixels, cp.HeightCaptchaPixels),
                    Color.FromArgb(rand[i++] / 2 + 128, rand[i++] / 2 + 128, 255),
                    Color.FromArgb(255, rand[i++] / 2 + 128, rand[i++] / 2 + 128),
                    rand[i++] * 360 / 256);
                g.FillRectangle(backgroundBrush, r);

                for (int br = 0; br < circleBrush.Length; br++)
                {
                    circleBrush[br] = new SolidBrush(Color.FromArgb(128, rand[i++], rand[i++], rand[i++]));
                }

                for (int circle = 0; circle < 30; circle++)
                {
                    int radius = rand[i++] % 10;
                    g.FillEllipse(circleBrush[circle % 2],
                                  rand[i++] * cp.WidthCaptchaPixels / 256,
                                  rand[i++] * cp.HeightCaptchaPixels / 256,
                                  radius, radius);
                }

                font = new Font(cp.FontFamilyString, cp.HeightCaptchaPixels / 2, FontStyle.Bold);
                StringFormat format = new StringFormat();
                format.Alignment = StringAlignment.Center;
                format.LineAlignment = StringAlignment.Center;

                path = new GraphicsPath();
                path.AddString(cp.PlainValue, font.FontFamily,
                               (int)font.Style, font.Size, r, format);

                textBrush = new LinearGradientBrush(
                    new RectangleF(0, 0, cp.WidthCaptchaPixels, cp.HeightCaptchaPixels),
                    Color.FromArgb(rand[i] % 128, rand[i] % 128, rand[i++] % 128),
                    Color.FromArgb(rand[i] % 128, rand[i] % 128, rand[i++] % 128),
                    rand[i++] * 360 / 256);
                g.FillPath(textBrush, path);


                cloneBmp = (Bitmap)bmp.Clone();

                int distortionSeed = rand[i++];
                double distortion = distortionSeed > 128 ? 5 + (distortionSeed - 128) % 5 : -5 - distortionSeed % 5;
                for (int y = 0; y < cp.HeightCaptchaPixels; y++)
                {
                    for (int x = 0; x < cp.WidthCaptchaPixels; x++)
                    {
                        // Adds a simple wave
                        int newX = (int)(x + (distortion * Math.Sin(Math.PI * y / 96.0)));
                        int newY = (int)(y + (distortion * Math.Cos(Math.PI * x / 64.0)));
                        if (newX < 0 || newX >= cp.WidthCaptchaPixels)
                        {
                            newX = 0;
                        }
                        if (newY < 0 || newY >= cp.HeightCaptchaPixels)
                        {
                            newY = 0;
                        }
                        bmp.SetPixel(x, y, cloneBmp.GetPixel(newX, newY));
                    }
                }

                MemoryStream stream = new MemoryStream();
                bmp.Save(stream, ImageFormat.Bmp);
                return stream.GetBuffer();
            }
            finally
            {
                if (backgroundBrush != null)
                {
                    backgroundBrush.Dispose();
                }
                if (textBrush != null)
                {
                    textBrush.Dispose();
                }
                for (int br = 0; br < circleBrush.Length; br++)
                {
                    if (circleBrush[br] != null)
                    {
                        circleBrush[br].Dispose();
                    }
                }
                if (font != null)
                {
                    font.Dispose();
                }
                if (path != null)
                {
                    path.Dispose();
                }
                if (g != null)
                {
                    g.Dispose();
                }
                if (bmp != null)
                {
                    bmp.Dispose();
                }
                if (cloneBmp != null)
                {
                    cloneBmp.Dispose();
                }
            }
        }
    }

    /// <summary>
    /// referenced from web.config for displaying an image
    /// </summary>
    public class CaptchaTypeHandler : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            if (context.Request.QueryString["id"] == null)
            {
                // likely, this is in design mode and we want to just show the
                // default image for type 2.
                Assembly assembly = Assembly.GetExecutingAssembly();
                string s = "CaptchaUltimateCustomControl.Images.CaptchaType2.gif";
                Stream imgStream = assembly.GetManifestResourceStream(s);
                byte[] ba = new byte[imgStream.Length];
                imgStream.Read(ba, 0, Convert.ToInt32(imgStream.Length));
                context.Response.BinaryWrite(ba);
            }
            else
            {
                // this is live
                string encryptedValue = context.Request.QueryString["id"];
                if (!string.IsNullOrEmpty(encryptedValue))
                {
                    string cacheKey = "CAPTCHA-" + encryptedValue;
                    CaptchaParams cp = (CaptchaParams)HttpContext.Current.Cache[cacheKey];
                    byte[] ba = CaptchaImageUtils.GetImageCaptcha(cp);
                    context.Response.BinaryWrite(ba);
                    context.Response.End();
                }
            }
        }

        public bool IsReusable
        {
            get { return false; }
        }
    }
}