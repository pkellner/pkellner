Demo.Tree = Ext.extend(Ext.tree.TreePanel, {
  initComponent : function() {
    Ext.apply(this, {
      title : 'West Region',
      width : 200,
      margins : '5 0 5 5',
      cmargins : '5 5 5 5',
      collapsible : true
    });

    Demo.Tree.superclass.initComponent.call(this);

    var root = new Ext.tree.TreeNode({
      text : 'Root Node',
      expanded : true
    });
    this.setRootNode(root);

    root.appendChild(new Ext.tree.TreeNode({text: 'Item 1'}));
    root.appendChild(new Ext.tree.TreeNode({text: 'Item 2'}));
    root.appendChild(new Ext.tree.TreeNode({text: 'Item 3'}));

    this.on('click', this.handleNodeClick, this);
  },

  handleNodeClick : function(n) {
    Ext.Msg.prompt('Edit Paragraph',
        '<b>Current value:</b><br />' + n.text, function(btn, text) {
          if (text != '' && btn == 'ok') {
            n.setText(text);
            Ext.fly(n.getUI().getTextEl()).highlight();
          }
        }, this, true);
  }
});
Ext.reg('demotree', Demo.Tree);