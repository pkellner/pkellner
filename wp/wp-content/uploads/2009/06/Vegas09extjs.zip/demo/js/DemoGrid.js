Demo.Grid = Ext.extend(Ext.grid.GridPanel, {
  initComponent : function() {
    Ext.applyIf(this, {
      title : 'Company Grid',
      columns : [           
        new Ext.grid.RowNumberer(),
        {header: "Company Test", width: 40, sortable: true, dataIndex: 'company'},
        {header: "Price", width: 20, sortable: true, renderer: Ext.util.Format.usMoney, dataIndex: 'price'},
        {header: "Change", width: 20, sortable: true, dataIndex: 'change'},
        {header: "% Change", width: 20, sortable: true, dataIndex: 'pctChange'},
        {header: "Last Updated", width: 20, sortable: true, renderer: Ext.util.Format.dateRenderer('m/d/Y'), dataIndex: 'lastChange'}
      ],
      viewConfig : {
        forceFit : true
      }
    });

    this.getView().getRowClass = function(rec, idx, rowParams, store) {
      if (rec.data.pctChange < 0) {
        return 'negative';
      } else if (rec.data.pctChange > 1) {
        return 'positive';
      }
    }
    Demo.Grid.superclass.initComponent.call(this);
  }
});

Ext.reg('demogrid', Demo.Grid);