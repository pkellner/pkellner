﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MembershipUtilities;
using System.Web.Security;

public partial class CreateSampleData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Random r = new Random();
        int cnt = 0;
        List<DataObjectUsers> listDataObjectUsers = LoadSampleUserData();
        foreach (var list in listDataObjectUsers)
        {
           
            MembershipUserAndProfileODS mODS = new MembershipUserAndProfileODS();

            if (Membership.GetUser(list.Username) == null)
            {
                
                mODS.Insert(list.Username,list.Isapproved, list.Comment,
                            DateTime.Now, DateTime.Now.AddDays(Convert.ToDouble(r.Next(1, 2000)*-1)), list.Email,
                            DateTime.Now.AddDays(Convert.ToDouble(r.Next(1, 40)*-1)),
                            "", false, DateTime.Now.AddMinutes(Convert.ToDouble(r.Next(1, 10000)*-1)),
                            false, "dog", DateTime.Now, "pass@word", "dog1",  list.FirstName, list.LastName, "", "", "",
                            "",
                            "");
                cnt++;
            }
        }
        Label1.Text = cnt.ToString() + " processed";
        Button1.Enabled = false;


    }


    private List<DataObjectUsers> LoadSampleUserData()
    {
        List<DataObjectUsers> listUsers = new List<DataObjectUsers>();
        // http://www.ruf.rice.edu/~pound/english-s

        string lastnames =
            "Adams Adamson Adler Akers Akin Aleman Alexander Allen Allison Allwood Anderson Andreou Anthony Appelbaum Applegate Arbore Arenson Armold Arntzen Askew Athanas Atkinson Ausman Austin Averitt Avila-Sakar Badders Baer Baggerly Bailliet Baird Baker Ball Ballentine Ballew Banks ";
        lastnames +=
            "Baptist-Nguyen Barbee Barber Barchas Barcio Bardsley Barkauskas Barnes Barnett Barnwell Barrera Barreto Barroso Barrow Bart Barton Bass Bates Bavinger Baxter Bazaldua Becker Beeghly Belforte Bellamy Bellavance Beltran Belusar Bennett Benoit Bensley Berger Berggren Bergman Berry ";
        lastnames +=
            "pippero pistole pitoni piu poco poi polacco pomodori popolazione porta portati portato porto possibile posso posta potere potrebbe poveretto pozione precipita precipitevolissimevolmente precisare predichi preferito premere prende preso primavera primo principe principessa problema problematico problemi profondo programma pronto protettori provaci provato provetta provetti pudore pulirsi pulisce punto pure puttana quadrato quando quando quanta quarantadue quarantaquattro quarto quattordici quattro quello quello questo questo questoggi quindici quinto quota ragazzi ragioniere ramazzotti reazione regole rendano rendita repubblicano respira resto rettangolo ribelle ricordo riempiamo rigatoni rione ripetizioni riposa riposa riposano riposare ";

        string firstnames =
            "Aaron Adam Adrian Alan Alejandro Alex Allen Andrew Andy Anthony Art Arthur Barry Bart Ben Benjamin Bill Bobby Brad Bradley Brendan Brett Brian Bruce Bryan Carlos Chad Charles Chris Christopher Chuck Clay Corey Craig Dan Daniel Darren Dave David Dean Dennis Denny Derek Don Doug Duane Edward Eric Eugene Evan Frank Fred Gary Gene George Gordon Greg Harry Henry Hunter Ivan Jack James Jamie Jason Jay Jeff Jeffrey Jeremy Jim Joe Joel John Jonathan Joseph Justin Keith Ken Kevin Larry Logan Marc Mark Matt Matthew Michael Mike Nat Nathan Patrick Paul Perry Peter Philip Phillip Randy Raymond Ricardo Richard Rick Rob Robert Rod Roger Ross Ruben Russell Ryan Sam Scot Scott Sean Shaun Stephen Steve Steven Stewart Stuart Ted Thomas Tim Toby Todd Tom Troy Victor Wade Walter Wayne William";

        char[] sep = new char[1];
        sep[0] = ' ';
        string[] lastnamelist = lastnames.Split(sep);
        string[] firstnamelist = firstnames.Split(sep);

        const int numUsersToProcess = 120;
        //int numUsersToProcess = 5;
        for (int i = 0; i < numUsersToProcess; i++)
        {
            string str = lastnamelist[i];
            if (!string.IsNullOrEmpty(str) && str.Substring(0, 1).Equals(str.Substring(0, 1).ToLower()))
            {
                lastnamelist[i] = str.Substring(0, 1).ToUpper() + str.Substring(1);
            }
        }

        Random r = new Random();

      

        for (int i = 0; i < numUsersToProcess; i++)
        {
            //string longname = firstnamelist[i] + " " + lastnamelist[i];
            string email = firstnamelist[i] + "@" + lastnamelist[i] + ".net";
            string userName = firstnamelist[i].Substring(0, 1).ToLower() +
                              lastnamelist[i].Substring(1).ToLower();
            DateTime dt = DateTime.Now;

            int daysBack = r.Next(800, 8000) * -1;
            DateTime birthDate = DateTime.Now.AddDays(Convert.ToDouble(daysBack));

            DataObjectUsers dou = new DataObjectUsers(
                Guid.NewGuid(),
                userName,
                birthDate,
                "applicationName",
                email,
                "comment",
                "password",
                "passwordQuestion",
                "passwordAnswer",
                true,
                dt, dt, dt,
                false,
                false,
                dt,
                0,
                dt,
                0,
                dt,
                dt,
                firstnamelist[i],
                lastnamelist[i],
                i
                );

            listUsers.Add(dou);
        }
        return listUsers;
    }

    public class DataObjectUsers
    {
        public DataObjectUsers()
        {
        }

        public DataObjectUsers(Guid pkid, string username,DateTime birthDate, string applicationname, string email, string comment,
                               string password, string passwordquestion, string passwordanswer, bool isapproved,
                               DateTime lastactivitydate, DateTime lastlogindate, DateTime creationdate, bool isonline,
                               bool islockedout, DateTime lastlockedoutdate, int failedpasswordattemptcount,
                               DateTime failedpasswordattemptwindowstart, int failedpasswordanswerattemptcount,
                               DateTime failedpasswordanswerattemptwindowstart, DateTime lastpasswordchangeddate,string firstName,string lastName, int id)
        {
            this.pkid = pkid;
            this.username = username;
            this.BirthDate = birthDate;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.applicationname = applicationname;
            this.email = email;
            this.comment = comment;
            this.password = password;
            this.passwordquestion = passwordquestion;
            this.passwordanswer = passwordanswer;
            this.isapproved = isapproved;
            this.lastactivitydate = lastactivitydate;
            this.lastlogindate = lastlogindate;
            this.creationdate = creationdate;
            this.isonline = isonline;
            this.islockedout = islockedout;
            this.lastlockedoutdate = lastlockedoutdate;
            this.failedpasswordattemptcount = failedpasswordattemptcount;
            this.failedpasswordattemptwindowstart = failedpasswordattemptwindowstart;
            this.failedpasswordanswerattemptcount = failedpasswordanswerattemptcount;
            this.failedpasswordanswerattemptwindowstart = failedpasswordanswerattemptwindowstart;
            this.lastpasswordchangeddate = lastpasswordchangeddate;
            this.id = id;
        }

        public string FirstName
        {
            set;
            get;
        }

        public string LastName
        {
            set;
            get;
        }

        public DateTime BirthDate { get; set; }

        private Guid pkid;
        //
        public Guid Pkid
        {
            get { return pkid; }
            set { pkid = value; }
        }

        private string username;
        //
        public string Username
        {
            get { return username; }
            set { username = value; }
        }


        private string applicationname;
        //
        public string Applicationname
        {
            get { return applicationname; }
            set { applicationname = value; }
        }

        private string email;
        //
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        private string comment;
        //
        public string Comment
        {
            get { return comment; }
            set { comment = value; }
        }

        private string password;
        //
        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        private string passwordquestion;
        //
        public string Passwordquestion
        {
            get { return passwordquestion; }
            set { passwordquestion = value; }
        }

        private string passwordanswer;
        //
        public string Passwordanswer
        {
            get { return passwordanswer; }
            set { passwordanswer = value; }
        }

        private bool isapproved;
        //
        public bool Isapproved
        {
            get { return isapproved; }
            set { isapproved = value; }
        }

        private DateTime lastactivitydate;
        //
        public DateTime Lastactivitydate
        {
            get { return lastactivitydate; }
            set { lastactivitydate = value; }
        }

        private DateTime lastlogindate;
        //
        public DateTime Lastlogindate
        {
            get { return lastlogindate; }
            set { lastlogindate = value; }
        }

        private DateTime creationdate;
        //
        public DateTime Creationdate
        {
            get { return creationdate; }
            set { creationdate = value; }
        }

        private bool isonline;
        //
        public bool Isonline
        {
            get { return isonline; }
            set { isonline = value; }
        }

        private bool islockedout;
        //
        public bool Islockedout
        {
            get { return islockedout; }
            set { islockedout = value; }
        }

        private DateTime lastlockedoutdate;
        //
        public DateTime Lastlockedoutdate
        {
            get { return lastlockedoutdate; }
            set { lastlockedoutdate = value; }
        }

        private int failedpasswordattemptcount;
        //
        public int Failedpasswordattemptcount
        {
            get { return failedpasswordattemptcount; }
            set { failedpasswordattemptcount = value; }
        }

        private DateTime failedpasswordattemptwindowstart;
        //
        public DateTime Failedpasswordattemptwindowstart
        {
            get { return failedpasswordattemptwindowstart; }
            set { failedpasswordattemptwindowstart = value; }
        }

        private int failedpasswordanswerattemptcount;
        //
        public int Failedpasswordanswerattemptcount
        {
            get { return failedpasswordanswerattemptcount; }
            set { failedpasswordanswerattemptcount = value; }
        }

        private DateTime failedpasswordanswerattemptwindowstart;
        //
        public DateTime Failedpasswordanswerattemptwindowstart
        {
            get { return failedpasswordanswerattemptwindowstart; }
            set { failedpasswordanswerattemptwindowstart = value; }
        }

        private DateTime lastpasswordchangeddate;
        //
        public DateTime Lastpasswordchangeddate
        {
            get { return lastpasswordchangeddate; }
            set { lastpasswordchangeddate = value; }
        }

        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
    }


}
