﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ext.Direct;


namespace App_Code
{
    /// <summary>
    /// Summary description for UserService
    /// </summary>
    [DirectAction]
    public class UserService
    {
        [DirectMethod]
        public object Hello()
        {
            return new { success = true, data = "Hello" };
        }

        [DirectMethod]
        public object Get(
            //object param //having this extra parameter will kill the current ExtJs 
            )
        {
            var results = (new UserManager()).Get(new UserQuery());
            return new { success = true, data = results };
        }

        [DirectMethod]
        public object Create(string data)
        {
            var results = ConvertToUsers(data);
            UserManager manager = new UserManager();
            manager.Create(ref results);
            if (results.Count == 1)
            {
                return results[0];
            }
            else
            {
                return results;
            }
        }

        [DirectMethod]
        public object Save(string Username, string data)
        {
            var results = ConvertToUsers(data);
            UserManager manager = new UserManager();
            manager.Update(ref results);
            if (results.Count == 1)
            {
                return results[0];
            }
            else
            {
                return results;
            }
        }

        [DirectMethod]
        public bool Destroy(string ProviderKey)
        {
            List<UserResult> results = new List<UserResult> { new UserResult { ProviderUserKey = ProviderKey.Trim('"') } };
            UserManager manager = new UserManager();
            manager.Delete(ref results);
            return true;
        }

        private List<UserResult> ConvertToUsers(string data)
        {
            //change the json string to be an array. 
            //otherwise it is not consistant between single item and multiple items
            if (data.StartsWith("{"))
            {
                data = string.Format("[{0}]", data);
            }
            var results = data.FromJson<List<UserResult>>();
            return results;
        }
    }
}