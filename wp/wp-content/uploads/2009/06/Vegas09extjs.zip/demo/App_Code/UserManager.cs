﻿using System;
using System.Collections.Generic;
using System.Linq;
using MembershipUtilities;
using System.Web.Security;

namespace App_Code
{
    public class UserManager
    {
        public List<UserResult> Get(UserQuery query)
        {
            var returnUsers = new List<UserResult>();

            var membershipUserAndProfileOds = new MembershipUserAndProfileODS();
            List<MembershipUserWrapperForMP> users =
                membershipUserAndProfileOds.GetMembers();

            query.TotalCount = users.Count;

            foreach (var myUser in users)
            {
                returnUsers.Add(new UserResult()
                                    {
                                        Username = myUser.UserName,
                                        FirstName = myUser.FirstName,
                                        LastName = myUser.LastName,
                                        AddressLine = myUser.AddressLine,
                                        City = myUser.City,
                                        State = myUser.State,
                                        ZipCode = myUser.ZipCode,
                                        Comment = myUser.Comment,
                                        CreationDate = myUser.CreationDate,
                                        Email = myUser.Email,
                                        IsApproved = myUser.IsApproved,
                                        IsLockedOut = myUser.IsLockedOut,
                                        ProviderUserKey = myUser.ProviderUserKey.ToString(),
                                        UserImageUrl = myUser.UserImageUrl
                                    });
            }

            IEnumerable<UserResult> results = from data in returnUsers
                                              orderby data.Username
                                              select new UserResult
                                                         {
                                                             Username = data.Username,
                                                             FirstName = data.FirstName,
                                                             LastName = data.LastName,
                                                             AddressLine = data.AddressLine,
                                                             City = data.City,
                                                             State = data.State,
                                                             ZipCode = data.ZipCode,
                                                             Comment = data.Comment,
                                                             CreationDate = data.CreationDate,
                                                             Email = data.Email,
                                                             IsApproved = data.IsApproved,
                                                             IsLockedOut = data.IsLockedOut,
                                                             ProviderUserKey = data.ProviderUserKey.ToString(),
                                                             UserImageUrl = data.UserImageUrl
                                                         };

            if (query.Username != null)
            {
                results = results.Where(data => query.Username.Equals(data.Username));
            }
            if (query.ProviderUserKey != null)
            {
                results = results.Where(data => query.ProviderUserKey.Equals(data.ProviderUserKey));
            }
            if (!String.IsNullOrEmpty(query.FilterName))
            {
                results = results.Where(theUser => theUser.LastName.ToLower().Contains(query.FilterName.ToLower()) ||
                                                   theUser.FirstName.ToLower().Contains(query.FilterName.ToLower()));
            }

            if (query.Start != null && query.Start > 0)
            {
                results = results.Skip(query.Start.Value);
            }
            if (query.Limit != null && query.Limit > 0)
            {
                results = results.Take(query.Limit.Value);
            }

            return results.ToList();
        }

        public void Create(ref List<UserResult> result)
        {
            UserResult r = result[0];
            var membershipUserAndProfileOds = new MembershipUserAndProfileODS();
            membershipUserAndProfileOds.Insert(r.Username, r.IsApproved ?? true, r.Comment ?? "", DateTime.Now, r.CreationDate ?? DateTime.Now,
                                               r.Email ?? "e@e.com", DateTime.Now, "", false, DateTime.Now, true, r.PasswordQuestion ?? "dfdf", DateTime.Now, r.Password ?? "Pass@word!",
                                               r.PasswordAnswer ?? "ccc", r.FirstName ?? "",
                                               r.LastName ?? "", r.AddressLine ?? "", r.City ?? "", r.State ?? "", r.ZipCode ?? "", r.UserImageUrl ?? "");

            // Membership.CreateUser(r.Username,"password",r.Email,)

            MembershipUser mu = Membership.GetUser(r.Username);

            r.CreationDate = mu.CreationDate;

            r.ProviderUserKey = mu.ProviderUserKey.ToString();

        }

        public void Update(ref List<UserResult> result)
        {
            List<UserResult> oldResult = result;
            result = new List<UserResult>();
            var membershipUserAndProfileOds = new MembershipUserAndProfileODS();
            foreach (var u in oldResult)
            {
                var oldUser = Get(new UserQuery { ProviderUserKey = u.ProviderUserKey }).FirstOrDefault();
                if (oldUser != null)
                {
                    membershipUserAndProfileOds.Update(oldUser.Username,
                        u.Email ?? oldUser.Email,
                        u.IsLockedOut ?? oldUser.IsLockedOut ?? false,
                        u.IsApproved ?? oldUser.IsApproved ?? false,
                        u.Comment ?? oldUser.Comment,
                        DateTime.Now, DateTime.Now,
                        u.FirstName ?? oldUser.FirstName,
                        u.LastName ?? oldUser.LastName,
                        u.AddressLine ?? oldUser.AddressLine,
                        u.City ?? oldUser.City,
                        u.State ?? oldUser.State,
                        u.ZipCode ?? oldUser.ZipCode,
                        u.UserImageUrl ?? oldUser.UserImageUrl);
                }
                var newUser = Get(new UserQuery { ProviderUserKey = u.ProviderUserKey }).FirstOrDefault();
                result.Add(newUser);
            }
        }


        public void Delete(ref List<UserResult> result)
        {
            List<UserResult> oldResult = result;
            result = new List<UserResult>();
            var membershipUserAndProfileOds = new MembershipUserAndProfileODS();
            foreach (var u in oldResult)
            {
                var oldUser = Get(new UserQuery { ProviderUserKey = u.ProviderUserKey }).FirstOrDefault();
                if (oldUser != null)
                {
                    membershipUserAndProfileOds.Delete(oldUser.Username);
                }
            }
        }
    }
}