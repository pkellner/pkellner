﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App_Code
{
    public class UserQuery
    {
        public string ProviderUserKey { get; set; }
        public string EmailAddress { get; set; }
        public string Username { get; set; }
        public string FilterName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        // params for paging
        public int? Start { get; set; }
        public int? Limit { set; get; }
        public int? TotalCount { get; set; }
    }
}