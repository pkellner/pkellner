/*
 * Ext JS Library 3.0 RC1.1
 * Copyright(c) 2006-2009, Ext JS, LLC.
 * licensing@extjs.com
 * 
 * http://extjs.com/license
 */

if(Ext.app.ContactForm) {
    Ext.apply(Ext.app.ContactForm.prototype, {
        formTitle: 'Contact Informatie (Dutch)',
        firstName: 'Voornaam',
        lastName: 'Achternaam',
        surnamePrefix: 'Tussenvoegsel',
        company: 'Bedrijf',
        state: 'Provincie',
        stateEmptyText: 'Kies een provincie...',
        email: 'E-mail',
        birth: 'Geb. Datum',
        save: 'Opslaan',
        cancel: 'Annuleren'
    });
}