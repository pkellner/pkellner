<?php
$API = array(
	'TestAction'=>array(
	    'methods'=>array(
	        'doEcho'=>array(
	            'len'=>1
	        ),
	        'multiply'=>array(
	            'len'=>1
	        )
	    )
	)
);
?>