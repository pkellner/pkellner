Ext.namespace('ASPNETProfile');

ASPNETProfile.memberProxy = new Ext.data.HttpProxy({
    prettyUrls: false,
    
    
    api: {
        read: 'Users.ashx',
        create: 'Create.ashx',
        update: 'Save.ashx',
        destroy: 'Delete.ashx'
    }
});

ASPNETProfile.memberRecord = Ext.data.Record.create(
        [
            {name: 'ProviderUserKey'},
            {name: 'Username',allowBlank: false },
            {name: 'FirstName',allowBlank: false },
            {name: 'LastName', allowBlank: false },
            {name: 'UserImageUrl' },
            {name: 'Email', allowBlank: false },
            {name: 'IsApproved', type: 'bool' },
            {name: 'CreationDate', type: 'date', dateFormat: 'n/j/Y' },
            {name: 'Comment' }
        ]);

ASPNETProfile.memberReader = new Ext.data.JsonReader(
{
    totalProperty: 'total',   //   the property which contains the total dataset size (optional)
    idProperty: 'ProviderUserKey',
    root: 'rows',
    successProperty: 'success'
},
        ASPNETProfile.memberRecord
        );

ASPNETProfile.memberWriter = new Ext.data.JsonWriter({
    returnJson: true,
    writeAllFields: true
});

ASPNETProfile.memberStore = new Ext.data.Store({
    id: 'user',
    root: 'records',
    proxy: ASPNETProfile.memberProxy,
    reader: ASPNETProfile.memberReader,
    writer: ASPNETProfile.memberWriter,
    paramsAsHash: true,
    batchSave: false,
    autoLoad: false

});