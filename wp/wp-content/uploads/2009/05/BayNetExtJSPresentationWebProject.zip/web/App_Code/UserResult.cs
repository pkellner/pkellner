﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App_Code
{
    public class UserResult
    {
        public string Username { set; get; }
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public string AddressLine { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { set; get; }
        public string UserImageUrl { get; set; }
        public string Password { set; get; }
        public string Comment { get; set; }
        public string Email { get; set; }
        public bool? IsApproved { get; set; }
        public bool? IsLockedOut { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? LastOnLineDate { get; set; }
        public string PasswordQuestion { get; set; }
        public string PasswordAnswer { get; set; }
        public string ProviderUserKey { get; set; }
    }
}