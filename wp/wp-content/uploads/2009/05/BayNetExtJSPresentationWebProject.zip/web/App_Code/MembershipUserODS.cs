//  Copyright  2006, Peter Kellner, 73rd Street Associates
//  All rights reserved.
//  http://PeterKellner.net
//
//
//  - Neither Peter Kellner, nor the names of its
//  contributors may be used to endorse or promote products
//  derived from this software without specific prior written
//  permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
//  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES INCLUDING,
//  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
//  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
//  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
//  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Profile;
using System.Web.Security;

namespace MembershipUtilities
{
    [DataObject(true)]
    public class MembershipUserAndProfileODS
    {
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
        public void Insert(string userName, bool isApproved,
                           string comment, DateTime lastLockoutDate, DateTime creationDate,
                           string email, DateTime lastActivityDate, string providerName, bool isLockedOut,
                           DateTime lastLoginDate, bool isOnline, string passwordQuestion,
                           DateTime lastPasswordChangedDate, string password, string passwordAnswer
                           , string firstName, string lastName, string addressLine, string city, string state,
                           string zipCode, string userImageUrl
            )
        {
            MembershipCreateStatus status;
            Membership.CreateUser(userName, password, email, passwordQuestion, passwordAnswer, isApproved, out status);

            if (status != MembershipCreateStatus.Success)
            {
                throw new ApplicationException(status.ToString());
            }

            MembershipUser mu = Membership.GetUser(userName);
            mu.Comment = comment;
            Membership.UpdateUser(mu);
            var pc = (ProfileCommon) ProfileBase.Create(mu.UserName, true);
            pc.FirstName = firstName;
            pc.LastName = lastName;
            pc.AddressLine = addressLine;
            pc.City = city;
            pc.State = state;
            pc.ZipCode = zipCode;
            pc.UserImageUrl = userImageUrl;
            pc.Save();
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public  void Delete(string UserName)
        {
            Membership.DeleteUser(UserName, true);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public static void Delete(string UserName, string original_UserName)
        {
            string userNameForDelete = String.IsNullOrEmpty(UserName) ? original_UserName : UserName;
            Membership.DeleteUser(userNameForDelete, true);
        }

        [DataObjectMethod(DataObjectMethodType.Update, false)]
        public void Update(string UserName, string original_UserName, string email, bool isLockedOut,
                           bool isApproved, string comment, DateTime lastActivityDate, DateTime lastLoginDate
                           , string firstName, string lastName, string addressLine, string city, string state,
                           string zipCode, string userImageUrl
            )
        {
            string userNameForUpdate = String.IsNullOrEmpty(UserName) ? original_UserName : UserName;
            Update(userNameForUpdate, email, isLockedOut, isApproved, comment, lastActivityDate, lastLoginDate
                   , firstName, lastName, addressLine, city, state, zipCode, userImageUrl
                );
        }


        [DataObjectMethod(DataObjectMethodType.Update, true)]
        public void Update(string userName, string email, bool isLockedOut,
                           bool isApproved, string comment, DateTime lastActivityDate, DateTime lastLoginDate
                           , string firstName, string lastName, string addressLine, string city, string state,
                           string zipCode, string userImageUrl
            )
        {
            bool dirtyFlagMu = false;

            MembershipUser mu = Membership.GetUser(userName);

            var pc = (ProfileCommon) ProfileBase.Create(mu.UserName, true);
            pc.FirstName = firstName;
            pc.LastName = lastName;
            pc.AddressLine = addressLine;
            pc.City = city;
            pc.State = state;
            pc.ZipCode = zipCode;
            pc.UserImageUrl = userImageUrl;
            pc.Save();

            if (mu.IsLockedOut && !isLockedOut)
            {
                mu.UnlockUser();
            }

            if (string.IsNullOrEmpty(mu.Comment) || mu.Comment.CompareTo(comment) != 0)
            {
                dirtyFlagMu = true;
                mu.Comment = comment;
            }

            if (string.IsNullOrEmpty(mu.Email) || mu.Email.CompareTo(email) != 0)
            {
                dirtyFlagMu = true;
                mu.Email = email;
            }

            if (mu.IsApproved != isApproved)
            {
                dirtyFlagMu = true;
                mu.IsApproved = isApproved;
            }

            if (dirtyFlagMu == true)
            {
                Membership.UpdateUser(mu);
            }
        }


        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public List<MembershipUserWrapperForMP> GetMembers()
        {
            return GetMembers(true, true, null, null);
        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public List<MembershipUserWrapperForMP> GetMembers(string sortData)
        {
            return GetMembers(true, true, null, sortData);
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public List<MembershipUserWrapperForMP> GetMembers(bool approvalStatus, string sortData)
        {
            if (approvalStatus == true)
            {
                return GetMembers(true, false, null, sortData);
            }
            else
            {
                return GetMembers(false, true, null, sortData);
            }
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public List<MembershipUserWrapperForMP> GetMembers(bool returnAllApprovedUsers, bool returnAllNotApprovedUsers,
                                                           string usernameToFind, string sortData)
        {
            var memberList = new List<MembershipUserWrapperForMP>();

            if (usernameToFind != null)
            {
                MembershipUser mu = Membership.GetUser(usernameToFind);
                if (mu != null)
                {
                    var md = new MembershipUserWrapperForMP(mu);
                    var pc = (ProfileCommon) ProfileBase.Create(mu.UserName, true);
                    md.FirstName = pc.FirstName;
                    md.LastName = pc.LastName;
                    md.AddressLine = pc.AddressLine;
                    md.City = pc.City;
                    md.State = pc.State;
                    md.ZipCode = pc.ZipCode;
                    md.UserImageUrl = pc.UserImageUrl;
                    memberList.Add(md);
                }
            }
            else
            {
                MembershipUserCollection muc = Membership.GetAllUsers();
                foreach (MembershipUser mu in muc)
                {
                    if ((returnAllApprovedUsers == true && mu.IsApproved == true) ||
                        (returnAllNotApprovedUsers == true && mu.IsApproved == false))
                    {
                        var md = new MembershipUserWrapperForMP(mu);
                        var pc = (ProfileCommon) ProfileBase.Create(mu.UserName, true);
                        md.FirstName = pc.FirstName;
                        md.LastName = pc.LastName;
                        md.AddressLine = pc.AddressLine;
                        md.City = pc.City;
                        md.State = pc.State;
                        md.ZipCode = pc.ZipCode;
                        md.UserImageUrl = pc.UserImageUrl;
                        memberList.Add(md);
                    }
                }

                if (sortData == null)
                {
                    sortData = "UserName";
                }
                if (sortData.Length == 0)
                {
                    sortData = "UserName";
                }

                string sortDataBase = sortData; // init and assume there is not DESC appended to sortData
                string descString = " DESC";
                if (sortData.EndsWith(descString))
                {
                    sortDataBase = sortData.Substring(0, sortData.Length - descString.Length);
                }

                Comparison<MembershipUserWrapperForMP> comparison = null;

                switch (sortDataBase)
                {
                    case "FirstName":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs)
                                {
                                    if (lhs.FirstName == null || rhs.FirstName == null)
                                    {
                                        return 1;
                                    }
                                    else
                                    {
                                        return lhs.FirstName.CompareTo(rhs.FirstName);
                                    }
                                }
                            );
                        break;
                    case "LastName":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs)
                                {
                                    if (lhs.LastName == null || rhs.LastName == null)
                                    {
                                        return 1;
                                    }
                                    else
                                    {
                                        return lhs.LastName.CompareTo(rhs.LastName);
                                    }
                                }
                            );
                        break;
                    case "AddressLine":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs)
                                {
                                    if (lhs.AddressLine == null || rhs.AddressLine == null)
                                    {
                                        return 1;
                                    }
                                    else
                                    {
                                        return lhs.AddressLine.CompareTo(rhs.AddressLine);
                                    }
                                }
                            );
                        break;
                    case "City":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs)
                                {
                                    if (lhs.City == null || rhs.City == null)
                                    {
                                        return 1;
                                    }
                                    else
                                    {
                                        return lhs.City.CompareTo(rhs.City);
                                    }
                                }
                            );
                        break;
                    case "State":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs)
                                {
                                    if (lhs.State == null || rhs.State == null)
                                    {
                                        return 1;
                                    }
                                    else
                                    {
                                        return lhs.State.CompareTo(rhs.State);
                                    }
                                }
                            );
                        break;
                    case "ZipCode":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs)
                                {
                                    if (lhs.ZipCode == null || rhs.ZipCode == null)
                                    {
                                        return 1;
                                    }
                                    else
                                    {
                                        return lhs.ZipCode.CompareTo(rhs.ZipCode);
                                    }
                                }
                            );
                        break;
                    case "UserImageUrl":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs)
                                {
                                    if (lhs.UserImageUrl == null || rhs.UserImageUrl == null)
                                    {
                                        return 1;
                                    }
                                    else
                                    {
                                        return lhs.UserImageUrl.CompareTo(rhs.UserImageUrl);
                                    }
                                }
                            );
                        break;
                    case "UserName":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs) { return lhs.UserName.CompareTo(rhs.UserName); }
                            );
                        break;
                    case "Email":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs)
                                {
                                    if (lhs.Email == null || rhs.Email == null)
                                    {
                                        return 0;
                                    }
                                    else
                                    {
                                        return lhs.Email.CompareTo(rhs.Email);
                                    }
                                }
                            );
                        break;
                    case "CreationDate":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs) { return lhs.CreationDate.CompareTo(rhs.CreationDate); }
                            );
                        break;
                    case "IsApproved":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs) { return lhs.IsApproved.CompareTo(rhs.IsApproved); }
                            );
                        break;
                    case "IsOnline":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs) { return lhs.IsOnline.CompareTo(rhs.IsOnline); }
                            );
                        break;
                    case "LastLoginDate":
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs) { return lhs.LastLoginDate.CompareTo(rhs.LastLoginDate); }
                            );
                        break;
                    default:
                        comparison = new Comparison<MembershipUserWrapperForMP>(
                            delegate(MembershipUserWrapperForMP lhs, MembershipUserWrapperForMP rhs) { return lhs.UserName.CompareTo(rhs.UserName); }
                            );
                        break;
                }

                if (sortData.EndsWith("DESC"))
                {
                    memberList.Sort(comparison);
                    memberList.Reverse();
                }
                else
                {
                    memberList.Sort(comparison);
                }
            }

            return memberList;
        }
    }

    public class MembershipUserWrapperForMP : MembershipUser
    {
        private string addressLine;
        private string city;
        private string firstName;
        private string lastName;
        private string state;
        private string userImageUrl;
        private string zipCode;

        public MembershipUserWrapperForMP(MembershipUser mu)
            : base(mu.ProviderName, mu.UserName, mu.ProviderUserKey, mu.Email, mu.PasswordQuestion,
                   mu.Comment, mu.IsApproved, mu.IsLockedOut, mu.CreationDate, mu.LastLoginDate, mu.LastActivityDate,
                   mu.LastPasswordChangedDate, mu.LastLockoutDate)
        {
        }

        public MembershipUserWrapperForMP()
        {
        }

        public MembershipUserWrapperForMP(string firstName, string lastName, string addressLine, string city,
                                          string state, string zipCode, string userImageUrl)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.addressLine = addressLine;
            this.city = city;
            this.state = state;
            this.zipCode = zipCode;
            this.userImageUrl = userImageUrl;
        }

        [DataObjectField(true)]
        public override string UserName
        {
            get { return base.UserName; }
        }

        [DataObjectField(false, false, false)]
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        [DataObjectField(false, false, false)]
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        [DataObjectField(false, false, false)]
        public string AddressLine
        {
            get { return addressLine; }
            set { addressLine = value; }
        }

        [DataObjectField(false, false, false)]
        public string City
        {
            get { return city; }
            set { city = value; }
        }

        [DataObjectField(false, false, false)]
        public string State
        {
            get { return state; }
            set { state = value; }
        }

        [DataObjectField(false, false, false)]
        public string ZipCode
        {
            get { return zipCode; }
            set { zipCode = value; }
        }

        [DataObjectField(false, false, false)]
        public string UserImageUrl
        {
            get { return userImageUrl; }
            set { userImageUrl = value; }
        }
    }


    [DataObject(true)] // This attribute allows the
    public class RoleDataObjectForMP
    {
        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public static List<RoleDataForMP> GetRoles()
        {
            return GetRoles(null, false);
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public static List<RoleDataForMP> GetRoles(string userName, bool showOnlyAssignedRolls)
        {
            var roleList = new List<RoleDataForMP>();

            string[] roleListStr = Roles.GetAllRoles();
            foreach (string roleName in roleListStr)
            {
                bool userInRole = false;
                if (userName != null)
                {
                    userInRole = Roles.IsUserInRole(userName, roleName);
                }

                if (showOnlyAssignedRolls == false || userInRole == true)
                {
                    string[] usersInRole = Roles.GetUsersInRole(roleName);
                    var rd = new RoleDataForMP();
                    rd.RoleName = roleName;
                    rd.UserName = userName;
                    rd.UserInRole = userInRole;
                    rd.NumberOfUsersInRole = usersInRole.Length;
                    roleList.Add(rd);
                }
            }

            return roleList;
        }

        [DataObjectMethod(DataObjectMethodType.Insert, true)]
        public static void Insert(string roleName)
        {
            if (Roles.RoleExists(roleName) == false)
            {
                Roles.CreateRole(roleName);
            }
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public static void Delete(string roleName)
        {
            MembershipUserCollection muc = Membership.GetAllUsers();
            var allUserNames = new string[1];

            foreach (MembershipUser mu in muc)
            {
                if (Roles.IsUserInRole(mu.UserName, roleName) == true)
                {
                    allUserNames[0] = mu.UserName;
                    Roles.RemoveUsersFromRole(allUserNames, roleName);
                }
            }
            Roles.DeleteRole(roleName);
        }
    }

    public class RoleDataForMP
    {
        private int numberOfUsersInRole;

        private string roleName;
        private bool userInRole;

        private string userName;

        public int NumberOfUsersInRole
        {
            get { return numberOfUsersInRole; }
            set { numberOfUsersInRole = value; }
        }

        [DataObjectField(true)]
        public string RoleName
        {
            get { return roleName; }
            set { roleName = value; }
        }

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

        public bool UserInRole
        {
            get { return userInRole; }
            set { userInRole = value; }
        }
    }
}