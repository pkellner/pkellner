Demo.DataView = Ext.extend(Ext.DataView, {
  initComponent : function() {
    Ext.applyIf(this, {
      tpl : new Ext.XTemplate('<tpl for=".">',
          '<div class="company-wrap" id="{company}">',
          '<div class="company-name">{company}</div>',
          '<div class="company-details">',
          '<b>Price</b>: {price:usMoney}<br />',
          '<b>Last Updated</b>: {lastChange:date("n/j h:ia")}<br />',
          '<b>Industry</b>: {industry}', '</div>', '</div>', '</tpl>'),
      overClass : 'company-over',
      itemSelector : 'div.company-wrap',
      emptyText : 'No companies to display',
      autoWidth : true
    });

    Demo.DataView.superclass.initComponent.call(this);
  },
  
  getRecordByCompany: function(comp) {
    return this.store.getAt(this.store.find('company', comp));
  }
});
Ext.reg('demodv', Demo.DataView);