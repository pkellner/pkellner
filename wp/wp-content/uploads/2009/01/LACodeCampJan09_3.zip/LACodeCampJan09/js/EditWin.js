Demo.EditWin = function(config) {
  if (config.allFields && config.grid) {
    this.buildForm(config.grid, config);
  }
  Demo.EditWin.superclass.constructor.call(this, config);
}
Ext.extend(Demo.EditWin, Ext.Window, {
  initComponent: function() {
    
    var formId = 'ew-form-'+Ext.id();
    
    Ext.applyIf(this, {
      modal: true,
      width: 400,
      autoHeight: true,
      items: [{
        xtype: 'form',
        id: formId,
        bodyStyle : 'padding:15px',
        labelWidth : 100,
        defaults : {
          msgTarget : 'side',
          anchor : '90%'
        },
        items: this.formItems
      }],
      buttons : [{
        text : 'Save',
        handler : this.save,
        scope: this
      }, {
        text : 'Cancel',
        handler : function() {
          this.hide();
        },
        scope: this
      }]
    });
    
    Demo.EditWin.superclass.initComponent.call(this);
    
    this.form = Ext.getCmp(formId);
    this.addEvents(
    /**
     * @event save
     * @param {Demo.EditWin} this
     * @param {Ext.data.Record} record
     */
    'save',
    'beforesave'
    );
  },
  
  buildForm: function(grid, config) {
    var items = [];
    Ext.each(grid.getColumnModel().config, function(c,i) {
      if (c.header && c.dataIndex) {
        if (!config.excludeFields || config.excludeFields.indexOf(c.dataIndex) == -1) {
		      items.push({
		        xtype: c.editor ? c.editor.getXType() : 'textfield',
		        fieldLabel: c.header,
		        name: c.dataIndex
		      });
        }
      }
    });
    this.formItems = items;
  },

  save: function() {
    if (this.fireEvent('beforesave', this, this.currentRecord) !== false) {
	    this.form.getForm().updateRecord(this.currentRecord);
	    this.fireEvent('save', this, this.currentRecord);
    }
    this.hide();
  },
  
  loadRecord: function(rec) {
    this.currentRecord = rec;
    this.form.getForm().loadRecord(rec); 
  }
});