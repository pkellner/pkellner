﻿using System;

public partial class DefaultNoColumns : System.Web.UI.MasterPage
{
   
}
