﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;


public partial class News : Page
{
   
}