'
'Copyright � 2005, Peter Kellner
'All rights reserved.
'http://peterkellner.net

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:

'- Redistributions of source code must retain the above copyright
'notice, this list of conditions and the following disclaimer.

'- Neither Peter Kellner, nor the names of its
'contributors may be used to endorse or promote products
'derived from this software without specific prior written
'permission.

'THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
'"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
'LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
'FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
'COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES INCLUDING,
'BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
'LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
'CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
'LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
'ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
'POSSIBILITY OF SUCH DAMAGE.
'


Imports Microsoft.VisualBasic
Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Collections.ObjectModel

Namespace MembershipUtilities

	''' <summary>
	''' A class used to encapsulate the Roles in ASP.NET Membermanagement 2.0
	''' </summary>
	<DataObject(True)> _
	Public Class RoleDataObject

		''' <summary>
		''' Used to get all roles available
		''' </summary>
		''' <returns></returns>
		''' 
		<DataObjectMethod(DataObjectMethodType.Select, True)> _
		Public Shared Function GetRoles() As List(Of RoleData)
			Return GetRoles(Nothing, False)
		End Function

		''' <summary>
		''' Returns a collection of RoleData type values.  This specialized constructor lets you request by
		''' an individual user
		''' </summary>
		''' <param name="userName">if null and showOnlyAssignedRolls==false, display all roles</param>
		''' <param name="showOnlyAssignedRolls">if true, just show assigned roles</param>
		''' <returns></returns>
		<DataObjectMethod(DataObjectMethodType.Select,False)> _
		Public Shared Function GetRoles(ByVal userName As String, ByVal showOnlyAssignedRolls As Boolean) As List(Of RoleData)
			Dim roleList As List(Of RoleData) = New List(Of RoleData)()

			Dim roleListStr As String() = Roles.GetAllRoles()
			For Each roleName As String In roleListStr
				Dim userInRole As Boolean = False
				' First, figure out if user is in role (if there is a user)
				If Not userName Is Nothing Then
					userInRole = Roles.IsUserInRole(userName, roleName)
				End If

				If showOnlyAssignedRolls = False OrElse userInRole = True Then
					' Getting usersInRole is only used for the count below
					Dim usersInRole As String() = Roles.GetUsersInRole(roleName)
					Dim rd As RoleData = New RoleData()
					rd.RoleName = roleName
					rd.UserName = userName
					rd.UserInRole = userInRole
					rd.NumberOfUsersInRole = usersInRole.Length
					roleList.Add(rd)
				End If
			Next roleName

			' FxCopy will give us a warning about returning a List rather than a Collection.
			' We could copy the data, but not worth the trouble.
			Return roleList
		End Function

		''' <summary>
		''' Used for Inserting a new role.  Doesn't associate a user with a role.
		''' This is not quite consistent with this object, but really what we want.
		''' </summary>
		''' <param name="RoleName">The Name of the role to insert</param>
		<DataObjectMethod(DataObjectMethodType.Insert, True)> _
		Public Shared Sub Insert(ByVal roleName As String)
			If Roles.RoleExists(roleName) = False Then
				Roles.CreateRole(roleName)
			End If
		End Sub

		''' <summary>
		''' Delete any given role while first removing any roles associated with existing users
		''' </summary>
		''' <param name="roleName">name of role to delete</param>
		<DataObjectMethod(DataObjectMethodType.Delete, True)> _
		Public Shared Sub Delete(ByVal roleName As String)
			' remove this role from all users.  not sure if deleterole does this automagically
			Dim muc As MembershipUserCollection = Membership.GetAllUsers()
			Dim allUserNames As String() = New String(0){}

			For Each mu As MembershipUser In muc
				If Roles.IsUserInRole(mu.UserName, roleName) = True Then
					allUserNames(0) = mu.UserName
					Roles.RemoveUsersFromRole(allUserNames, roleName)
				End If
			Next mu
			Roles.DeleteRole(roleName)
		End Sub
	End Class

	''' <summary>
	''' Dataobject class used as a base for the collection
	''' </summary>
	Public Class RoleData

		' Non normalized column which counts current number of users in a role
		Private numberOfUsersInRole_Renamed As Integer
		Public Property NumberOfUsersInRole() As Integer
			Get
				Return numberOfUsersInRole_Renamed
			End Get
			Set
				numberOfUsersInRole_Renamed = Value
			End Set
		End Property

		Private roleName_Renamed As String
		<DataObjectField(True)> _
		Public Property RoleName() As String
			Get
				Return roleName_Renamed
			End Get
			Set
				roleName_Renamed = Value
			End Set
		End Property

		Private userName_Renamed As String
		Public Property UserName() As String
			Get
				Return userName_Renamed
			End Get
			Set
				userName_Renamed = Value
			End Set
		End Property

		Private userInRole_Renamed As Boolean
		Public Property UserInRole() As Boolean
			Get
				Return userInRole_Renamed
			End Get
			Set
				userInRole_Renamed = Value
			End Set
		End Property

	End Class

End Namespace