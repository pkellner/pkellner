using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MembershipUtilities;
using System.Collections.Generic;

public partial class UpdateComment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ButtonZipCount_Click(object sender, EventArgs e)
    {
        MembershipUtilities.MembershipUserAndProfileODS
            membershipUserAndProfileODS =
            new MembershipUserAndProfileODS();

        List<MembershipUserWrapperForMP> li =
            membershipUserAndProfileODS.GetMembers(string.Empty);

        int count = 0;
        foreach (MembershipUserWrapperForMP mu in li)
        {
            if (mu.Address_Zip.StartsWith("9"))
            {
                count++;
            }
        }
        Label1.Text = "Zips Found " + count.ToString() + ".";

    }
}


