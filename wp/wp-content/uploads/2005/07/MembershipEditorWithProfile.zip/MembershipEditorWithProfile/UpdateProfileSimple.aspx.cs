using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ShowProfileSimple : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Only allow for profile update when a user is logged in
        MembershipUser mu = Membership.GetUser();
        if (mu == null)
        {
            ButtonUpdate.Enabled = false;
        }
        else
        {
            if (!IsPostBack)
            {
                TextBoxFirstName.Text = Profile.FirstName;
                TextBoxLastName.Text = Profile.LastName;
            }
        }
    }

    protected void ButtonUpdate_Click(object sender,
        EventArgs e)
    {
        Profile.FirstName = TextBoxFirstName.Text;
        Profile.LastName = TextBoxLastName.Text;
        Profile.Save();
    }
}
