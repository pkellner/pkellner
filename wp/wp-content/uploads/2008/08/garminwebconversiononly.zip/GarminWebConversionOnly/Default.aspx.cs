﻿using System;
using System.Web.UI;

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string fileName = Context.Server.MapPath("~/App_Data/sample.tcl");
        Activity activity = GarminUtils.ConvertTCS(fileName);
        int count = 0;
        foreach (Lap lap in activity.Laps)
        {
            foreach (Track track in lap.Tracks)
            {
                foreach (TrackPoint tp in track.TrackPoints)
                {
                    count++;
                }
            }
        }
        LabelStatus.Text = String.Format("{0} Track Points Processed.", count);
    }
}