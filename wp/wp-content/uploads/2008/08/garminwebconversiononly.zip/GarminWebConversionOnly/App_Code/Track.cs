﻿using System.Collections.Generic;

public class Track
{
    public List<TrackPoint> TrackPoints { set; get; }
}