﻿using System.Collections.Generic;

public class Activity
{
    public string Id { set; get; }
    public string Sport { set; get; }
    public List<Lap> Laps { set; get; }
}