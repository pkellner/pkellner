﻿public class Position
{
    public double LatitudeDegrees { set; get; }
    public double LongitudeDegrees { set; get; }
}