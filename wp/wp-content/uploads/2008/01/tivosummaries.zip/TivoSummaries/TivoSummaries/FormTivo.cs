﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Net.Security;
using ZedGraph;
using System.Reflection;

namespace TivoSummaries
{

    public partial class FormTivo : Form
    {
        private ZedGraph.ZedGraphControl zg1;
        //private PictureBox pb1;

        public FormTivo()
        {
            InitializeComponent();
        }

        private void FormTivo_LoadExtracted()
        {
            zg1 = new ZedGraphControl();

            try
            {
                textBoxTivoServiceNumber.Text = Properties.Settings1.Default.TivoService;
                textBoxTivoMediaKey.Text = Properties.Settings1.Default.TivoMediaKey;
            }
            catch (Exception eee)
            {
                throw new ApplicationException(eee.ToString());
            }


            string urlName =
                string.Format(@"https://{0}/TiVoConnect?Command=QueryContainer&Container=%2FNowPlaying&Recurse=Yes", Properties.Settings1.Default.TivoService);

            ServicePointManager.ServerCertificateValidationCallback = TrustAllCertificatePolicy.TrustAllCertificateCallback;
            WebClient webClient = new WebClient();
            webClient.Credentials = new System.Net.NetworkCredential("tivo",
                Properties.Settings1.Default.TivoMediaKey);

            try
            {
                webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(client_OpenReadCompleted);
                webClient.OpenReadAsync(new Uri(urlName));
            }
            catch (Exception ee)
            {
                throw new ApplicationException(ee.ToString());
            }
        }
        private void FormTivo_Load(object sender, EventArgs e)
        {
            FormTivo_LoadExtracted();
        }

      

        private void client_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            if ((e.Error != null) || (e.Cancelled))
            {
                return;
            }

            List<KeyValuePair<string, Int64>> spaceList = null;
            using (StreamReader reader = new StreamReader(e.Result))
            {
                spaceList = TivoUtils.GetSpaceByCategory(reader.ReadToEnd());
            };
            
            GraphSpace(spaceList);
            pictureBox1.Visible = false;
        }

        private void GraphSpace(List<KeyValuePair<string, Int64>> spaceList)
        {
            Color[] colorsx = {Color.Navy,Color.Purple,Color.LimeGreen,Color.SandyBrown,
                                 Color.Red,Color.Blue,Color.Green,Color.Yellow};
            

            GraphPane myPane = zg1.GraphPane;
            this.Controls.Add(zg1);

            myPane.Title.Text = "Tivo Space by Content Type";
            myPane.Title.FontSpec.IsItalic = true;
            myPane.Title.FontSpec.Size = 24f;
            myPane.Title.FontSpec.Family = "Times New Roman";

            // Fill the pane background with a color gradient
            myPane.Fill = new Fill(Color.White, Color.Goldenrod, 45.0f);
            // No fill for the chart background
            myPane.Chart.Fill.Type = FillType.None;

            // Set the legend to an arbitrary location
            myPane.Legend.Position = LegendPos.Float;
            myPane.Legend.Location = new Location(0.95f, 0.15f, CoordType.PaneFraction,
                           AlignH.Right, AlignV.Top);
            myPane.Legend.FontSpec.Size = 10f;
            myPane.Legend.IsHStack = false;

            Int64 total = 0;
            foreach (KeyValuePair<string, Int64> kvp in spaceList)
            {
                total += kvp.Value;
            }

            int cnt = 0;
            foreach (KeyValuePair<string, Int64> kvp in spaceList)
            {
                Int64 Mbs = kvp.Value / 1000000;
                string contentType = kvp.Key;
                PieItem segment1 = myPane.AddPieSlice(Mbs, colorsx[cnt], Color.White, 45f, 0,
                    string.Format("{0} {1}%",contentType.Substring(15),(Mbs*100000000)/total));
                cnt++;
            }

            // Sum up the pie values                                                               
            CurveList curves = myPane.CurveList;
            
            // Make a text label to highlight the total value
            TextObj text = new TextObj(String.Format("{0} Gigabytes Recorded.",total/1000000000),
                           0.18F, 0.40F, CoordType.PaneFraction);
            text.Location.AlignH = AlignH.Center;
            text.Location.AlignV = AlignV.Bottom;
            text.FontSpec.Border.IsVisible = false;
            text.FontSpec.Fill = new Fill(Color.White, Color.FromArgb(255, 100, 100), 45F);
            text.FontSpec.StringAlignment = StringAlignment.Center;
            myPane.GraphObjList.Add(text);

            // Create a drop shadow for the total value text item
            TextObj text2 = new TextObj(text);
            text2.FontSpec.Fill = new Fill(Color.Black);
            text2.Location.X += 0.008f;
            text2.Location.Y += 0.01f;
            myPane.GraphObjList.Add(text2);

            // Calculate the Axis Scale Ranges
            zg1.AxisChange();
            SetSize();
        }

        private void SetSize()
        {
            zg1.Location = new Point(10, 30);
            // Leave a small margin around the outside of the control
            zg1.Size = new Size(this.ClientRectangle.Width - 20,
                    this.ClientRectangle.Height - 40);
        }

        private void FormTivo_Resize(object sender, EventArgs e)
        {
            SetSize();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Properties.Settings1.Default.TivoService = textBoxTivoServiceNumber.Text;
            Properties.Settings1.Default.TivoMediaKey = textBoxTivoMediaKey.Text;
            Properties.Settings1.Default.Save();
            this.Controls.Remove(zg1);
            pictureBox1.Visible = true;
            FormTivo_LoadExtracted();
        }

    
    }

    public class TrustAllCertificatePolicy : System.Net.ICertificatePolicy
    {
        public static bool TrustAllCertificateCallback(object sender,
            X509Certificate cert, X509Chain chain, SslPolicyErrors errors)
        {
            return true;
        }

        public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem)
        {
            return true;
        }
    }


}
