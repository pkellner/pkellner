﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;
using System.Linq;
using System.IO;



namespace TivoSummaries
{
    class TivoUtils
    {
        /// <summary>
        /// Initializes a new instance of the TivoUtils class.
        /// </summary>
        public TivoUtils()
        {
        }

        public static List<KeyValuePair<string, Int64>> GetSpaceByCategory(string xmlString)
        {
            XNamespace ns1 = "http://www.tivo.com/developer/calypso-protocol-1.6/";


            XElement root;
            try
            {
                TextReader stringReader =  new StringReader(xmlString);
                root = XElement.Load(stringReader);
            }
            catch (Exception e)
            {
                throw new ApplicationException(e.ToString());
            }

            List<TivoShowInfo> tivoShowInfoList = new List<TivoShowInfo>();

            var query =
              from item in root.Descendants(ns1 + "Item")
              let details = item.Element(ns1 + "Details")
              let links = item.Element(ns1 + "Links")
              where links.HasElements == true
              select new
              {
                  Title = (String)details.Element(ns1 + "Title"),
                  Duration = (Int32)details.Element(ns1 + "Duration"),
                  Bytes = (Int64)details.Element(ns1 + "SourceSize"),
                  customIcon = (XElement)links.Element(ns1 + "CustomIcon")
              };


            foreach (var item in query)
            {
                if (item.customIcon != null)
                {
                    XElement customIconElement = item.customIcon;
                    var query1 =
                        from item1 in customIconElement.Descendants()
                        where item1.Name.LocalName.Equals("Url")
                        select item1;

                    foreach (XElement v in query1)
                    {
                        string myTitle = item.Title;
                        int myDuration = item.Duration;
                        string urlValue = v.Value;
                        tivoShowInfoList.Add(new TivoShowInfo(item.Title, item.Duration, item.Bytes, v.Value));
                    }
                }
            }

            Int64 totalBytes = (from t in tivoShowInfoList select t.NumberBytes).Sum();

            var categories =
              from s in tivoShowInfoList
              group s by s.ShowType into g
              select
                new
                {
                    ShowType1 = g.Key,
                    TotalBytes = g.Sum(s => s.NumberBytes)
                };

            List<KeyValuePair<string, Int64>> kvpList = new List<KeyValuePair<string, Int64>>();
            foreach (var c in categories)
            {
                Int64 val = (Int64)c.TotalBytes;

                KeyValuePair<string, Int64> kvp = new KeyValuePair<string, Int64>(c.ShowType1, val);
                kvpList.Add(kvp);
            }
            return kvpList;
        }
    }

    class TivoShowInfo
    {
        /// <summary>
        /// Initializes a new instance of the TivoShowInfo class.
        /// </summary>
        /// <param name="title"></param>
        /// <param name="duration"></param>
        /// <param name="numberBytes"></param>
        /// <param name="showType"></param>
        public TivoShowInfo(string title, int duration, Int64 numberBytes, string showType)
        {
            _Title = title;
            _Duration = duration;
            _NumberBytes = numberBytes;
            _ShowType = showType;
        }

        private string _Title;
        public string Title
        {
            get { return _Title; }
            set
            {
                _Title = value;
            }
        }

        private int _Duration;
        public int Duration
        {
            get { return _Duration; }
            set
            {
                _Duration = value;
            }
        }

        private Int64 _NumberBytes;
        public Int64 NumberBytes
        {
            get { return _NumberBytes; }
            set
            {
                _NumberBytes = value;
            }
        }

        private string _ShowType;
        public string ShowType
        {
            get { return _ShowType; }
            set
            {
                _ShowType = value;
            }
        }

    }
}
