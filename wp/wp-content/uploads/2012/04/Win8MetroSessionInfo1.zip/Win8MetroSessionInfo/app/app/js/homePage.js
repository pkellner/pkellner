﻿(function () {
    "use strict";

    // This function is called whenever a user navigates to this page. It
    // populates the page elements with the app's data.
    function ready(element, options) {
       
        
        var urlString = 'http://www.siliconvalley-codecamp.com/GeneralHandlers/Speakers.ashx';
        var xhrOptions = { url: urlString };
        var that = this;
        WinJS.xhr(xhrOptions).done(function (myXhr) {
            var result = JSON.parse(myXhr.response);
            var speakers = [];
            for (var i = 0; i < result.rows.length; i++) {
                var speaker = {};
                speaker.UserFirstName = result.rows[i].UserFirstName;
                speaker.UserLastName = result.rows[i].UserLastName;
                speaker.UserWebsite = result.rows[i].UserWebsite;
                speaker.UserBio = result.rows[i].UserBio;
                speaker.PKID = result.rows[i].PKID;
                speaker.Sessions = result.rows[i].Sessions;
                speakers.push(speaker);
            }
            var speakersList = new WinJS.Binding.List(speakers);
            var publicSpeakers =
                {
                    itemList: speakersList
                };
            
            WinJS.Namespace.define("DataSpeakers", publicSpeakers);
            var listView = element.querySelector(".itemslist").winControl;
            WinJS.UI.setOptions(listView, {
                itemTemplate: element.querySelector(".itemtemplate"),
                itemDataSource: DataSpeakers.itemList.dataSource,
                oniteminvoked: that.itemInvoked.bind(this)
            });

        }, function () {
            console.log('error');
        });
    }
    


    WinJS.UI.Pages.define("/html/homePage.html", {
        itemInvoked: function (eventObject) {
            var itemIndex = eventObject.detail.itemIndex;
            var speakerInfo = DataSpeakers.itemList.getAt(itemIndex);
            WinJS.Navigation.navigate("/html/SpeakerDetail.html", { speakerInfo: speakerInfo });
        },

        // This function updates the page layout in response to viewState changes.
        updateLayout: function (element, viewState) {
            var listView = element.querySelector(".itemslist").winControl;
            if (viewState === Windows.UI.ViewManagement.ApplicationViewState.snapped) {
                listView.layout = new WinJS.UI.ListLayout();
            } else {
                listView.layout = new WinJS.UI.GridLayout();
            }
        },

        ready: ready
    });

    WinJS.UI.Pages.define("/html/homePage.html", {
        ready: ready
    });
})();
