﻿// For an introduction to the HTML Fragment template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    // This function is called whenever a user navigates to this page. It
    // populates the page elements with the app's data.
    function ready(element, options) {
        var title = document.querySelector(".pagetitle");
        title.innerText = 'SV Code Camp Speaker ' + options.speakerInfo.UserFirstName + ' '
            + options.speakerInfo.UserLastName;
        
        var bio = document.querySelector(".speakerbio");
        bio.innerText = options.speakerInfo.UserBio;

        var speakers = [];
        speakers.push(options.speakerInfo);

        //var speakersList = new WinJS.Binding.List(speakers);
        var sessionList = new WinJS.Binding.List(options.speakerInfo.Sessions);
     
        WinJS.Binding.processAll(document.querySelector(".SpeakerDetail"), options.speakerInfo);
        //WinJS.Binding.processAll(document.querySelector(""), options.speakerInfo);

        var listView = element.querySelector(".itemslist").winControl;
        WinJS.UI.setOptions(listView, {
            itemTemplate: element.querySelector(".itemtemplate"),
            itemDataSource: sessionList.dataSource
        });
    }   

    function updateLayout(element, viewState) {
        // TODO: Respond to changes in viewState.
    }

    WinJS.UI.Pages.define("/html/SpeakerDetail.html", {
        ready: ready,
        updateLayout: updateLayout
    });
})();
