Ext.define('MyApp.controller.MyController', {
    extend: 'Ext.app.Controller',

    views: [
        'MyPanel'
    ],

    refs: [
        {
            ref: 'MyPanel',
            selector: 'mypanel'
        }],

    init: function () {

        this.control({
            'button[action=b1]': {
                tap: this.onButtonTap1
            },
            'button[action=b2]': {
                tap: this.onButtonTap2
            }
        });
    },

    onLaunch: function () {
        console.log('onLaunch');
    },

    onButtonTap1: function () {
        console.log('controller: onButtonTap1');
    },

    onButtonTap2: function () {
        console.log('controller: onButtonTap2');
    },

    config: {

    }
});