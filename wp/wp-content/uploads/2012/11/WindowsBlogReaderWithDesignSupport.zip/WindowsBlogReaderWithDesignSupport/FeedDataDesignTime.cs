﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace WindowsBlogReader
{
    public class FeedDataSourceDesignTime
    {
        public List<FeedData> Feeds { get; set; }

        public FeedDataSourceDesignTime()
        {
            Feeds = new List<FeedData>();
            const string imageUrl = 
                "http://petersblogcdn.s3.amazonaws.com/wp/wp-content/themes/curved-10/images/Peter-Kellner.jpg";
            DateTime dt = DateTime.Now;
            var feedDatas = new List<FeedData>
                                {

                                    new FeedData
                                        {
                                            
                                            Description = "description1",
                                            PubDate = dt.Subtract(new TimeSpan(1, 1, 1)),
                                            Title = "title1",
                                            Items = new List<FeedItem>
                                                        {
                                                            new FeedItem
                                                                {
                                                                    Author = "FIauthor1a",
                                                                    Title = "FItitle1a",
                                                                    Content = "<b>Content1a</b>",
                                                                    PubDate = dt.Subtract(new TimeSpan(2, 1, 1)),
                                                                    Link = new Uri(imageUrl),

                                                                },
                                                            new FeedItem
                                                                {
                                                                    Author = "FIauthor1b",
                                                                    Title = "FItitle1b",
                                                                    Content = "<b>Content1b</b>",
                                                                    PubDate = dt.Subtract(new TimeSpan(3, 1, 1)),
                                                                    Link = new Uri(imageUrl),
                                                                }
                                                        }
                                        },
                                    new FeedData
                                        {
                                            Description = "description2",
                                            PubDate = dt.Subtract(new TimeSpan(4, 1, 1)),
                                            Title = "title2",
                                            Items = new List<FeedItem>
                                                        {
                                                            new FeedItem
                                                                {
                                                                    Author = "FIauthor2a",
                                                                    Title = "FItitle2a",
                                                                    Content = "<b>Content2a</b>",
                                                                    PubDate = dt.Subtract(new TimeSpan(5, 1, 1)),
                                                                    Link = new Uri(imageUrl),
                                                                },
                                                            new FeedItem
                                                                {
                                                                    Author = "FIauthor2b",
                                                                    Title = "FItitle2b",
                                                                    Content = "<b>Content2b</b>",
                                                                    PubDate = dt.Subtract(new TimeSpan(6, 1, 1)),
                                                                    Link = new Uri(imageUrl),
                                                                }
                                                        }
                                        }
                                };
            Feeds.AddRange(feedDatas);
        }





        public Task GetAsync()
        {
            return null;
        }

        public static FeedData GetFeed(string emailTitle)
        {
            return null;
        }

        public static FeedItem GetItem(string itemTitle)
        {
            return null;
        }

        public Task GetFeedsAsync()
        {
            return null;
        }

    }
}